# 🎬 Demo Script: Awesome Codebase Analysis (eShop + Juice Shop)

This script shows how to demo the entire analysis flow using:

- **eShopOnContainers / eShop** – realistic microservices e-commerce system.
- **OWASP Juice Shop** – intentionally insecure app for security demos.

---

## 1. Clone & Run the Demo Repos

### 1.1 eShop (System Design + Patterns + Data Flows)

```bash
git clone https://github.com/dotnet/eShop.git
cd eShop
# follow repo instructions, typically:
docker compose up
```

eShop gives you:

- Microservices-based architecture (catalog, basket, ordering, identity, etc.).
- Docker-based deployment, suitable for C4 & container diagrams.
- Relational databases and messaging for ERD + data flow analysis.

### 1.2 Juice Shop (Security & Vulnerabilities)

```bash
git clone https://github.com/juice-shop/juice-shop.git
cd juice-shop
npm install
npm start
```

Juice Shop is intentionally insecure and perfect for security reasoning demos.

---

## 2. Stage 1 – Tech Context & Capabilities (eShop)

1. From the `eShop` repo, collect:
   - Root `README.md`.
   - `docker-compose.yml`.
   - Output of `tree -L 2 src`.

2. Use `STAGE_1/1.1_tech_context.prompt.md` with this input.  
   - **Output:** `[TECH_CONTEXT_JSON]` (language, framework, DB type, auth model, domain summary).

3. Collect controllers/routes for one or more services (e.g., Ordering API).  
   - Use `STAGE_1/1.2_capability_extraction.prompt.md`.  
   - **Output:** `[CAPABILITY_LIST]` – top user-facing features.

---

## 3. Stage 2 – Architecture & Data Modeling (eShop)

### 3.1 C4 Context & Container

1. Use `[TECH_CONTEXT_JSON]`, `docker-compose.yml`, and key parts of the architecture docs.
2. Run `STAGE_2/2.1_c4_model_generation.prompt.md`.  
   - **Output:** `[C4_TEXT_OUTPUT]` – C4 Level 1 & 2 in markdown.

### 3.2 ERD (Mermaid)

1. Choose a microservice (e.g., Ordering). Gather ORM models / schema.
2. Run `STAGE_2/2.2_erd_mermaid_script.prompt.md`.  
   - **Output:** `[MERMAID_ERD_SCRIPT]` – directly renderable ER diagram.

---

## 4. Stage 3 – Critical Flow & Scaffolding (eShop)

### 4.1 Critical Flow Sequence Diagram

1. From `[CAPABILITY_LIST]`, pick the most complex feature (e.g., Checkout / Place Order).
2. Collect related service/logic files.
3. Run `STAGE_3/3.1_critical_flow_sequence.prompt.md`.  
   - **Output:** `[SEQUENCE_DIAGRAM_SCRIPT]` – PlantUML sequence diagram script.

### 4.2 Minimal Scaffold Outline

1. Use `[TECH_CONTEXT_JSON]` and `tree -L 4` from the repo.
2. Run `STAGE_3/3.2_scaffold_outline_generation.prompt.md`.  
   - **Output:** `[SCAFFOLD_OUTLINE_TREE]` – minimal project structure for 3 basic features.

---

## 5. System Design – Pattern Selection & Blueprint

### 5.1 Multi-Option Pattern Comparison

1. Provide eShop business context and NFRs.
2. Run `SYSTEM_DESIGN/1.0_pattern_selection_multi.prompt.md`.  
   - **Output:** `[SYSTEM_PATTERN_OPTIONS]` – comparison of multiple architecture patterns.

### 5.2 Single Recommended Pattern

1. Feed `[SYSTEM_PATTERN_OPTIONS]` into  
   `SYSTEM_DESIGN/1.1_pattern_selection_single_option.prompt.md`.  
   - **Output:** `[SELECTED_SYSTEM_PATTERN]` – one chosen pattern with strong justification.

### 5.3 Detailed System Design Blueprint

1. Provide `[SELECTED_SYSTEM_PATTERN]` and 3–7 core use cases.
2. Run `SYSTEM_DESIGN/2.0_pattern_detailed_design.prompt.md`.  
   - **Output:** `[SYSTEM_DESIGN_BLUEPRINT]` – production-grade design summary with mapped design patterns.

---

## 6. Stage 4 – Security Paths

You can choose one or more of these branches.

### 6.1 Classic Stage 4 – With DAST Findings (Any App)

1. Generate DAST scan output (e.g., ZAP, Nikto) as JSON/XML.
2. Use `STAGE_4/4.1_security_report_generation.prompt.md` with:
   - Raw DAST findings.
   - `[SEQUENCE_DIAGRAM_SCRIPT]`.
   - `[TECH_CONTEXT_JSON]`.  
   - **Output:** `[FINAL_SECURITY_REPORT]`.

### 6.2 LLM-Only Static Security (eShop or Juice Shop)

1. Collect:
   - `[TECH_CONTEXT_JSON]`.
   - Auth/authorization code.
   - API routes/controllers.
   - Security-related config.
2. Run, in order:
   - `STAGE_4_LLM_ONLY/4.0_security_context_llm_only.prompt.md` → `[SECURITY_CONTEXT_JSON]`.
   - `STAGE_4_LLM_ONLY/4.1_static_threat_analysis_llm_only.prompt.md` → `[STATIC_SECURITY_FINDINGS]`.
   - `STAGE_4_LLM_ONLY/4.2_security_report_llm_only.prompt.md` → `[LLM_ONLY_SECURITY_REPORT]`.

This gives a fully LLM-based, static security review.

### 6.3 LLM-DAST: Reasoning Over Captured HTTP Traffic (Juice Shop)

1. From a running Juice Shop instance, capture HTTP traffic:
   - Login, registration, browsing, checkout, error pages.
   - Use browser DevTools or curl and copy raw requests/responses.

2. Run, in order:
   - `STAGE_4_LLM_DAST/4.0_llm_dast_context.prompt.md` → `[LLM_DAST_OBSERVATIONS]`.
   - `STAGE_4_LLM_DAST/4.1_llm_dast_findings.prompt.md` → `[LLM_DAST_FINDINGS]`.
   - `STAGE_4_LLM_DAST/4.2_llm_dast_report.prompt.md` → `[LLM_DAST_REPORT]`.

This produces a DAST-style report purely from captured traffic and LLM reasoning.

---

## 7. Suggested 20–30 Minute Live Demo Flow

1. **Intro (2–3 min):** Explain the goal – an agentic LLM pipeline for system understanding, design, and security.
2. **eShop Understanding (5–7 min):** Show Stage 1 outputs and C4/ERD.
3. **System Design (5–7 min):** Run or show pattern selection + blueprint.
4. **Security (5–10 min):** Either:
   - LLM-only static security on eShop, or
   - LLM-DAST-style reasoning on Juice Shop traffic.
5. **Wrap-up (2–3 min):** Highlight that the same prompt pack can be reused for any repo.
