# 💡 Awesome Codebase Analysis Prompts (Agentic Flow)

A structured collection of sequential prompts designed for Large Language Models (LLMs) to perform **deep analysis and documentation** of software repositories in an "agentic" manner. The output of one step is designed to be the input for the next, ensuring a cohesive and high-quality analysis.

## 🚀 Flow Overview

The analysis is broken into multiple sequential stages:

1.  **Stage 1:** Core Technology and Capability Identification.
2.  **Stage 2:** Architecture and Data Modeling (C4 & ERD) Generation.
3.  **Stage 3:** Flow Diagram (Sequence) and Scaffolding Preparation.
4.  **Stage 4 (Classic):** Security Analysis Reporting (with DAST findings, if available).
5.  **Stage 4 (LLM-Only):** Static security analysis using only code/config and LLM reasoning.
6.  **Stage 4 (LLM-DAST):** DAST-style reasoning using captured HTTP traffic only.
7.  **System Design Pack:** Standard architecture pattern selection & detailed blueprint generation.

## 📝 How to Use

1.  Start with Stage 1: execute the prompt in `STAGE_1/1.1_tech_context.prompt.md`.
2.  Pass outputs between prompts using the named variables (e.g., `[TECH_CONTEXT_JSON]`, `[CAPABILITY_LIST]`).
3.  Use the `SYSTEM_DESIGN` prompts for higher-level architecture decisions.
4.  Choose **one** of the Stage 4 branches depending on your context:
    - `STAGE_4/` for traditional DAST output analysis.
    - `STAGE_4_LLM_ONLY/` for static, LLM-only security.
    - `STAGE_4_LLM_DAST/` for LLM-based reasoning over captured HTTP traffic.
5.  See `DEMO_SCRIPT.md` for a concrete end-to-end demo using real open-source repos.
