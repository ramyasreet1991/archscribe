"""
Example usage of the Deep-Thinking RAG Pipeline for Pentest Reports
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.pipeline.orchestrator import DeepThinkingRAGPipeline
from src.data.pentest_loader import PentestReportLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

load_dotenv()


def example_1_simple_query():
    """Example 1: Simple query for exploit information."""
    print("\n" + "="*80)
    print("EXAMPLE 1: Query for SQL Injection Exploits")
    print("="*80)
    
    pipeline = DeepThinkingRAGPipeline()
    
    # Load some sample data
    loader = PentestReportLoader()
    findings = loader.create_sample_findings()
    
    # Create documents from findings
    from langchain.schema import Document
    documents = []
    for finding in findings:
        content = f"""
        Vulnerability: {finding['title']}
        Type: {finding['type']}
        Severity: {finding['severity']}
        Description: {finding['description']}
        CVE/CWE: {finding.get('cve', 'N/A')}
        """
        doc = Document(
            page_content=content,
            metadata={"type": "finding", "severity": finding['severity']}
        )
        documents.append(doc)
    
    # Add to retrieval system
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
    split_docs = text_splitter.split_documents(documents)
    pipeline.retrieval_system.add_documents(split_docs)
    
    # Query
    query = "What are the common SQL injection attack vectors and how can they be exploited?"
    result = pipeline.process_query(query, max_iterations=2)
    
    print(f"\nQuery: {query}")
    print(f"\nFound {len(result['exploits'])} exploits:")
    for exploit in result['exploits']:
        print(f"  - {exploit.get('name', 'Unknown')} ({exploit.get('severity', 'Unknown')})")
    
    print(f"\nKnowledge Graph: {result['knowledge_graph']['stats']['nodes']} nodes, "
          f"{result['knowledge_graph']['stats']['edges']} edges")


def example_2_generate_report():
    """Example 2: Generate a full pentest report."""
    print("\n" + "="*80)
    print("EXAMPLE 2: Generate Pentest Report from Findings")
    print("="*80)
    
    pipeline = DeepThinkingRAGPipeline()
    
    # Load knowledge base
    loader = PentestReportLoader()
    findings = loader.create_sample_findings()
    
    # Create documents
    from langchain.schema import Document
    documents = []
    for finding in findings:
        content = f"""
        Finding: {finding['title']}
        Type: {finding['type']}
        Severity: {finding['severity']}
        Description: {finding['description']}
        Location: {finding.get('location', 'N/A')}
        CVE: {finding.get('cve', 'N/A')}
        CVSS: {finding.get('cvss_score', 0.0)}
        """
        doc = Document(
            page_content=content,
            metadata={"type": "finding", "severity": finding['severity']}
        )
        documents.append(doc)
    
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
    split_docs = text_splitter.split_documents(documents)
    pipeline.retrieval_system.add_documents(split_docs)
    
    # Generate report
    target_info = {
        "name": "Example Web Application",
        "type": "Web Application",
        "url": "https://example.com"
    }
    
    result = pipeline.generate_pentest_report(
        findings=findings,
        target_info=target_info
    )
    
    print(f"\nReport generated!")
    print(f"  - Evidence collected: {len(result['evidence'])} documents")
    print(f"  - Exploits identified: {len(result['exploits'])}")
    print(f"  - Knowledge graph nodes: {result['knowledge_graph']['stats']['nodes']}")
    
    # Save report
    output_dir = Path("./output")
    output_dir.mkdir(exist_ok=True)
    pipeline.report_generator.export_markdown(result["report"], str(output_dir / "example_report.md"))
    print(f"\nReport saved to: {output_dir / 'example_report.md'}")


def example_3_knowledge_graph():
    """Example 3: Build and visualize knowledge graph."""
    print("\n" + "="*80)
    print("EXAMPLE 3: Knowledge Graph Visualization")
    print("="*80)
    
    pipeline = DeepThinkingRAGPipeline()
    
    # Create sample evidence with CVEs
    from langchain.schema import Document
    evidence = [
        Document(
            page_content="SQL Injection vulnerability CVE-2024-1234 found in login endpoint. Related to CWE-89.",
            metadata={"type": "finding"}
        ),
        Document(
            page_content="XSS vulnerability CVE-2024-5678 in search functionality. Related to CWE-79.",
            metadata={"type": "finding"}
        )
    ]
    
    exploits = [
        {"name": "SQL Injection Exploit", "cve": "CVE-2024-1234", "severity": "Critical"},
        {"name": "XSS Exploit", "cve": "CVE-2024-5678", "severity": "High"}
    ]
    
    # Build knowledge graph
    kg = pipeline.kg_builder.build_graph(
        evidence=evidence,
        exploits=exploits,
        query="Example query"
    )
    
    print(f"\nKnowledge Graph Statistics:")
    print(f"  - Nodes: {kg['stats']['nodes']}")
    print(f"  - Edges: {kg['stats']['edges']}")
    print(f"  - Node Types: {kg['stats']['node_types']}")
    
    # Visualize
    output_dir = Path("./output")
    output_dir.mkdir(exist_ok=True)
    pipeline.kg_builder.visualize(str(output_dir / "example_kg.html"))
    print(f"\nKnowledge graph visualized: {output_dir / 'example_kg.html'}")


if __name__ == "__main__":
    # Check for API key
    if not os.getenv("OPENAI_API_KEY"):
        print("ERROR: OPENAI_API_KEY not found in environment variables")
        print("Please set it in .env file or environment")
        sys.exit(1)
    
    try:
        example_1_simple_query()
        example_2_generate_report()
        example_3_knowledge_graph()
        print("\n" + "="*80)
        print("All examples completed successfully!")
        print("="*80)
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()

