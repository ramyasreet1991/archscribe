"""
Live Demo: Deep-Thinking RAG Pipeline for Pentest Report Generation
This script demonstrates the system with a realistic pentest scenario
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv
import json
from datetime import datetime

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.pipeline.orchestrator import DeepThinkingRAGPipeline
from src.data.pentest_loader import PentestReportLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document

load_dotenv()


def print_section(title, char="=", width=80):
    """Print a formatted section header."""
    print("\n" + char * width)
    print(f" {title}")
    print(char * width)


def print_subsection(title, char="-", width=80):
    """Print a formatted subsection header."""
    print(f"\n{char * width}")
    print(f" {title}")
    print(char * width)


def demo_setup():
    """Step 1: Setup and initialization."""
    print_section("DEMO: Deep-Thinking RAG Pipeline for Pentest Reports")
    
    print("\n📋 Step 1: Initializing Pipeline...")
    
    # Check for API key
    if not os.getenv("OPENAI_API_KEY"):
        print("⚠️  WARNING: OPENAI_API_KEY not found!")
        print("   The demo will show the structure but won't make API calls.")
        print("   Set OPENAI_API_KEY in .env file to run full demo.\n")
        return None
    
    try:
        pipeline = DeepThinkingRAGPipeline(
            llm_model="gpt-4-turbo-preview",
            temperature=0.3,
            vector_store_path="./vector_store"
        )
        print("✅ Pipeline initialized successfully!")
        return pipeline
    except Exception as e:
        print(f"❌ Error initializing pipeline: {e}")
        return None


def demo_load_knowledge_base(pipeline):
    """Step 2: Load existing pentest reports."""
    print_subsection("Step 2: Loading Pentest Knowledge Base")
    
    loader = PentestReportLoader()
    
    # Load from data directory
    data_dir = "./data/pentest_reports"
    documents = []
    
    if os.path.exists(data_dir):
        docs = loader.load_from_directory(data_dir)
        documents.extend(docs)
        print(f"✅ Loaded {len(docs)} documents from {data_dir}")
    else:
        print(f"⚠️  Directory {data_dir} not found")
    
    # Create sample documents if none found
    if not documents:
        print("📝 Creating sample knowledge base from findings...")
        findings = loader.create_sample_findings()
        for finding in findings:
            content = f"""
            Vulnerability: {finding['title']}
            Type: {finding['type']}
            Severity: {finding['severity']}
            Description: {finding['description']}
            Location: {finding.get('location', 'N/A')}
            CVE/CWE: {finding.get('cve', 'N/A')}
            CVSS Score: {finding.get('cvss_score', 0.0)}
            
            This vulnerability was identified during a penetration test.
            Similar vulnerabilities have been found in other applications.
            """
            doc = Document(
                page_content=content,
                metadata={
                    "type": "pentest_finding",
                    "severity": finding['severity'],
                    "vulnerability_type": finding['type']
                }
            )
            documents.append(doc)
    
    # Split documents
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )
    
    split_docs = text_splitter.split_documents(documents)
    print(f"📚 Split into {len(split_docs)} chunks")
    
    # Add to retrieval system
    if pipeline:
        pipeline.retrieval_system.add_documents(split_docs)
        print(f"✅ Indexed {len(split_docs)} chunks in vector store")
    
    return len(split_docs)


def demo_realistic_scenario():
    """Step 3: Define realistic pentest scenario."""
    print_subsection("Step 3: Realistic Pentest Scenario")
    
    print("""
    🎯 Scenario: Web Application Security Assessment
    
    Target: E-Commerce Platform (example-shop.com)
    Assessment Type: External Penetration Test
    Duration: 5 days
    """)
    
    # Realistic findings based on common vulnerabilities
    findings = [
        {
            "title": "SQL Injection in User Authentication Endpoint",
            "type": "SQL Injection",
            "severity": "Critical",
            "description": "The /api/auth/login endpoint is vulnerable to SQL injection. "
                          "User input is directly concatenated into SQL queries without "
                          "parameterization. Attackers can bypass authentication using "
                          "payloads like: admin' OR '1'='1'--",
            "location": "/api/auth/login",
            "cve": "CWE-89",
            "cvss_score": 9.8,
            "proof_of_concept": "POST /api/auth/login with payload: {\"username\": \"admin' OR '1'='1'--\", \"password\": \"anything\"}",
            "impact": "Complete authentication bypass, potential data exfiltration, privilege escalation"
        },
        {
            "title": "Cross-Site Scripting (XSS) in Product Search",
            "type": "XSS",
            "severity": "High",
            "description": "The product search functionality at /api/products/search does not "
                          "properly sanitize user input. Stored XSS attacks are possible when "
                          "malicious scripts are injected through search queries.",
            "location": "/api/products/search",
            "cve": "CWE-79",
            "cvss_score": 7.2,
            "proof_of_concept": "GET /api/products/search?q=<script>alert(document.cookie)</script>",
            "impact": "Session hijacking, cookie theft, potential account takeover"
        },
        {
            "title": "Insecure Direct Object Reference (IDOR) in User Orders",
            "type": "IDOR",
            "severity": "High",
            "description": "The API endpoint /api/users/{userId}/orders allows users to access "
                          "orders belonging to other users by manipulating the userId parameter. "
                          "No authorization checks are performed.",
            "location": "/api/users/{userId}/orders",
            "cve": "CWE-639",
            "cvss_score": 7.5,
            "proof_of_concept": "GET /api/users/12345/orders (where 12345 is another user's ID)",
            "impact": "Unauthorized access to sensitive order data, privacy violation"
        },
        {
            "title": "Missing Security Headers",
            "type": "Security Misconfiguration",
            "severity": "Medium",
            "description": "The application is missing critical security headers including "
                          "Content-Security-Policy, X-Frame-Options, and Strict-Transport-Security. "
                          "This increases the risk of XSS attacks and clickjacking.",
            "location": "All endpoints",
            "cve": "CWE-693",
            "cvss_score": 4.3,
            "impact": "Increased attack surface, clickjacking vulnerability"
        },
        {
            "title": "Server-Side Request Forgery (SSRF) in Webhook Callback",
            "type": "SSRF",
            "severity": "High",
            "description": "The webhook callback endpoint accepts arbitrary URLs and makes requests "
                          "to them without validation. This allows attackers to probe internal networks.",
            "location": "/api/webhooks/callback",
            "cve": "CWE-918",
            "cvss_score": 8.2,
            "proof_of_concept": "POST /api/webhooks/callback with {\"url\": \"http://127.0.0.1:8080/admin\"}",
            "impact": "Internal network scanning, access to internal services"
        }
    ]
    
    target_info = {
        "name": "Example E-Commerce Platform",
        "type": "Web Application",
        "url": "https://example-shop.com",
        "scope": "Web application, REST API, and admin panel",
        "assessment_date": datetime.now().strftime("%Y-%m-%d")
    }
    
    print(f"\n📊 Findings Summary:")
    print(f"   - Total Findings: {len(findings)}")
    print(f"   - Critical: {sum(1 for f in findings if f['severity'] == 'Critical')}")
    print(f"   - High: {sum(1 for f in findings if f['severity'] == 'High')}")
    print(f"   - Medium: {sum(1 for f in findings if f['severity'] == 'Medium')}")
    print(f"   - Low: {sum(1 for f in findings if f['severity'] == 'Low')}")
    
    return findings, target_info


def demo_generate_report(pipeline, findings, target_info):
    """Step 4: Generate the pentest report."""
    print_subsection("Step 4: Generating Pentest Report with Deep-Thinking Pipeline")
    
    if not pipeline:
        print("⚠️  Skipping report generation (no pipeline)")
        return None
    
    print("\n🔄 Starting Deep-Thinking Pipeline...")
    print("   This involves:")
    print("   1. Planning: Decomposing query into research steps")
    print("   2. Retrieval: Finding similar reports and exploits")
    print("   3. Refinement: Reranking and distilling evidence")
    print("   4. Exploit Analysis: Identifying CVEs and attack vectors")
    print("   5. Reflection: Critiquing and improving")
    print("   6. Knowledge Graph: Building relationships")
    print("   7. Report Generation: Synthesizing final report")
    print("\n⏳ Processing... (this may take a few minutes)")
    
    try:
        result = pipeline.generate_pentest_report(
            findings=findings,
            target_info=target_info,
            scan_results=None
        )
        
        print("✅ Report generation complete!")
        return result
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        import traceback
        traceback.print_exc()
        return None


def demo_display_results(result):
    """Step 5: Display and save results."""
    print_subsection("Step 5: Results and Output")
    
    if not result:
        print("⚠️  No results to display")
        return
    
    print("\n📈 Pipeline Statistics:")
    print(f"   - Query: {result.get('query', 'N/A')[:100]}...")
    print(f"   - Iterations: {result.get('iterations', 0)}")
    print(f"   - Evidence Collected: {len(result.get('evidence', []))} documents")
    print(f"   - Exploits Identified: {len(result.get('exploits', []))}")
    
    # Display exploits
    if result.get('exploits'):
        print("\n🔍 Identified Exploits:")
        for i, exploit in enumerate(result['exploits'][:5], 1):  # Show top 5
            print(f"\n   {i}. {exploit.get('name', 'Unknown')}")
            print(f"      CVE: {exploit.get('cve', 'N/A')}")
            print(f"      Severity: {exploit.get('severity', 'Unknown')}")
            if exploit.get('cvss_score'):
                print(f"      CVSS Score: {exploit.get('cvss_score')}")
            desc = exploit.get('description', '')[:150]
            if desc:
                print(f"      Description: {desc}...")
    
    # Knowledge graph stats
    if result.get('knowledge_graph', {}).get('stats'):
        kg_stats = result['knowledge_graph']['stats']
        print(f"\n🕸️  Knowledge Graph:")
        print(f"   - Nodes: {kg_stats.get('nodes', 0)}")
        print(f"   - Edges: {kg_stats.get('edges', 0)}")
        print(f"   - Node Types: {kg_stats.get('node_types', {})}")
        
        if kg_stats.get('central_nodes'):
            print(f"\n   Key Entities:")
            for node in kg_stats['central_nodes'][:3]:
                print(f"   - {node.get('type', 'unknown')}: {node.get('node', '')[:50]}")
    
    # Save outputs
    output_dir = Path("./output")
    output_dir.mkdir(exist_ok=True)
    
    if result.get('report'):
        report_path = output_dir / "demo_pentest_report.md"
        try:
            pipeline = DeepThinkingRAGPipeline()  # Need pipeline for export
            pipeline.report_generator.export_markdown(result["report"], str(report_path))
            print(f"\n💾 Report saved to: {report_path}")
        except:
            # Fallback: save raw content
            with open(report_path, "w") as f:
                f.write(result["report"].get("content", ""))
            print(f"\n💾 Report saved to: {report_path}")
    
    # Save knowledge graph
    if result.get('knowledge_graph'):
        try:
            pipeline = DeepThinkingRAGPipeline()
            kg_html = output_dir / "demo_knowledge_graph.html"
            kg_json = output_dir / "demo_knowledge_graph.json"
            pipeline.kg_builder.visualize(str(kg_html))
            pipeline.kg_builder.export_json(str(kg_json))
            print(f"💾 Knowledge graph saved to: {kg_html} and {kg_json}")
        except Exception as e:
            print(f"⚠️  Could not save knowledge graph: {e}")
    
    # Save full result
    result_path = output_dir / "demo_full_result.json"
    result_copy = result.copy()
    # Remove non-serializable objects
    if "knowledge_graph" in result_copy and "graph" in result_copy["knowledge_graph"]:
        result_copy["knowledge_graph"]["graph"] = "NetworkX graph (see HTML/JSON exports)"
    
    with open(result_path, "w") as f:
        json.dump(result_copy, f, indent=2, default=str)
    print(f"💾 Full result saved to: {result_path}")


def demo_show_report_preview(result):
    """Step 6: Show report preview."""
    print_subsection("Step 6: Report Preview")
    
    if not result or not result.get('report'):
        print("⚠️  No report to preview")
        return
    
    report = result['report']
    content = report.get('content', '')
    
    # Show first 2000 characters
    preview = content[:2000]
    print("\n📄 Report Preview (first 2000 characters):")
    print("-" * 80)
    print(preview)
    if len(content) > 2000:
        print(f"\n... (truncated, full report is {len(content)} characters)")
    print("-" * 80)
    
    # Show metadata
    if report.get('metadata'):
        print("\n📋 Report Metadata:")
        metadata = report['metadata']
        for key, value in metadata.items():
            print(f"   - {key}: {value}")


def main():
    """Run the complete demo."""
    print_section("=" * 80)
    print(" " * 20 + "LIVE DEMO: Deep-Thinking RAG Pipeline")
    print(" " * 15 + "Pentest Report Generation & Exploit Analysis")
    print("=" * 80)
    
    # Step 1: Setup
    pipeline = demo_setup()
    
    # Step 2: Load knowledge base
    doc_count = demo_load_knowledge_base(pipeline)
    
    # Step 3: Define scenario
    findings, target_info = demo_realistic_scenario()
    
    # Step 4: Generate report
    result = demo_generate_report(pipeline, findings, target_info)
    
    # Step 5: Display results
    demo_display_results(result)
    
    # Step 6: Show preview
    demo_show_report_preview(result)
    
    # Final summary
    print_section("Demo Complete!")
    print("\n✅ Demo completed successfully!")
    print("\n📁 Check the ./output/ directory for:")
    print("   - demo_pentest_report.md (Full generated report)")
    print("   - demo_knowledge_graph.html (Interactive knowledge graph)")
    print("   - demo_knowledge_graph.json (Graph data)")
    print("   - demo_full_result.json (Complete analysis)")
    print("\n💡 Next Steps:")
    print("   1. Review the generated report")
    print("   2. Open knowledge_graph.html in a browser to explore relationships")
    print("   3. Add your own pentest reports to ./data/pentest_reports/")
    print("   4. Customize findings and run again")
    print("\n" + "=" * 80)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Demo interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Error during demo: {e}")
        import traceback
        traceback.print_exc()

