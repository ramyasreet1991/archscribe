"""
Simple Demo: Shows the Deep-Thinking RAG Pipeline process
This version demonstrates the workflow without requiring API calls
"""

import json
from pathlib import Path
from datetime import datetime


def print_section(title, char="=", width=80):
    """Print a formatted section header."""
    print("\n" + char * width)
    print(f" {title}")
    print(char * width)


def print_subsection(title, char="-", width=80):
    """Print a formatted subsection header."""
    print(f"\n{char * width}")
    print(f" {title}")
    print(char * width)


def demo_scenario():
    """Define the realistic pentest scenario."""
    print_section("DEMO: Deep-Thinking RAG Pipeline for Pentest Reports")
    
    print("\n🎯 Scenario: Web Application Security Assessment")
    print("   Target: E-Commerce Platform (example-shop.com)")
    print("   Assessment Type: External Penetration Test")
    
    findings = [
        {
            "title": "SQL Injection in User Authentication Endpoint",
            "type": "SQL Injection",
            "severity": "Critical",
            "description": "The /api/auth/login endpoint is vulnerable to SQL injection. "
                          "User input is directly concatenated into SQL queries without "
                          "parameterization. Attackers can bypass authentication.",
            "location": "/api/auth/login",
            "cve": "CWE-89",
            "cvss_score": 9.8,
            "proof_of_concept": "POST /api/auth/login with payload: {\"username\": \"admin' OR '1'='1'--\"}",
            "impact": "Complete authentication bypass, potential data exfiltration"
        },
        {
            "title": "Cross-Site Scripting (XSS) in Product Search",
            "type": "XSS",
            "severity": "High",
            "description": "The product search functionality does not properly sanitize user input. "
                          "Stored XSS attacks are possible when malicious scripts are injected.",
            "location": "/api/products/search",
            "cve": "CWE-79",
            "cvss_score": 7.2,
            "proof_of_concept": "GET /api/products/search?q=<script>alert(document.cookie)</script>",
            "impact": "Session hijacking, cookie theft, potential account takeover"
        },
        {
            "title": "Insecure Direct Object Reference (IDOR)",
            "type": "IDOR",
            "severity": "High",
            "description": "The API endpoint allows users to access orders belonging to other users "
                          "by manipulating the userId parameter. No authorization checks are performed.",
            "location": "/api/users/{userId}/orders",
            "cve": "CWE-639",
            "cvss_score": 7.5,
            "impact": "Unauthorized access to sensitive order data"
        },
        {
            "title": "Missing Security Headers",
            "type": "Security Misconfiguration",
            "severity": "Medium",
            "description": "The application is missing critical security headers including "
                          "Content-Security-Policy, X-Frame-Options, and Strict-Transport-Security.",
            "location": "All endpoints",
            "cve": "CWE-693",
            "cvss_score": 4.3,
            "impact": "Increased attack surface, clickjacking vulnerability"
        },
        {
            "title": "Server-Side Request Forgery (SSRF)",
            "type": "SSRF",
            "severity": "High",
            "description": "The webhook callback endpoint accepts arbitrary URLs and makes requests "
                          "to them without validation. This allows attackers to probe internal networks.",
            "location": "/api/webhooks/callback",
            "cve": "CWE-918",
            "cvss_score": 8.2,
            "proof_of_concept": "POST /api/webhooks/callback with {\"url\": \"http://127.0.0.1:8080/admin\"}",
            "impact": "Internal network scanning, access to internal services"
        }
    ]
    
    target_info = {
        "name": "Example E-Commerce Platform",
        "type": "Web Application",
        "url": "https://example-shop.com",
        "scope": "Web application, REST API, and admin panel"
    }
    
    print(f"\n📊 Findings Summary:")
    print(f"   - Total Findings: {len(findings)}")
    print(f"   - Critical: {sum(1 for f in findings if f['severity'] == 'Critical')}")
    print(f"   - High: {sum(1 for f in findings if f['severity'] == 'High')}")
    print(f"   - Medium: {sum(1 for f in findings if f['severity'] == 'Medium')}")
    
    return findings, target_info


def show_pipeline_steps():
    """Show the deep-thinking pipeline steps."""
    print_subsection("Deep-Thinking Pipeline Process")
    
    steps = [
        ("1. Planning", "Decompose query into structured multi-step research plan"),
        ("2. Retrieval", "Adaptive multi-stage retrieval (vector/keyword/hybrid)"),
        ("3. Refinement", "Cross-encoder reranking and evidence distillation"),
        ("4. Exploit Analysis", "Identify CVEs, exploits, and attack vectors"),
        ("5. Reflection", "Critique evidence quality and identify gaps"),
        ("6. Knowledge Graph", "Build relationships between vulnerabilities and exploits"),
        ("7. Report Generation", "Synthesize comprehensive pentest report")
    ]
    
    for step_name, description in steps:
        print(f"\n   {step_name}")
        print(f"      → {description}")


def show_exploit_analysis(findings):
    """Show how exploits would be analyzed."""
    print_subsection("Exploit Analysis (Simulated)")
    
    print("\n🔍 Analyzing findings for exploits...")
    
    exploits = []
    for finding in findings:
        if finding.get('cve'):
            exploit = {
                "name": finding['title'],
                "cve": finding.get('cve', 'N/A'),
                "severity": finding['severity'],
                "cvss_score": finding.get('cvss_score', 0.0),
                "description": finding['description'],
                "impact": finding.get('impact', ''),
                "source": "finding_analysis"
            }
            exploits.append(exploit)
    
    print(f"\n✅ Identified {len(exploits)} exploits:\n")
    
    for i, exploit in enumerate(exploits, 1):
        print(f"   {i}. {exploit['name']}")
        print(f"      CVE/CWE: {exploit['cve']}")
        print(f"      Severity: {exploit['severity']} (CVSS: {exploit['cvss_score']})")
        print(f"      Impact: {exploit['impact'][:80]}...")
        print()
    
    return exploits


def show_knowledge_graph(findings, exploits):
    """Show knowledge graph structure."""
    print_subsection("Knowledge Graph Construction")
    
    print("\n🕸️  Building knowledge graph from evidence and exploits...")
    
    # Simulate graph structure
    nodes = {
        "query": 1,
        "evidence": len(findings),
        "exploits": len(exploits),
        "cves": len([e for e in exploits if e.get('cve')]),
        "findings": len(findings)
    }
    
    edges = nodes["evidence"] + nodes["exploits"] + nodes["cves"]
    
    print(f"\n📊 Graph Statistics:")
    print(f"   - Total Nodes: {sum(nodes.values())}")
    print(f"   - Total Edges: {edges}")
    print(f"   - Node Types: {nodes}")
    
    print("\n🔗 Key Relationships:")
    print("   - Query → Evidence (retrieved_for)")
    print("   - Evidence → CVEs (mentions)")
    print("   - Exploits → CVEs (exploits)")
    print("   - Findings → Vulnerabilities (discovered_in)")
    print("   - CVEs → CWEs (related_to)")
    
    return {
        "nodes": sum(nodes.values()),
        "edges": edges,
        "node_types": nodes
    }


def generate_sample_report(findings, exploits, target_info):
    """Generate a sample report."""
    print_subsection("Report Generation")
    
    print("\n📝 Generating comprehensive pentest report...")
    
    report_content = f"""# Penetration Test Report

## Executive Summary

This report details the findings from a comprehensive penetration test conducted on the {target_info['name']}. 
The assessment identified {len(findings)} vulnerabilities, including {sum(1 for f in findings if f['severity'] == 'Critical')} critical, 
{sum(1 for f in findings if f['severity'] == 'High')} high, and {sum(1 for f in findings if f['severity'] == 'Medium')} medium severity issues.

**Target**: {target_info['name']} ({target_info['url']})  
**Assessment Date**: {datetime.now().strftime('%Y-%m-%d')}  
**Assessment Type**: External Penetration Test

## Methodology

- OWASP Testing Guide v4.1
- PTES (Penetration Testing Execution Standard)
- Automated scanning with Burp Suite Pro
- Manual testing and code review
- Deep-Thinking RAG Pipeline for analysis

## Findings

"""
    
    for i, finding in enumerate(findings, 1):
        report_content += f"""### Finding {i}: {finding['title']}

**Severity**: {finding['severity']} (CVSS: {finding['cvss_score']})  
**CVE/CWE**: {finding.get('cve', 'N/A')}  
**Location**: {finding['location']}

**Description**:  
{finding['description']}

**Impact**:  
{finding.get('impact', 'Not specified')}

**Proof of Concept**:  
```
{finding.get('proof_of_concept', 'N/A')}
```

**Remediation**:  
- Implement proper input validation and sanitization
- Use parameterized queries for database operations
- Apply principle of least privilege
- Deploy Web Application Firewall (WAF)
- Regular security testing and code reviews

---

"""
    
    report_content += f"""
## Exploits Identified

The following exploits were identified during the assessment:

"""
    
    for i, exploit in enumerate(exploits, 1):
        report_content += f"""### Exploit {i}: {exploit['name']}

- **CVE/CWE**: {exploit['cve']}
- **Severity**: {exploit['severity']}
- **CVSS Score**: {exploit['cvss_score']}
- **Description**: {exploit['description']}
- **Impact**: {exploit['impact']}

"""
    
    report_content += """
## Risk Assessment

### Overall Risk Rating: HIGH

The identified vulnerabilities pose significant risks to the application and its users:

1. **Critical SQL Injection** - Allows complete authentication bypass and potential data exfiltration
2. **High Severity XSS** - Enables session hijacking and account takeover
3. **High Severity IDOR** - Results in unauthorized data access
4. **High Severity SSRF** - Allows internal network probing
5. **Medium Security Misconfiguration** - Increases overall attack surface

### Business Impact

- **Data Breach Risk**: High - SQL injection and IDOR vulnerabilities could lead to data exposure
- **Service Disruption**: Medium - SSRF could potentially disrupt internal services
- **Reputation Damage**: High - Security incidents could damage customer trust
- **Compliance Issues**: High - May violate GDPR, PCI-DSS, and other regulations

## Recommendations

### Immediate Actions (Critical & High)

1. **Fix SQL Injection** (Priority 1)
   - Implement parameterized queries immediately
   - Deploy WAF as temporary mitigation
   - Conduct code review of all database queries

2. **Fix XSS Vulnerabilities** (Priority 2)
   - Implement output encoding
   - Deploy Content Security Policy (CSP)
   - Sanitize all user input

3. **Fix IDOR** (Priority 3)
   - Implement proper authorization checks
   - Use indirect object references
   - Validate user permissions for each resource

4. **Fix SSRF** (Priority 4)
   - Whitelist allowed URL patterns
   - Block private IP ranges
   - Implement URL validation

### Short-term Actions (Medium)

5. **Implement Security Headers**
   - Content-Security-Policy
   - X-Frame-Options: DENY
   - Strict-Transport-Security
   - X-Content-Type-Options: nosniff

### Long-term Actions

- Implement regular penetration testing (quarterly)
- Establish secure coding practices
- Deploy automated security scanning in CI/CD
- Conduct security training for developers
- Implement bug bounty program

## Knowledge Graph Insights

The knowledge graph analysis revealed:

- **{len(exploits)} exploits** linked to findings
- **{len([f for f in findings if f.get('cve')])} CVEs/CWEs** identified
- **Multiple relationships** between vulnerabilities and attack vectors
- **Similar patterns** found in other pentest reports

## Appendices

### A. Testing Tools Used

- Burp Suite Professional
- OWASP ZAP
- SQLMap
- Nmap
- Custom scripts

### B. References

- OWASP Top 10 (2021)
- CWE-89: SQL Injection
- CWE-79: Cross-site Scripting
- CWE-639: Authorization Bypass
- CWE-918: Server-Side Request Forgery
- CWE-693: Protection Mechanism Failure

### C. Report Generation

This report was generated using the Deep-Thinking RAG Pipeline, which:
- Analyzed findings using AI-powered reasoning
- Identified exploits and CVEs automatically
- Built knowledge graphs showing relationships
- Leveraged knowledge from similar pentest reports
- Synthesized comprehensive recommendations

---
*Report generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
"""
    
    return report_content


def save_outputs(report_content, findings, exploits, kg_stats):
    """Save all outputs to files."""
    print_subsection("Saving Outputs")
    
    output_dir = Path("./output")
    output_dir.mkdir(exist_ok=True)
    
    # Save report
    report_path = output_dir / "demo_pentest_report.md"
    with open(report_path, "w") as f:
        f.write(report_content)
    print(f"✅ Report saved: {report_path}")
    
    # Save findings as JSON
    findings_path = output_dir / "demo_findings.json"
    with open(findings_path, "w") as f:
        json.dump(findings, f, indent=2)
    print(f"✅ Findings saved: {findings_path}")
    
    # Save exploits
    exploits_path = output_dir / "demo_exploits.json"
    with open(exploits_path, "w") as f:
        json.dump(exploits, f, indent=2)
    print(f"✅ Exploits saved: {exploits_path}")
    
    # Save knowledge graph stats
    kg_path = output_dir / "demo_knowledge_graph_stats.json"
    with open(kg_path, "w") as f:
        json.dump(kg_stats, f, indent=2)
    print(f"✅ Knowledge graph stats saved: {kg_path}")
    
    # Create summary
    summary = {
        "timestamp": datetime.now().isoformat(),
        "findings_count": len(findings),
        "exploits_count": len(exploits),
        "knowledge_graph": kg_stats,
        "output_files": [
            str(report_path),
            str(findings_path),
            str(exploits_path),
            str(kg_path)
        ]
    }
    
    summary_path = output_dir / "demo_summary.json"
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"✅ Summary saved: {summary_path}")


def show_report_preview(report_content):
    """Show a preview of the generated report."""
    print_subsection("Report Preview")
    
    print("\n📄 First 1500 characters of generated report:")
    print("-" * 80)
    print(report_content[:1500])
    print("...")
    print("-" * 80)
    print(f"\n📊 Full report length: {len(report_content)} characters")


def main():
    """Run the complete demo."""
    print_section("=" * 80)
    print(" " * 20 + "LIVE DEMO: Deep-Thinking RAG Pipeline")
    print(" " * 15 + "Pentest Report Generation & Exploit Analysis")
    print("=" * 80)
    
    # Step 1: Define scenario
    findings, target_info = demo_scenario()
    
    # Step 2: Show pipeline process
    show_pipeline_steps()
    
    # Step 3: Analyze exploits
    exploits = show_exploit_analysis(findings)
    
    # Step 4: Build knowledge graph
    kg_stats = show_knowledge_graph(findings, exploits)
    
    # Step 5: Generate report
    report_content = generate_sample_report(findings, exploits, target_info)
    
    # Step 6: Save outputs
    save_outputs(report_content, findings, exploits, kg_stats)
    
    # Step 7: Show preview
    show_report_preview(report_content)
    
    # Final summary
    print_section("Demo Complete!")
    print("\n✅ Demo completed successfully!")
    print("\n📁 Generated Files (in ./output/):")
    print("   - demo_pentest_report.md (Full generated report)")
    print("   - demo_findings.json (Structured findings)")
    print("   - demo_exploits.json (Identified exploits)")
    print("   - demo_knowledge_graph_stats.json (KG statistics)")
    print("   - demo_summary.json (Complete summary)")
    print("\n💡 Next Steps:")
    print("   1. Review demo_pentest_report.md")
    print("   2. Check the JSON files for structured data")
    print("   3. To run with full AI capabilities, set OPENAI_API_KEY and run: python3 demo.py")
    print("\n" + "=" * 80)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Demo interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Error during demo: {e}")
        import traceback
        traceback.print_exc()

