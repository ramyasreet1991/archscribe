"""
Main entry point for the Deep-Thinking RAG Pipeline for Pentest Reports
"""

import os
import sys
from dotenv import load_dotenv
import logging
import json
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.pipeline.orchestrator import DeepThinkingRAGPipeline
from src.data.pentest_loader import PentestReportLoader
from src.retrieval.retrieval_system import RetrievalSystem
from langchain.text_splitter import RecursiveCharacterTextSplitter

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()


def initialize_pipeline():
    """Initialize the pipeline with configuration."""
    # Check for OpenAI API key
    if not os.getenv("OPENAI_API_KEY"):
        logger.error("OPENAI_API_KEY not found in environment variables")
        logger.info("Please set OPENAI_API_KEY in .env file or environment")
        return None
    
    pipeline = DeepThinkingRAGPipeline(
        llm_model="gpt-4-turbo-preview",
        temperature=0.3,
        vector_store_path="./vector_store"
    )
    
    return pipeline


def load_pentest_knowledge_base(pipeline: DeepThinkingRAGPipeline):
    """Load existing pentest reports into the knowledge base."""
    logger.info("Loading pentest knowledge base...")
    
    loader = PentestReportLoader()
    
    # Load from data directories
    data_dirs = ["./data/pentest_reports", "./data/public_pentest_reports"]
    
    all_documents = []
    for data_dir in data_dirs:
        if os.path.exists(data_dir):
            docs = loader.load_from_directory(data_dir)
            all_documents.extend(docs)
    
    # If no documents found, create sample data
    if not all_documents:
        logger.warning("No existing reports found. Creating sample knowledge base...")
        # Create sample documents from findings
        findings = loader.create_sample_findings()
        for finding in findings:
            content = f"""
            Vulnerability: {finding['title']}
            Type: {finding['type']}
            Severity: {finding['severity']}
            Description: {finding['description']}
            Location: {finding['location']}
            CVE/CWE: {finding.get('cve', 'N/A')}
            CVSS Score: {finding.get('cvss_score', 0.0)}
            
            This vulnerability was identified during a penetration test.
            Similar vulnerabilities have been found in other applications.
            """
            from langchain.schema import Document
            doc = Document(
                page_content=content,
                metadata={
                    "type": "pentest_finding",
                    "severity": finding['severity'],
                    "vulnerability_type": finding['type']
                }
            )
            all_documents.append(doc)
    
    # Split documents into chunks
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )
    
    split_docs = text_splitter.split_documents(all_documents)
    
    # Add to retrieval system
    pipeline.retrieval_system.add_documents(split_docs)
    
    logger.info(f"Loaded {len(split_docs)} document chunks into knowledge base")
    return len(split_docs)


def generate_pentest_report_example():
    """Example: Generate a pentest report from findings."""
    pipeline = initialize_pipeline()
    if not pipeline:
        return
    
    # Load knowledge base
    load_pentest_knowledge_base(pipeline)
    
    # Example findings
    findings = [
        {
            "title": "SQL Injection in User Authentication",
            "type": "SQL Injection",
            "severity": "Critical",
            "description": "The /api/auth/login endpoint is vulnerable to SQL injection. User input is directly concatenated into SQL queries without proper sanitization.",
            "location": "/api/auth/login",
            "cve": "CWE-89",
            "cvss_score": 9.8,
            "proof_of_concept": "Payload: admin' OR '1'='1'-- successfully bypasses authentication"
        },
        {
            "title": "Cross-Site Scripting (XSS) in Search Functionality",
            "type": "XSS",
            "severity": "High",
            "description": "The search endpoint does not properly sanitize user input, allowing XSS attacks.",
            "location": "/api/search",
            "cve": "CWE-79",
            "cvss_score": 7.2
        },
        {
            "title": "Missing Security Headers",
            "type": "Security Misconfiguration",
            "severity": "Medium",
            "description": "Application is missing Content-Security-Policy, X-Frame-Options, and other security headers.",
            "location": "All endpoints",
            "cve": "CWE-693",
            "cvss_score": 4.3
        }
    ]
    
    target_info = {
        "name": "Example Web Application",
        "type": "Web Application",
        "url": "https://example.com",
        "scope": "Web application and API endpoints"
    }
    
    logger.info("Generating pentest report...")
    result = pipeline.generate_pentest_report(
        findings=findings,
        target_info=target_info
    )
    
    # Save report
    output_dir = Path("./output")
    output_dir.mkdir(exist_ok=True)
    
    # Export report as markdown
    report_path = output_dir / "pentest_report.md"
    pipeline.report_generator.export_markdown(result["report"], str(report_path))
    logger.info(f"Report saved to: {report_path}")
    
    # Export knowledge graph
    if result.get("knowledge_graph"):
        kg_path = output_dir / "knowledge_graph.html"
        pipeline.kg_builder.visualize(str(kg_path))
        logger.info(f"Knowledge graph saved to: {kg_path}")
        
        kg_json_path = output_dir / "knowledge_graph.json"
        pipeline.kg_builder.export_json(str(kg_json_path))
        logger.info(f"Knowledge graph JSON saved to: {kg_json_path}")
    
    # Save full result as JSON
    result_path = output_dir / "full_result.json"
    # Convert graph to serializable format
    result_copy = result.copy()
    if "knowledge_graph" in result_copy and "graph" in result_copy["knowledge_graph"]:
        # Remove NetworkX graph object (not JSON serializable)
        result_copy["knowledge_graph"]["graph"] = "NetworkX graph (see HTML/JSON exports)"
    
    with open(result_path, "w") as f:
        json.dump(result_copy, f, indent=2, default=str)
    
    logger.info(f"Full result saved to: {result_path}")
    
    # Print summary
    print("\n" + "="*80)
    print("PENTEST REPORT GENERATION COMPLETE")
    print("="*80)
    print(f"Query: {result['query']}")
    print(f"Iterations: {result['iterations']}")
    print(f"Evidence collected: {len(result['evidence'])} documents")
    print(f"Exploits identified: {len(result['exploits'])}")
    if result.get("knowledge_graph", {}).get("stats"):
        stats = result["knowledge_graph"]["stats"]
        print(f"Knowledge graph: {stats.get('nodes', 0)} nodes, {stats.get('edges', 0)} edges")
    print(f"\nReport saved to: {report_path}")
    print("="*80 + "\n")


def query_exploits_example():
    """Example: Query for exploits related to a vulnerability."""
    pipeline = initialize_pipeline()
    if not pipeline:
        return
    
    # Load knowledge base
    load_pentest_knowledge_base(pipeline)
    
    query = "Find exploits for SQL injection vulnerabilities in web applications. Include CVEs, proof-of-concept code, and remediation strategies."
    
    logger.info(f"Processing query: {query}")
    result = pipeline.process_query(query)
    
    print("\n" + "="*80)
    print("EXPLOIT ANALYSIS RESULTS")
    print("="*80)
    print(f"Exploits identified: {len(result['exploits'])}")
    for i, exploit in enumerate(result['exploits'], 1):
        print(f"\n{i}. {exploit.get('name', 'Unknown')}")
        print(f"   CVE: {exploit.get('cve', 'N/A')}")
        print(f"   Severity: {exploit.get('severity', 'Unknown')}")
        print(f"   Description: {exploit.get('description', '')[:200]}...")
    print("="*80 + "\n")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Deep-Thinking RAG Pipeline for Pentest Reports")
    parser.add_argument(
        "--mode",
        choices=["report", "query", "both"],
        default="report",
        help="Operation mode: generate report, query exploits, or both"
    )
    
    args = parser.parse_args()
    
    if args.mode == "report":
        generate_pentest_report_example()
    elif args.mode == "query":
        query_exploits_example()
    else:
        generate_pentest_report_example()
        print("\n" + "-"*80 + "\n")
        query_exploits_example()

