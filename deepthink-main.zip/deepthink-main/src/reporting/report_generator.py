"""
Report Generator: Creates comprehensive pentest reports with deep-thinking synthesis
"""

from typing import List, Dict, Any, Optional
from langchain.prompts import ChatPromptTemplate
from datetime import datetime
import json
import logging

logger = logging.getLogger(__name__)


class ReportGenerator:
    """
    Generates comprehensive penetration test reports by synthesizing
    evidence, exploits, and knowledge graph insights.
    """
    
    REPORT_GENERATION_PROMPT = ChatPromptTemplate.from_messages([
        ("system", """You are an expert penetration testing report writer. Your task is to
create a comprehensive, professional penetration test report that:

1. Executive Summary: High-level overview for management
2. Methodology: Testing approach and tools used
3. Findings: Detailed vulnerability analysis with:
   - Description
   - Severity and CVSS scores
   - Proof of concept
   - Impact assessment
   - Remediation recommendations
4. Exploits: Detailed exploit analysis
5. Risk Assessment: Overall risk posture
6. Recommendations: Prioritized remediation steps
7. Appendices: Technical details, references, knowledge graph insights

The report should be professional, actionable, and suitable for both technical
and executive audiences. Leverage the knowledge graph to show relationships
between vulnerabilities and exploits."""),
        ("human", """Generate a comprehensive penetration test report based on:

Query/Objective: {query}

Evidence Collected:
{evidence_summary}

Exploits Identified:
{exploits_summary}

Knowledge Graph Insights:
{kg_insights}

Context:
{context}

Create a detailed, professional report following industry standards (OWASP, PTES, etc.)."""),
    ])
    
    def __init__(self, llm):
        """Initialize the report generator."""
        self.llm = llm
    
    def generate(
        self,
        query: str,
        evidence: List[Dict[str, Any]],
        exploits: List[Dict[str, Any]],
        knowledge_graph: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Generate a comprehensive pentest report.
        
        Args:
            query: Original query/objective
            evidence: Collected evidence
            exploits: Identified exploits
            knowledge_graph: Knowledge graph structure
            context: Optional context (findings, target info)
            
        Returns:
            Complete report structure
        """
        # Prepare summaries
        evidence_summary = self._summarize_evidence(evidence)
        exploits_summary = self._summarize_exploits(exploits)
        kg_insights = self._extract_kg_insights(knowledge_graph)
        
        context_str = json.dumps(context, indent=2) if context else "None"
        
        messages = self.REPORT_GENERATION_PROMPT.format_messages(
            query=query,
            evidence_summary=evidence_summary,
            exploits_summary=exploits_summary,
            kg_insights=kg_insights,
            context=context_str
        )
        
        try:
            response = self.llm.invoke(messages)
            report_content = response.content
            
            # Structure the report
            report = self._structure_report(
                report_content,
                evidence,
                exploits,
                knowledge_graph,
                context
            )
            
            return report
        except Exception as e:
            logger.error(f"Error generating report: {e}")
            return {
                "error": str(e),
                "content": "Failed to generate report"
            }
    
    def _summarize_evidence(self, evidence: List[Dict[str, Any]]) -> str:
        """Create a summary of evidence for the report."""
        if not evidence:
            return "No evidence collected."
        
        summaries = []
        for i, doc in enumerate(evidence[:10], 1):  # Top 10
            content = doc.get("content", "")[:300]
            score = doc.get("rerank_score", doc.get("score", 0))
            summaries.append(f"{i}. [Relevance: {score:.3f}] {content}...")
        
        return "\n".join(summaries)
    
    def _summarize_exploits(self, exploits: List[Dict[str, Any]]) -> str:
        """Create a summary of exploits for the report."""
        if not exploits:
            return "No exploits identified."
        
        summaries = []
        for i, exploit in enumerate(exploits, 1):
            name = exploit.get("name", "Unknown")
            severity = exploit.get("severity", "Unknown")
            cve = exploit.get("cve", "N/A")
            description = exploit.get("description", "")[:200]
            
            summaries.append(
                f"{i}. {name} (CVE: {cve}, Severity: {severity})\n"
                f"   {description}..."
            )
        
        return "\n".join(summaries)
    
    def _extract_kg_insights(self, knowledge_graph: Dict[str, Any]) -> str:
        """Extract insights from the knowledge graph."""
        if not knowledge_graph or "stats" not in knowledge_graph:
            return "No knowledge graph insights available."
        
        stats = knowledge_graph.get("stats", {})
        central_nodes = stats.get("central_nodes", [])
        
        insights = [
            f"Knowledge Graph Statistics:",
            f"- Total Nodes: {stats.get('nodes', 0)}",
            f"- Total Relationships: {stats.get('edges', 0)}",
            f"- Node Types: {stats.get('node_types', {})}",
        ]
        
        if central_nodes:
            insights.append("\nKey Entities:")
            for node in central_nodes[:5]:
                insights.append(f"- {node.get('type', 'unknown')}: {node.get('node', '')}")
        
        return "\n".join(insights)
    
    def _structure_report(
        self,
        content: str,
        evidence: List[Dict[str, Any]],
        exploits: List[Dict[str, Any]],
        knowledge_graph: Dict[str, Any],
        context: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Structure the report with metadata and sections."""
        report = {
            "metadata": {
                "generated_at": datetime.now().isoformat(),
                "query": context.get("query") if context else "N/A",
                "target": context.get("target_info", {}).get("name", "Unknown") if context else "Unknown",
                "evidence_count": len(evidence),
                "exploit_count": len(exploits),
                "kg_nodes": knowledge_graph.get("stats", {}).get("nodes", 0) if knowledge_graph else 0
            },
            "content": content,
            "sections": self._extract_sections(content),
            "executive_summary": self._extract_executive_summary(content),
            "findings": self._extract_findings(content, exploits),
            "exploits": exploits,
            "recommendations": self._extract_recommendations(content),
            "knowledge_graph": knowledge_graph
        }
        
        return report
    
    def _extract_sections(self, content: str) -> Dict[str, str]:
        """Extract major sections from the report content."""
        sections = {}
        current_section = None
        current_content = []
        
        lines = content.split("\n")
        for line in lines:
            # Detect section headers (markdown style)
            if line.startswith("#"):
                if current_section:
                    sections[current_section] = "\n".join(current_content)
                current_section = line.lstrip("#").strip()
                current_content = []
            else:
                current_content.append(line)
        
        if current_section:
            sections[current_section] = "\n".join(current_content)
        
        return sections
    
    def _extract_executive_summary(self, content: str) -> str:
        """Extract executive summary section."""
        # Look for executive summary section
        if "executive summary" in content.lower():
            start_idx = content.lower().find("executive summary")
            # Find next major section
            remaining = content[start_idx:]
            for marker in ["\n## ", "\n# ", "\n\n## "]:
                if marker in remaining:
                    end_idx = remaining.find(marker)
                    return remaining[:end_idx].strip()
            return remaining.strip()
        
        # Fallback: first 500 characters
        return content[:500] + "..."
    
    def _extract_findings(
        self,
        content: str,
        exploits: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Extract findings from report content and exploits."""
        findings = []
        
        # Use exploits as findings
        for exploit in exploits:
            findings.append({
                "title": exploit.get("name", "Unknown Vulnerability"),
                "severity": exploit.get("severity", "Unknown"),
                "cve": exploit.get("cve", "N/A"),
                "description": exploit.get("description", ""),
                "cvss_score": exploit.get("cvss_score", 0.0)
            })
        
        return findings
    
    def _extract_recommendations(self, content: str) -> List[str]:
        """Extract recommendations from report content."""
        recommendations = []
        
        # Look for recommendations section
        if "recommendation" in content.lower():
            start_idx = content.lower().find("recommendation")
            remaining = content[start_idx:]
            
            # Extract bullet points or numbered items
            lines = remaining.split("\n")
            for line in lines[:50]:  # Limit search
                line = line.strip()
                if line and (line.startswith("-") or line.startswith("*") or 
                           line[0].isdigit() and "." in line[:3]):
                    rec = line.lstrip("-*0123456789. ").strip()
                    if rec and len(rec) > 10:  # Filter out very short items
                        recommendations.append(rec)
        
        return recommendations[:10]  # Limit to 10 recommendations
    
    def export_markdown(self, report: Dict[str, Any], output_path: str):
        """Export report as Markdown file."""
        content = report.get("content", "")
        metadata = report.get("metadata", {})
        
        # Add metadata header
        markdown = f"""---
title: Penetration Test Report
generated_at: {metadata.get('generated_at', 'Unknown')}
target: {metadata.get('target', 'Unknown')}
evidence_count: {metadata.get('evidence_count', 0)}
exploit_count: {metadata.get('exploit_count', 0)}
---

{content}
"""
        
        with open(output_path, "w") as f:
            f.write(markdown)
        
        logger.info(f"Report exported to: {output_path}")

