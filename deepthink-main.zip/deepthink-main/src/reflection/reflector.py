"""
Reflection Agent: Critiques evidence and decides when to synthesize
"""

from typing import List, Dict, Any
from langchain.prompts import ChatPromptTemplate
import logging

logger = logging.getLogger(__name__)


class ReflectionAgent:
    """
    Reflects on retrieved evidence and exploits to:
    1. Critique the quality and completeness
    2. Identify gaps in knowledge
    3. Decide when to synthesize vs. continue searching
    """
    
    REFLECTION_PROMPT = ChatPromptTemplate.from_messages([
        ("system", """You are a critical security analyst reviewing evidence and exploits
for a penetration test report. Your task is to:

1. Evaluate the quality and relevance of the evidence
2. Identify gaps in knowledge (missing CVEs, exploits, similar reports)
3. Assess if enough information exists to generate a comprehensive report
4. Provide specific guidance on what additional information would be valuable

Consider:
- Are all vulnerabilities properly analyzed?
- Are exploit vectors identified?
- Are similar pentest reports referenced?
- Is risk assessment complete?
- Are remediation recommendations feasible?

Output your reflection as structured feedback."""),
        ("human", """Query: {query}

Current Evidence:
{evidence}

Identified Exploits:
{exploits}

Iteration: {iteration}

Critique this evidence and decide:
1. Is the evidence sufficient to answer the query comprehensively?
2. What gaps exist in the current knowledge?
3. Should we continue searching or synthesize the report now?
4. What specific information should be retrieved next (if continuing)?"""),
    ])
    
    def __init__(self, llm):
        """Initialize the reflection agent."""
        self.llm = llm
    
    def reflect(
        self,
        query: str,
        evidence: List[Dict[str, Any]],
        exploits: List[Dict[str, Any]],
        iteration: int
    ) -> Dict[str, Any]:
        """
        Reflect on the current state and provide critique.
        
        Args:
            query: Original query
            evidence: Current evidence
            exploits: Identified exploits
            iteration: Current iteration number
            
        Returns:
            Reflection with critique and decision
        """
        # Prepare evidence summary
        evidence_summary = self._summarize_evidence(evidence)
        exploits_summary = self._summarize_exploits(exploits)
        
        messages = self.REFLECTION_PROMPT.format_messages(
            query=query,
            evidence=evidence_summary,
            exploits=exploits_summary,
            iteration=iteration
        )
        
        try:
            response = self.llm.invoke(messages)
            reflection_text = response.content
            
            # Parse reflection (try to extract structured info)
            reflection = self._parse_reflection(reflection_text)
            reflection["raw_text"] = reflection_text
            
            return reflection
        except Exception as e:
            logger.error(f"Reflection error: {e}")
            return {
                "should_synthesize": iteration >= 2,
                "gaps": [],
                "quality_score": 0.5,
                "feedback": f"Error during reflection: {e}"
            }
    
    def _summarize_evidence(self, evidence: List[Dict[str, Any]]) -> str:
        """Create a summary of evidence for reflection."""
        if not evidence:
            return "No evidence retrieved yet."
        
        summaries = []
        for i, doc in enumerate(evidence[:5], 1):  # Top 5
            content_preview = doc.get("content", "")[:200]
            score = doc.get("rerank_score", doc.get("score", 0))
            summaries.append(
                f"{i}. [Score: {score:.3f}] {content_preview}..."
            )
        
        return "\n".join(summaries)
    
    def _summarize_exploits(self, exploits: List[Dict[str, Any]]) -> str:
        """Create a summary of exploits for reflection."""
        if not exploits:
            return "No exploits identified yet."
        
        summaries = []
        for i, exploit in enumerate(exploits, 1):
            name = exploit.get("name", "Unknown")
            severity = exploit.get("severity", "Unknown")
            summaries.append(f"{i}. {name} (Severity: {severity})")
        
        return "\n".join(summaries)
    
    def _parse_reflection(self, reflection_text: str) -> Dict[str, Any]:
        """Parse reflection text to extract structured information."""
        # Simple heuristic parsing
        reflection_lower = reflection_text.lower()
        
        # Determine if should synthesize
        should_synthesize = any(
            phrase in reflection_lower
            for phrase in ["sufficient", "enough information", "comprehensive", "complete"]
        ) and not any(
            phrase in reflection_lower
            for phrase in ["insufficient", "missing", "gap", "need more"]
        )
        
        # Extract gaps (look for common patterns)
        gaps = []
        if "missing" in reflection_lower or "gap" in reflection_lower:
            # Try to extract specific gaps
            lines = reflection_text.split("\n")
            for line in lines:
                if any(word in line.lower() for word in ["missing", "gap", "need"]):
                    gaps.append(line.strip())
        
        # Quality score heuristic
        quality_score = 0.7  # Default
        if "high quality" in reflection_lower or "excellent" in reflection_lower:
            quality_score = 0.9
        elif "low quality" in reflection_lower or "poor" in reflection_lower:
            quality_score = 0.3
        
        return {
            "should_synthesize": should_synthesize,
            "gaps": gaps[:5],  # Limit to 5 gaps
            "quality_score": quality_score,
            "feedback": reflection_text
        }

