"""
Multi-Stage Retrieval System with Adaptive Strategy Selection
Supports vector search, keyword search (BM25), and hybrid approaches
"""

from typing import List, Dict, Any, Optional
try:
    from langchain_community.vectorstores import Chroma
    from langchain_community.embeddings import HuggingFaceEmbeddings
except ImportError:
    from langchain.vectorstores import Chroma
    from langchain.embeddings import HuggingFaceEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
import chromadb
from rank_bm25 import BM25Okapi
import numpy as np
import logging

logger = logging.getLogger(__name__)


class RetrievalSystem:
    """
    Adaptive retrieval system that selects the best search strategy
    based on query characteristics and uses a supervisor to combine results.
    """
    
    def __init__(
        self,
        vector_store_path: str = "./vector_store",
        embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    ):
        """Initialize the retrieval system."""
        self.embeddings = HuggingFaceEmbeddings(model_name=embedding_model)
        self.vector_store_path = vector_store_path
        
        # Initialize vector store
        try:
            self.vector_store = Chroma(
                persist_directory=vector_store_path,
                embedding_function=self.embeddings
            )
        except Exception as e:
            logger.warning(f"Could not load existing vector store: {e}")
            self.vector_store = None
        
        # BM25 for keyword search
        self.bm25_index = None
        self.documents = []
        
        logger.info("Retrieval system initialized")
    
    def add_documents(self, documents: List[Document]):
        """Add documents to both vector store and BM25 index."""
        if not documents:
            return
        
        self.documents.extend(documents)
        
        # Add to vector store
        if self.vector_store is None:
            self.vector_store = Chroma.from_documents(
                documents=documents,
                embedding=self.embeddings,
                persist_directory=self.vector_store_path
            )
        else:
            self.vector_store.add_documents(documents)
        
        # Update BM25 index
        texts = [doc.page_content for doc in documents]
        tokenized_texts = [text.lower().split() for text in texts]
        self.bm25_index = BM25Okapi(tokenized_texts)
        
        logger.info(f"Added {len(documents)} documents to retrieval system")
    
    def retrieve(
        self,
        query: str,
        tool: str = "hybrid",
        top_k: int = 20
    ) -> List[Dict[str, Any]]:
        """
        Retrieve relevant documents using the specified tool.
        
        Args:
            query: Search query
            tool: "vector", "keyword", or "hybrid"
            top_k: Number of results to return
            
        Returns:
            List of retrieved documents with metadata
        """
        if tool == "vector":
            return self._vector_search(query, top_k)
        elif tool == "keyword":
            return self._keyword_search(query, top_k)
        else:  # hybrid
            return self._hybrid_search(query, top_k)
    
    def _vector_search(self, query: str, top_k: int) -> List[Dict[str, Any]]:
        """Perform vector similarity search."""
        if self.vector_store is None:
            logger.warning("Vector store not initialized, returning empty results")
            return []
        
        try:
            results = self.vector_store.similarity_search_with_score(query, k=top_k)
            return [
                {
                    "content": doc.page_content,
                    "metadata": doc.metadata,
                    "score": score,
                    "method": "vector"
                }
                for doc, score in results
            ]
        except Exception as e:
            logger.error(f"Vector search error: {e}")
            return []
    
    def _keyword_search(self, query: str, top_k: int) -> List[Dict[str, Any]]:
        """Perform BM25 keyword search."""
        if self.bm25_index is None or not self.documents:
            logger.warning("BM25 index not initialized, returning empty results")
            return []
        
        try:
            tokenized_query = query.lower().split()
            scores = self.bm25_index.get_scores(tokenized_query)
            
            # Get top_k indices
            top_indices = np.argsort(scores)[::-1][:top_k]
            
            results = []
            for idx in top_indices:
                if scores[idx] > 0:  # Only include non-zero scores
                    results.append({
                        "content": self.documents[idx].page_content,
                        "metadata": self.documents[idx].metadata,
                        "score": float(scores[idx]),
                        "method": "keyword"
                    })
            
            return results
        except Exception as e:
            logger.error(f"Keyword search error: {e}")
            return []
    
    def _hybrid_search(self, query: str, top_k: int) -> List[Dict[str, Any]]:
        """Perform hybrid search combining vector and keyword results."""
        vector_results = self._vector_search(query, top_k * 2)
        keyword_results = self._keyword_search(query, top_k * 2)
        
        # Combine and rerank using reciprocal rank fusion
        combined = self._reciprocal_rank_fusion(
            vector_results,
            keyword_results,
            top_k
        )
        
        return combined
    
    def _reciprocal_rank_fusion(
        self,
        list1: List[Dict[str, Any]],
        list2: List[Dict[str, Any]],
        top_k: int,
        k: int = 60
    ) -> List[Dict[str, Any]]:
        """
        Combine two ranked lists using Reciprocal Rank Fusion (RRF).
        
        Args:
            list1: First ranked list
            list2: Second ranked list
            top_k: Number of results to return
            k: RRF constant (typically 60)
        """
        # Create content-based index to deduplicate
        content_to_doc = {}
        
        # Process list1
        for rank, doc in enumerate(list1, 1):
            content = doc["content"]
            if content not in content_to_doc:
                content_to_doc[content] = doc.copy()
                content_to_doc[content]["rrf_score"] = 0
            content_to_doc[content]["rrf_score"] += 1 / (k + rank)
        
        # Process list2
        for rank, doc in enumerate(list2, 1):
            content = doc["content"]
            if content not in content_to_doc:
                content_to_doc[content] = doc.copy()
                content_to_doc[content]["rrf_score"] = 0
            content_to_doc[content]["rrf_score"] += 1 / (k + rank)
        
        # Sort by RRF score and return top_k
        sorted_docs = sorted(
            content_to_doc.values(),
            key=lambda x: x["rrf_score"],
            reverse=True
        )
        
        return sorted_docs[:top_k]
    
    def select_best_tool(self, query: str) -> str:
        """
        Supervisory function to select the best retrieval tool.
        
        Args:
            query: The search query
            
        Returns:
            Recommended tool: "vector", "keyword", or "hybrid"
        """
        # Simple heuristic: use keyword for specific terms, vector for semantic queries
        query_lower = query.lower()
        
        # Keywords that suggest keyword search
        specific_terms = ["cve-", "exploit", "cwe-", "api", "endpoint", "version"]
        has_specific_terms = any(term in query_lower for term in specific_terms)
        
        # Long queries or complex questions suggest vector search
        is_complex = len(query.split()) > 10 or "?" in query
        
        if has_specific_terms and not is_complex:
            return "keyword"
        elif is_complex and not has_specific_terms:
            return "vector"
        else:
            return "hybrid"

