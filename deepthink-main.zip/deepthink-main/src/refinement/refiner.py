"""
Refinement System: Cross-encoder reranking and evidence distillation
"""

from typing import List, Dict, Any
from langchain.prompts import ChatPromptTemplate
from sentence_transformers import CrossEncoder
import logging

logger = logging.getLogger(__name__)


class RefinementSystem:
    """
    Refines retrieved evidence through:
    1. Cross-encoder reranking for precision
    2. Distillation to compress best evidence
    """
    
    DISTILLATION_PROMPT = ChatPromptTemplate.from_messages([
        ("system", """You are an expert at distilling security information. Your task is to
compress multiple pieces of evidence into concise, actionable insights while preserving
critical details about vulnerabilities, exploits, and remediation strategies.

Focus on:
- Key vulnerability details (type, severity, CVEs)
- Exploit vectors and attack methods
- Risk assessment
- Remediation recommendations
- Relationships to similar findings"""),
        ("human", """Query: {query}

Evidence to distill:
{evidence}

Create a concise summary that captures the most important information
for answering the query and generating a pentest report."""),
    ])
    
    def __init__(
        self,
        llm,
        rerank_model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"
    ):
        """Initialize the refinement system."""
        self.llm = llm
        try:
            self.reranker = CrossEncoder(rerank_model)
        except Exception as e:
            logger.warning(f"Could not load reranker model: {e}")
            self.reranker = None
    
    def refine(
        self,
        query: str,
        evidence: List[Dict[str, Any]],
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Refine evidence through reranking and distillation.
        
        Args:
            query: Original query
            evidence: Retrieved evidence documents
            top_k: Number of top results to keep
            
        Returns:
            Refined and distilled evidence
        """
        if not evidence:
            return []
        
        # Step 1: Rerank using cross-encoder
        reranked = self._rerank(query, evidence, top_k)
        
        # Step 2: Distill top results
        distilled = self._distill(query, reranked)
        
        return distilled
    
    def _rerank(
        self,
        query: str,
        evidence: List[Dict[str, Any]],
        top_k: int
    ) -> List[Dict[str, Any]]:
        """Rerank evidence using cross-encoder for better precision."""
        if self.reranker is None or not evidence:
            # Fallback: return top_k by existing score
            return sorted(
                evidence,
                key=lambda x: x.get("score", 0) or x.get("rrf_score", 0),
                reverse=True
            )[:top_k]
        
        try:
            # Prepare pairs for cross-encoder
            pairs = [
                [query, doc["content"]]
                for doc in evidence
            ]
            
            # Get reranking scores
            scores = self.reranker.predict(pairs)
            
            # Add rerank scores and sort
            for i, doc in enumerate(evidence):
                doc["rerank_score"] = float(scores[i])
            
            # Sort by rerank score
            reranked = sorted(
                evidence,
                key=lambda x: x.get("rerank_score", 0),
                reverse=True
            )
            
            return reranked[:top_k]
        except Exception as e:
            logger.error(f"Reranking error: {e}")
            # Fallback to original ranking
            return sorted(
                evidence,
                key=lambda x: x.get("score", 0) or x.get("rrf_score", 0),
                reverse=True
            )[:top_k]
    
    def _distill(
        self,
        query: str,
        evidence: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Distill evidence into concise summaries."""
        if not evidence:
            return []
        
        # Prepare evidence text
        evidence_text = "\n\n---\n\n".join([
            f"Document {i+1} (Score: {doc.get('rerank_score', doc.get('score', 0)):.3f}):\n"
            f"{doc['content'][:1000]}..."  # Truncate for prompt
            for i, doc in enumerate(evidence)
        ])
        
        messages = self.DISTILLATION_PROMPT.format_messages(
            query=query,
            evidence=evidence_text
        )
        
        try:
            response = self.llm.invoke(messages)
            distilled_summary = response.content
            
            # Create distilled document
            distilled_doc = {
                "content": distilled_summary,
                "metadata": {
                    "type": "distilled",
                    "source_count": len(evidence),
                    "original_scores": [doc.get("rerank_score", doc.get("score", 0)) for doc in evidence]
                },
                "score": max(doc.get("rerank_score", doc.get("score", 0)) for doc in evidence),
                "method": "distilled",
                "original_evidence": evidence
            }
            
            return [distilled_doc] + evidence[:3]  # Return distilled + top 3 original
        except Exception as e:
            logger.error(f"Distillation error: {e}")
            return evidence

