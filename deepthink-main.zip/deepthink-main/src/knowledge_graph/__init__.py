# Knowledge graph builder for pentest reports and exploits

