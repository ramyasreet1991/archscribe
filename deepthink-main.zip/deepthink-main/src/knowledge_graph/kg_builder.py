"""
Knowledge Graph Builder: Creates structured knowledge graphs from pentest evidence
"""

from typing import List, Dict, Any, Optional
import networkx as nx
from pyvis.network import Network
import json
import logging
import re

logger = logging.getLogger(__name__)


class KnowledgeGraphBuilder:
    """
    Builds knowledge graphs from pentest evidence, exploits, and findings.
    Captures relationships between vulnerabilities, exploits, CVEs, and similar reports.
    """
    
    def __init__(self, kg_type: str = "networkx"):
        """
        Initialize the knowledge graph builder.
        
        Args:
            kg_type: "networkx" or "neo4j"
        """
        self.kg_type = kg_type
        self.graph = nx.MultiDiGraph() if kg_type == "networkx" else None
        
        # Entity extraction patterns
        self.cve_pattern = re.compile(r'CVE-\d{4}-\d{4,7}', re.IGNORECASE)
        self.cwe_pattern = re.compile(r'CWE-\d+', re.IGNORECASE)
        self.cvss_pattern = re.compile(r'CVSS:\s*(\d+\.\d+)', re.IGNORECASE)
        
        logger.info(f"Knowledge graph builder initialized with type: {kg_type}")
    
    def build_graph(
        self,
        evidence: List[Dict[str, Any]],
        exploits: List[Dict[str, Any]],
        query: str,
        findings: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Build a knowledge graph from evidence, exploits, and findings.
        
        Args:
            evidence: Retrieved evidence documents
            exploits: Identified exploits
            query: Original query
            findings: Optional pentest findings
            
        Returns:
            Knowledge graph structure
        """
        if self.kg_type == "networkx":
            return self._build_networkx_graph(evidence, exploits, query, findings)
        else:
            return self._build_neo4j_graph(evidence, exploits, query, findings)
    
    def _build_networkx_graph(
        self,
        evidence: List[Dict[str, Any]],
        exploits: List[Dict[str, Any]],
        query: str,
        findings: Optional[List[Dict[str, Any]]]
    ) -> Dict[str, Any]:
        """Build a NetworkX knowledge graph."""
        self.graph = nx.MultiDiGraph()
        
        # Add query as central node
        self.graph.add_node("query", type="query", label=query[:50])
        
        # Process evidence
        for i, doc in enumerate(evidence):
            doc_id = f"evidence_{i}"
            self.graph.add_node(
                doc_id,
                type="evidence",
                content=doc.get("content", "")[:200],
                score=doc.get("score", 0)
            )
            self.graph.add_edge("query", doc_id, relation="retrieved_for")
            
            # Extract entities from evidence
            entities = self._extract_entities(doc.get("content", ""))
            for entity_type, entity_value in entities:
                entity_id = f"{entity_type}_{entity_value}"
                self.graph.add_node(
                    entity_id,
                    type=entity_type,
                    value=entity_value
                )
                self.graph.add_edge(doc_id, entity_id, relation="mentions")
        
        # Process exploits
        for i, exploit in enumerate(exploits):
            exploit_id = f"exploit_{i}"
            self.graph.add_node(
                exploit_id,
                type="exploit",
                name=exploit.get("name", "Unknown"),
                severity=exploit.get("severity", "Unknown"),
                description=exploit.get("description", "")
            )
            self.graph.add_edge("query", exploit_id, relation="identified_for")
            
            # Link exploits to CVEs
            if "cve" in exploit:
                cve_id = f"cve_{exploit['cve']}"
                if not self.graph.has_node(cve_id):
                    self.graph.add_node(cve_id, type="cve", value=exploit["cve"])
                self.graph.add_edge(exploit_id, cve_id, relation="exploits")
        
        # Process findings
        if findings:
            for i, finding in enumerate(findings):
                finding_id = f"finding_{i}"
                self.graph.add_node(
                    finding_id,
                    type="finding",
                    title=finding.get("title", "Unknown"),
                    severity=finding.get("severity", "Unknown")
                )
                self.graph.add_edge("query", finding_id, relation="discovered_in")
        
        # Build relationships between entities
        self._build_entity_relationships()
        
        # Calculate graph statistics
        stats = {
            "nodes": self.graph.number_of_nodes(),
            "edges": self.graph.number_of_edges(),
            "node_types": self._get_node_type_distribution(),
            "central_nodes": self._get_central_nodes()
        }
        
        return {
            "graph": self.graph,
            "stats": stats,
            "type": "networkx"
        }
    
    def _extract_entities(self, text: str) -> List[tuple]:
        """Extract security-related entities from text."""
        entities = []
        
        # Extract CVEs
        cves = self.cve_pattern.findall(text)
        for cve in set(cves):
            entities.append(("cve", cve.upper()))
        
        # Extract CWEs
        cwes = self.cwe_pattern.findall(text)
        for cwe in set(cwes):
            entities.append(("cwe", cwe.upper()))
        
        # Extract CVSS scores
        cvss_matches = self.cvss_pattern.findall(text)
        for cvss in set(cvss_matches):
            entities.append(("cvss", cvss))
        
        # Extract common vulnerability types
        vuln_types = [
            "sql injection", "xss", "csrf", "ssrf", "xxe",
            "path traversal", "command injection", "rce",
            "authentication bypass", "authorization bypass"
        ]
        text_lower = text.lower()
        for vuln_type in vuln_types:
            if vuln_type in text_lower:
                entities.append(("vulnerability_type", vuln_type))
        
        return entities
    
    def _build_entity_relationships(self):
        """Build relationships between extracted entities."""
        # Find all CVE nodes
        cve_nodes = [n for n in self.graph.nodes() if self.graph.nodes[n].get("type") == "cve"]
        cwe_nodes = [n for n in self.graph.nodes() if self.graph.nodes[n].get("type") == "cwe"]
        
        # Link CVEs to CWEs if they share evidence
        for cve_node in cve_nodes:
            cve_predecessors = list(self.graph.predecessors(cve_node))
            for cwe_node in cwe_nodes:
                cwe_predecessors = list(self.graph.predecessors(cwe_node))
                # If they share a common evidence node, link them
                if set(cve_predecessors) & set(cwe_predecessors):
                    self.graph.add_edge(cve_node, cwe_node, relation="related_to")
    
    def _get_node_type_distribution(self) -> Dict[str, int]:
        """Get distribution of node types in the graph."""
        distribution = {}
        for node in self.graph.nodes():
            node_type = self.graph.nodes[node].get("type", "unknown")
            distribution[node_type] = distribution.get(node_type, 0) + 1
        return distribution
    
    def _get_central_nodes(self, top_k: int = 5) -> List[Dict[str, Any]]:
        """Get the most central nodes in the graph."""
        if self.graph.number_of_nodes() == 0:
            return []
        
        try:
            # Calculate centrality
            centrality = nx.degree_centrality(self.graph)
            sorted_nodes = sorted(
                centrality.items(),
                key=lambda x: x[1],
                reverse=True
            )[:top_k]
            
            return [
                {
                    "node": node,
                    "centrality": score,
                    "type": self.graph.nodes[node].get("type", "unknown")
                }
                for node, score in sorted_nodes
            ]
        except Exception as e:
            logger.error(f"Error calculating centrality: {e}")
            return []
    
    def _build_neo4j_graph(
        self,
        evidence: List[Dict[str, Any]],
        exploits: List[Dict[str, Any]],
        query: str,
        findings: Optional[List[Dict[str, Any]]]
    ) -> Dict[str, Any]:
        """Build a Neo4j knowledge graph (placeholder for Neo4j implementation)."""
        # This would require Neo4j driver setup
        logger.warning("Neo4j implementation not yet complete, using NetworkX")
        return self._build_networkx_graph(evidence, exploits, query, findings)
    
    def visualize(self, output_path: str = "knowledge_graph.html"):
        """Visualize the knowledge graph using Pyvis."""
        if self.graph is None or self.graph.number_of_nodes() == 0:
            logger.warning("No graph to visualize")
            return
        
        net = Network(height="800px", width="100%", directed=True)
        
        # Add nodes with styling
        for node in self.graph.nodes():
            node_data = self.graph.nodes[node]
            node_type = node_data.get("type", "unknown")
            
            # Color coding by type
            color_map = {
                "query": "#FF6B6B",
                "evidence": "#4ECDC4",
                "exploit": "#FFE66D",
                "cve": "#95E1D3",
                "cwe": "#F38181",
                "finding": "#AA96DA",
                "vulnerability_type": "#FCBAD3"
            }
            
            net.add_node(
                node,
                label=node[:30],
                color=color_map.get(node_type, "#CCCCCC"),
                title=str(node_data)
            )
        
        # Add edges
        for edge in self.graph.edges(data=True):
            net.add_edge(edge[0], edge[1], label=edge[2].get("relation", ""))
        
        # Save visualization
        net.save_graph(output_path)
        logger.info(f"Knowledge graph visualized: {output_path}")
    
    def export_json(self, output_path: str = "knowledge_graph.json"):
        """Export knowledge graph as JSON."""
        if self.graph is None:
            logger.warning("No graph to export")
            return
        
        graph_data = {
            "nodes": [
                {"id": node, **self.graph.nodes[node]}
                for node in self.graph.nodes()
            ],
            "edges": [
                {"source": edge[0], "target": edge[1], **edge[2]}
                for edge in self.graph.edges(data=True)
            ]
        }
        
        with open(output_path, "w") as f:
            json.dump(graph_data, f, indent=2)
        
        logger.info(f"Knowledge graph exported: {output_path}")

