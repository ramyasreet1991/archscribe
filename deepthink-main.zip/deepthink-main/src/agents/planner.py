"""
Planning Agent: Decomposes complex queries into structured multi-step research plans
"""

from typing import Dict, Any, List, Optional
from langchain.prompts import ChatPromptTemplate
from langchain.schema import BaseMessage
import json
import logging

logger = logging.getLogger(__name__)


class PlanningAgent:
    """Agent that creates and manages execution plans for complex queries."""
    
    PLANNING_PROMPT = ChatPromptTemplate.from_messages([
        ("system", """You are an expert penetration testing analyst. Your task is to decompose
complex security queries into a structured, multi-step research plan.

For each step, decide:
1. What specific information needs to be retrieved
2. Which tool is best: "vector" (semantic search), "keyword" (exact matches), 
   or "hybrid" (combination)
3. What type of knowledge is needed (exploits, CVEs, similar reports, etc.)

Consider:
- Similar pentest reports and their findings
- Known exploits and attack vectors
- CVE databases and vulnerability information
- Security best practices and remediation strategies
- Knowledge graph relationships between vulnerabilities

Output a JSON plan with steps that can be executed sequentially or in parallel."""),
        ("human", """Query: {query}

Context: {context}

Create a detailed research plan to answer this query comprehensively.
Consider all aspects: vulnerability analysis, exploit identification, risk assessment,
and remediation recommendations."""),
    ])
    
    UPDATE_PROMPT = ChatPromptTemplate.from_messages([
        ("system", """You are updating a research plan based on reflection and critique.
Incorporate new insights and adjust the plan accordingly."""),
        ("human", """Original Plan: {original_plan}

Reflection: {reflection}

Update the plan to address gaps and improve the research strategy."""),
    ])
    
    def __init__(self, llm):
        """Initialize the planning agent."""
        self.llm = llm
    
    def create_plan(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Create a multi-step research plan from a query.
        
        Args:
            query: The user's query
            context: Optional context information
            
        Returns:
            Structured plan with steps
        """
        context_str = json.dumps(context, indent=2) if context else "None"
        
        messages = self.PLANNING_PROMPT.format_messages(
            query=query,
            context=context_str
        )
        
        response = self.llm.invoke(messages)
        plan_text = response.content
        
        # Parse JSON from response
        try:
            # Extract JSON from markdown code blocks if present
            if "```json" in plan_text:
                plan_text = plan_text.split("```json")[1].split("```")[0].strip()
            elif "```" in plan_text:
                plan_text = plan_text.split("```")[1].split("```")[0].strip()
            
            plan = json.loads(plan_text)
        except json.JSONDecodeError:
            # Fallback: create a default plan structure
            logger.warning("Failed to parse plan JSON, using default structure")
            plan = self._create_default_plan(query)
        
        # Ensure plan has required structure
        if "steps" not in plan:
            plan["steps"] = []
        
        # Validate and enrich steps
        plan["steps"] = self._enrich_steps(plan.get("steps", []), query, context)
        
        return plan
    
    def update_plan(
        self,
        original_plan: Dict[str, Any],
        reflection: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Update plan based on reflection and critique."""
        reflection_str = json.dumps(reflection, indent=2)
        original_plan_str = json.dumps(original_plan, indent=2)
        
        messages = self.UPDATE_PROMPT.format_messages(
            original_plan=original_plan_str,
            reflection=reflection_str
        )
        
        response = self.llm.invoke(messages)
        updated_plan_text = response.content
        
        try:
            if "```json" in updated_plan_text:
                updated_plan_text = updated_plan_text.split("```json")[1].split("```")[0].strip()
            elif "```" in updated_plan_text:
                updated_plan_text = updated_plan_text.split("```")[1].split("```")[0].strip()
            
            updated_plan = json.loads(updated_plan_text)
        except json.JSONDecodeError:
            logger.warning("Failed to parse updated plan, returning original")
            return original_plan
        
        return updated_plan
    
    def _create_default_plan(self, query: str) -> Dict[str, Any]:
        """Create a default plan structure if parsing fails."""
        return {
            "goal": query,
            "steps": [
                {
                    "step": 1,
                    "query": query,
                    "tool": "hybrid",
                    "description": "Initial comprehensive search",
                    "expected_output": "Relevant documents and knowledge"
                },
                {
                    "step": 2,
                    "query": f"exploits related to {query}",
                    "tool": "vector",
                    "description": "Find related exploits",
                    "expected_output": "Exploit information and attack vectors"
                },
                {
                    "step": 3,
                    "query": f"similar pentest reports for {query}",
                    "tool": "vector",
                    "description": "Find similar reports",
                    "expected_output": "Similar findings and recommendations"
                }
            ]
        }
    
    def _enrich_steps(
        self,
        steps: List[Dict[str, Any]],
        query: str,
        context: Optional[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Enrich steps with additional metadata."""
        enriched = []
        for i, step in enumerate(steps):
            enriched_step = {
                "step": step.get("step", i + 1),
                "query": step.get("query", query),
                "tool": step.get("tool", "hybrid"),
                "description": step.get("description", ""),
                "expected_output": step.get("expected_output", ""),
                "priority": step.get("priority", "medium")
            }
            enriched.append(enriched_step)
        return enriched

