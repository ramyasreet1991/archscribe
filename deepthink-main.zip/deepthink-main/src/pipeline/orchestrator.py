"""
Main orchestrator for the Deep-Thinking RAG Pipeline
Implements the multi-step planning, retrieval, refinement, and reflection cycle
"""

from typing import List, Dict, Any, Optional
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import BaseMessage
import json
import logging

from ..agents.planner import PlanningAgent
from ..retrieval.retrieval_system import RetrievalSystem
from ..refinement.refiner import RefinementSystem
from ..reflection.reflector import ReflectionAgent
from ..knowledge_graph.kg_builder import KnowledgeGraphBuilder
from ..exploits.exploit_analyzer import ExploitAnalyzer
from ..reporting.report_generator import ReportGenerator

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DeepThinkingRAGPipeline:
    """
    Orchestrates the complete deep-thinking RAG pipeline for pentest report generation.
    
    Pipeline stages:
    1. Plan: Decompose query into multi-step research plan
    2. Retrieve: Adaptive multi-stage retrieval with supervisor
    3. Refine: Cross-encoder reranking and distillation
    4. Reflect: Critique and synthesis
    5. Generate: Create comprehensive pentest report
    """
    
    def __init__(
        self,
        llm_model: str = "gpt-4-turbo-preview",
        temperature: float = 0.3,
        vector_store_path: str = "./vector_store",
        kg_type: str = "networkx"
    ):
        """Initialize the pipeline with all components."""
        self.llm = ChatOpenAI(model=llm_model, temperature=temperature)
        
        # Initialize components
        self.planner = PlanningAgent(llm=self.llm)
        self.retrieval_system = RetrievalSystem(vector_store_path=vector_store_path)
        self.refiner = RefinementSystem(llm=self.llm)
        self.reflector = ReflectionAgent(llm=self.llm)
        self.kg_builder = KnowledgeGraphBuilder(kg_type=kg_type)
        self.exploit_analyzer = ExploitAnalyzer(llm=self.llm)
        self.report_generator = ReportGenerator(llm=self.llm)
        
        logger.info("Deep-Thinking RAG Pipeline initialized")
    
    def process_query(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None,
        max_iterations: int = 3
    ) -> Dict[str, Any]:
        """
        Process a complex query through the deep-thinking pipeline.
        
        Args:
            query: The user's query about pentest findings or exploits
            context: Optional context (e.g., scan results, target info)
            max_iterations: Maximum reflection iterations
            
        Returns:
            Complete analysis with report, exploits, and knowledge graph
        """
        logger.info(f"Processing query: {query}")
        
        # Stage 1: Plan
        plan = self.planner.create_plan(query, context)
        logger.info(f"Generated plan: {json.dumps(plan, indent=2)}")
        
        all_evidence = []
        all_exploits = []
        iteration = 0
        
        # Execute plan with reflection loop
        while iteration < max_iterations:
            iteration += 1
            logger.info(f"Iteration {iteration}/{max_iterations}")
            
            # Stage 2: Retrieve for each plan step
            step_evidence = []
            for step in plan.get("steps", []):
                evidence = self.retrieval_system.retrieve(
                    query=step["query"],
                    tool=step.get("tool", "hybrid"),
                    top_k=20
                )
                step_evidence.extend(evidence)
            
            # Stage 3: Refine evidence
            refined_evidence = self.refiner.refine(
                query=query,
                evidence=step_evidence,
                top_k=5
            )
            all_evidence.extend(refined_evidence)
            
            # Stage 4: Analyze for exploits
            exploits = self.exploit_analyzer.analyze(
                query=query,
                evidence=refined_evidence,
                context=context
            )
            all_exploits.extend(exploits)
            
            # Stage 5: Reflect and critique
            reflection = self.reflector.reflect(
                query=query,
                evidence=refined_evidence,
                exploits=exploits,
                iteration=iteration
            )
            
            # Check if we should continue or synthesize
            if reflection.get("should_synthesize", False) or iteration >= max_iterations:
                break
            
            # Update plan based on reflection
            plan = self.planner.update_plan(plan, reflection)
        
        # Build knowledge graph from all evidence
        kg = self.kg_builder.build_graph(
            evidence=all_evidence,
            exploits=all_exploits,
            query=query
        )
        
        # Stage 6: Generate comprehensive report
        report = self.report_generator.generate(
            query=query,
            evidence=all_evidence,
            exploits=all_exploits,
            knowledge_graph=kg,
            context=context
        )
        
        return {
            "query": query,
            "plan": plan,
            "evidence": all_evidence,
            "exploits": all_exploits,
            "knowledge_graph": kg,
            "report": report,
            "iterations": iteration,
            "reflection": reflection
        }
    
    def generate_pentest_report(
        self,
        findings: List[Dict[str, Any]],
        target_info: Dict[str, Any],
        scan_results: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Generate a comprehensive pentest report from findings.
        
        Args:
            findings: List of discovered vulnerabilities/findings
            target_info: Information about the target system
            scan_results: Optional scan results (nmap, etc.)
            
        Returns:
            Complete pentest report with exploits and recommendations
        """
        # Create query from findings
        query = self._create_query_from_findings(findings, target_info)
        
        context = {
            "findings": findings,
            "target_info": target_info,
            "scan_results": scan_results
        }
        
        return self.process_query(query, context=context)
    
    def _create_query_from_findings(
        self,
        findings: List[Dict[str, Any]],
        target_info: Dict[str, Any]
    ) -> str:
        """Create a comprehensive query from pentest findings."""
        finding_summaries = [
            f"{f.get('type', 'Unknown')}: {f.get('description', '')}"
            for f in findings
        ]
        
        query = f"""
        Generate a comprehensive penetration test report for:
        Target: {target_info.get('name', 'Unknown')}
        Type: {target_info.get('type', 'Unknown')}
        
        Findings:
        {chr(10).join(finding_summaries)}
        
        Analyze these findings, identify potential exploits, provide detailed
        risk assessment, and generate remediation recommendations. Leverage
        knowledge from similar pentest reports and exploit databases.
        """
        return query

