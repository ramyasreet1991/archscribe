"""
Setup script to initialize the project structure
"""

from pathlib import Path
import os


def create_directories():
    """Create necessary directories."""
    directories = [
        "data/pentest_reports",
        "data/public_pentest_reports",
        "output",
        "vector_store",
        "templates"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"Created directory: {directory}")
    
    # Create .gitkeep files to preserve empty directories
    for directory in directories:
        gitkeep = Path(directory) / ".gitkeep"
        if not gitkeep.exists():
            gitkeep.touch()
            print(f"Created .gitkeep in: {directory}")


def create_template():
    """Create a basic report template."""
    template_dir = Path("templates")
    template_file = template_dir / "pentest_report_template.md"
    
    if not template_file.exists():
        template_content = """# Penetration Test Report

## Executive Summary

[Generated executive summary]

## Methodology

[Testing methodology and approach]

## Findings

### Finding 1: [Title]
- **Severity**: [Critical/High/Medium/Low]
- **CVE**: [CVE-ID]
- **Description**: [Detailed description]
- **Impact**: [Impact assessment]
- **Remediation**: [Remediation steps]

## Exploits

[Detailed exploit analysis]

## Risk Assessment

[Overall risk assessment]

## Recommendations

[Prioritized recommendations]

## Appendices

[Technical details and references]
"""
        template_file.write_text(template_content)
        print(f"Created template: {template_file}")


if __name__ == "__main__":
    print("Setting up Deep-Thinking RAG Pipeline project structure...")
    print("-" * 60)
    create_directories()
    create_template()
    print("-" * 60)
    print("Setup complete!")
    print("\nNext steps:")
    print("1. Copy .env.example to .env and add your OPENAI_API_KEY")
    print("2. Add your pentest reports to data/pentest_reports/ or data/public_pentest_reports/")
    print("3. Run: python main.py --mode report")

