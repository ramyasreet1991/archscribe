# ArchScribe Quick Start Guide

## Installation

```bash
# Install dependencies
pip install poetry
poetry install

# Or install directly
pip install -e .
```

## Basic Usage

### 1. Scan a Repository

```bash
# Basic scan
archscribe scan /path/to/repo \
  --targets c4-container erd \
  --formats drawio mermaid csv \
  --out diagrams/

# With security analysis
archscribe scan /path/to/repo \
  --targets c4-container erd \
  --formats drawio mermaid \
  --security \
  --kg \
  --cpg \
  --out diagrams/
```

### 2. Launch Dashboard

```bash
# After scanning, launch the dashboard
archscribe dashboard diagrams/reports/graph.json \
  --neo4j-uri bolt://localhost:7687 \
  --neo4j-user neo4j \
  --neo4j-password password \
  --port 8501
```

### 3. View Results

After scanning, you'll find:

- **Diagrams**: `diagrams/architecture/` and `diagrams/erd/`
  - Mermaid files (`.mmd`)
  - Draw.io XML files (`.drawio.xml`)
  - CSV files (`.csv`)
  - PlantUML files (`.puml`)

- **Reports**: `diagrams/reports/`
  - `graph.json`: Complete graph representation
  - `graph.cypher`: Neo4j import script
  - `security-report.json`: Security analysis results
  - `cpg/`: Code Property Graph artifacts
  - `summary.html`: Human-readable summary

## Configuration

Create a `archscribe.yaml` file:

```yaml
project: myproject
targets:
  - type: c4-container
  - type: erd
inputs:
  repo: .
  paths:
    include: ["src/**", "migrations/**"]
    exclude: ["**/tests/**"]
languages: [python, javascript]
erd:
  sources: [orm, migrations]
render:
  formats: [drawio, mermaid, csv]
cpg: true
kg: true
security: true
```

Then run:

```bash
archscribe scan . --config archscribe.yaml --out diagrams/
```

## Neo4j Setup (Optional)

1. Install Neo4j:
   ```bash
   docker run -d \
     --name neo4j \
     -p 7474:7474 -p 7687:7687 \
     -e NEO4J_AUTH=neo4j/password \
     neo4j:latest
   ```

2. Access Neo4j Browser: http://localhost:7474

3. Run scan with Neo4j:
   ```bash
   archscribe scan . \
     --kg \
     --neo4j-uri bolt://localhost:7687 \
     --neo4j-user neo4j \
     --neo4j-password password \
     --out diagrams/
   ```

4. Query the graph:
   ```cypher
   MATCH (n) RETURN n LIMIT 25
   MATCH (e:Endpoint {public: true}) RETURN e
   MATCH (s:Secret) RETURN s
   ```

## Security Analysis

ArchScribe performs comprehensive security analysis:

1. **Attack Path Detection**: Identifies paths from public endpoints to sensitive resources
2. **Authentication Analysis**: Detects unauthenticated endpoints
3. **Secret Detection**: Finds hardcoded secrets and credentials
4. **SQL Injection Risks**: Identifies potential SQL injection vulnerabilities
5. **Privilege Escalation**: Detects privilege escalation paths

View results in:
- `diagrams/reports/security-report.json`
- Dashboard: Security Analysis view

## GitHub Actions

The included GitHub Actions workflow automatically generates diagrams on PRs:

```yaml
# .github/workflows/diagram.yml
name: Generate Architecture Diagrams

on:
  push:
    paths: ['**.py', '**.js']
  pull_request:

jobs:
  diagrams:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Generate diagrams
        run: archscribe scan . --targets c4-container erd --formats drawio mermaid --out diagrams/
      - name: Upload diagrams
        uses: actions/upload-artifact@v3
        with:
          name: diagrams
          path: diagrams/
```

## Demo: SAST vs Knowledge Graph

ArchScribe demonstrates the value of knowledge graph analysis:

### SAST Alone
- Finds potential vulnerabilities in isolation
- High false positive rate
- No attack path context
- No prioritization based on exploitability

### Knowledge Graph Analysis
- Models full system architecture
- Identifies real attack paths
- Prioritizes based on exploitability
- Context-aware risk assessment

### Business Value
- 🎯 **Focus on Real Risks**: Identifies actual exploitable paths
- ⏱️ **Save Time**: Reduced false positives means less time on non-issues
- 🔒 **Better Security**: Context-aware analysis catches architectural flaws
- 📊 **Actionable Insights**: Prioritized findings with business impact

## Troubleshooting

### CPG Extraction Fails
- Install `py2cpg`: `pip install py2cpg`
- Or use AST fallback (automatic)

### Neo4j Connection Fails
- Check Neo4j is running: `docker ps | grep neo4j`
- Verify credentials: `neo4j/password`
- Check connection: `bolt://localhost:7687`

### No Diagrams Generated
- Check repository path is correct
- Verify supported file types exist (`.py`, `.js`, `requirements.txt`, `package.json`)
- Check output directory permissions

## Next Steps

1. **Customize Analyzers**: Add custom analyzers for your stack
2. **Extend Renderers**: Add support for additional formats
3. **Enhance Security**: Add more security analysis rules
4. **Integrate CI/CD**: Use GitHub Actions workflow
5. **Query Graph**: Use Neo4j for advanced graph queries

## Support

For issues, questions, or contributions:
- GitHub Issues: https://github.com/your-org/archscribe/issues
- Documentation: See README.md
- Examples: See `samples/` directory

