# ArchScribe – Automatic Architecture & ERD Diagrams from Code

Scan your code repositories and auto-generate system architecture diagrams, ERDs, knowledge graphs, and security analysis reports. Export to multiple formats including Mermaid, PlantUML, Draw.io (for Lucidchart import), and CSV.

## Features

- 🏗️ **Architecture Diagrams**: Generate C4 Context/Container/Component diagrams
- 📊 **ERD Generation**: Extract database schemas from ORMs, migrations, and SQL files
- 🔍 **Code Property Graph (CPG)**: Extract CPG for deep code analysis
- 🧠 **Knowledge Graph**: Build knowledge graphs from code repositories
- 🛡️ **Security Analysis**: Identify attack paths, vulnerabilities, and security risks
- 📈 **Interactive Dashboard**: Streamlit dashboard for visualization and analysis
- 🔗 **Neo4j Integration**: Export to Neo4j for advanced graph queries
- 📋 **Multiple Formats**: Export to Mermaid, PlantUML, Draw.io, CSV, and more

## Installation

```bash
# Clone the repository
git clone https://github.com/your-org/archscribe.git
cd archscribe

# Install dependencies
pip install poetry
poetry install

# Or install directly
pip install -e .
```

## Quick Start

### Basic Scan

```bash
# Scan a repository
archscribe scan /path/to/repo \
  --targets c4-container erd \
  --formats drawio mermaid csv \
  --out diagrams/
```

### With Security Analysis

```bash
# Scan with security analysis
archscribe scan /path/to/repo \
  --targets c4-container erd \
  --formats drawio mermaid \
  --security \
  --kg \
  --cpg \
  --out diagrams/
```

### With Neo4j

```bash
# Scan and export to Neo4j
archscribe scan /path/to/repo \
  --kg \
  --neo4j-uri bolt://localhost:7687 \
  --neo4j-user neo4j \
  --neo4j-password password \
  --out diagrams/
```

### Launch Dashboard

```bash
# Launch Streamlit dashboard
archscribe dashboard diagrams/reports/graph.json \
  --neo4j-uri bolt://localhost:7687 \
  --neo4j-user neo4j \
  --neo4j-password password
```

## Configuration

Create a `archscribe.yaml` configuration file:

```yaml
project: myproject
targets:
  - type: c4-context
  - type: c4-container
  - type: erd
inputs:
  repo: .
  paths:
    include: ["src/**", "migrations/**", "infra/**"]
    exclude: ["**/tests/**", "**/node_modules/**"]
languages: [python, javascript]
frameworks: [flask, express]
cloud: aws
erd:
  sources: [orm, migrations, sql]
  infer_nullability: true
render:
  formats: [drawio, mermaid, plantuml, csv]
  layout: elk
  theme: "neutral"
publish:
  github_pr_comment: true
  artifact_dir: "diagrams/"
cpg: true
kg: true
security: true
```

## Supported Analyzers

### Python
- Requirements.txt parsing
- SQLAlchemy model extraction
- FastAPI/Flask endpoint detection
- CPG extraction (py2cpg)

### JavaScript/TypeScript
- package.json parsing
- Express/NestJS endpoint detection
- Prisma schema extraction

### Infrastructure
- Docker/Docker Compose analysis
- Kubernetes manifests (planned)
- Terraform (planned)

### Security
- Hardcoded secret detection
- API endpoint analysis
- Attack path simulation
- SQL injection risk detection
- Privilege escalation path detection

## Output Formats

### Diagrams
- **Mermaid** (`.mmd`): For GitHub, documentation, and PR reviews
- **PlantUML** (`.puml`): For technical documentation
- **Draw.io** (`.drawio.xml`): For Lucidchart import
- **CSV** (`.csv`): For ERD data import into Lucidchart

### Reports
- **JSON Graph** (`graph.json`): Complete graph representation
- **Cypher Script** (`graph.cypher`): Neo4j import script
- **Security Report** (`security-report.json`): Security analysis results
- **CPG** (`cpg/`): Code Property Graph artifacts
- **HTML Summary** (`summary.html`): Human-readable summary

## Security Analysis

ArchScribe performs comprehensive security analysis:

1. **Attack Path Detection**: Identifies paths from public endpoints to sensitive resources
2. **Authentication Analysis**: Detects unauthenticated endpoints
3. **Secret Detection**: Finds hardcoded secrets and credentials
4. **SQL Injection Risks**: Identifies potential SQL injection vulnerabilities
5. **Privilege Escalation**: Detects privilege escalation paths

### Example Security Report

```json
{
  "attack_paths": [
    {
      "endpoint": "POST /orders/create",
      "resource": "orders_db",
      "severity": "high",
      "exploitable": true,
      "path": ["endpoint-orders-create", "service-orders", "db-orders"]
    }
  ],
  "unauthenticated_endpoints": [
    {
      "name": "POST /orders/create",
      "file": "src/api/orders.py",
      "method": "POST",
      "path": "/orders/create"
    }
  ],
  "hardcoded_secrets": [
    {
      "name": "aws_key at config.py:22",
      "file": "src/config.py",
      "line": 22,
      "type": "aws_key",
      "severity": "high"
    }
  ]
}
```

## Dashboard

The Streamlit dashboard provides:

- **Security Analysis View**: Overview of security issues and attack paths
- **Graph Explorer**: Interactive graph exploration with Cypher queries
- **Attack Path Visualization**: Visual representation of attack paths
- **SAST Comparison**: Comparison between SAST and knowledge graph analysis

### Launch Dashboard

```bash
archscribe dashboard diagrams/reports/graph.json \
  --neo4j-uri bolt://localhost:7687 \
  --neo4j-user neo4j \
  --neo4j-password password \
  --port 8501
```

## Knowledge Graph

ArchScribe builds a comprehensive knowledge graph from your codebase:

- **Nodes**: Services, modules, databases, tables, endpoints, secrets, etc.
- **Edges**: Calls, reads, writes, depends_on, authenticates, etc.
- **Properties**: Metadata, file paths, line numbers, etc.

### Neo4j Integration

Export to Neo4j for advanced graph queries:

```cypher
// Find all attack paths
MATCH (e:Endpoint {public: true})-[*1..5]->(r)
WHERE r:Database OR r:Secret
RETURN e, r

// Find unauthenticated endpoints
MATCH (e:Endpoint)
WHERE NOT (e)-[:REQUIRES_AUTH]->()
RETURN e

// Find hardcoded secrets
MATCH (s:Secret)
RETURN s
```

## GitHub Actions

ArchScribe includes a GitHub Actions workflow that automatically generates diagrams on PRs:

```yaml
# .github/workflows/diagram.yml
name: Generate Architecture Diagrams

on:
  push:
    paths: ['**.py', '**.js', '**/migrations/**']
  pull_request:

jobs:
  diagrams:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Generate diagrams
        run: archscribe scan . --targets c4-container erd --formats drawio mermaid --out diagrams/
      - name: Upload diagrams
        uses: actions/upload-artifact@v3
        with:
          name: diagrams
          path: diagrams/
```

## Demo: SAST vs Knowledge Graph Analysis

ArchScribe demonstrates the value of knowledge graph analysis over traditional SAST:

### SAST Alone
- Finds potential vulnerabilities in isolation
- High false positive rate
- No attack path context
- No prioritization based on exploitability

### Knowledge Graph Analysis
- Models full system architecture
- Identifies real attack paths
- Prioritizes based on exploitability
- Context-aware risk assessment

### Business Value
- 🎯 **Focus on Real Risks**: Identifies actual exploitable paths
- ⏱️ **Save Time**: Reduced false positives means less time on non-issues
- 🔒 **Better Security**: Context-aware analysis catches architectural flaws
- 📊 **Actionable Insights**: Prioritized findings with business impact

## Roadmap

- [x] MVP: Python/JS analyzers, ERD extraction, Mermaid/Draw.io rendering
- [x] CPG extraction
- [x] Knowledge graph generation
- [x] Security analysis
- [x] Streamlit dashboard
- [ ] Java/Spring Boot support
- [ ] OpenAPI/gRPC edge detection
- [ ] ELK auto-layout
- [ ] Visio VDX export
- [ ] Terraform/K8s overlays
- [ ] Multi-repo system map
- [ ] PR diff diagram highlighting

## Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for details.

## License

MIT License - see [LICENSE](LICENSE) for details.

## Support

For issues, questions, or contributions, please open an issue on GitHub.

