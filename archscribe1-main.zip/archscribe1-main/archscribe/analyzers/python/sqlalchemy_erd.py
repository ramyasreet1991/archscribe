"""Extract ERD from SQLAlchemy models"""

from pathlib import Path
from typing import List
import re
import ast
from archscribe.core.metamodel import Table, Column, Graph


def scan_sqlalchemy_models(repo_path: Path, graph: Graph) -> List[Table]:
    """Scan Python files for SQLAlchemy models and extract tables"""
    tables = []
    python_files = list(repo_path.rglob("*.py"))
    
    for py_file in python_files:
        # Skip test files and migrations for now
        if "test" in str(py_file) or "migration" in str(py_file):
            continue
        
        try:
            with open(py_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Try to parse as AST
            try:
                tree = ast.parse(content)
                tables.extend(_extract_models_from_ast(tree, py_file))
            except SyntaxError:
                # Fallback to regex for basic extraction
                tables.extend(_extract_models_from_regex(content, py_file))
        except Exception as e:
            print(f"Error parsing {py_file}: {e}")
            continue
    
    # Add tables to graph
    for table in tables:
        graph.add_table(table)
    
    return tables


def _extract_models_from_ast(tree: ast.AST, file_path: Path) -> List[Table]:
    """Extract SQLAlchemy models from AST"""
    tables = []
    
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            # Check if it's a SQLAlchemy model (has __tablename__ or inherits from Base/Model)
            table_name = None
            columns = []
            
            # Look for __tablename__
            for item in node.body:
                if isinstance(item, ast.Assign):
                    for target in item.targets:
                        if isinstance(target, ast.Name) and target.id == "__tablename__":
                            if isinstance(item.value, ast.Constant):
                                table_name = item.value.value
                            elif isinstance(item.value, ast.Str):  # Python < 3.8
                                table_name = item.value.s
            
            # If no __tablename__, use class name (lowercase)
            if not table_name:
                table_name = node.name.lower()
            
            # Extract columns
            for item in node.body:
                if isinstance(item, ast.Assign):
                    # Check if it's a Column assignment
                    if isinstance(item.value, ast.Call):
                        func = item.value.func
                        if isinstance(func, ast.Attribute) and func.attr == "Column":
                            # Extract column name
                            for target in item.targets:
                                if isinstance(target, ast.Name):
                                    col_name = target.id
                                    
                                    # Extract column type and properties
                                    col_type = "string"
                                    nullable = True
                                    primary_key = False
                                    foreign_key = False
                                    fk_target = None
                                    
                                    # Parse Column() arguments
                                    for keyword in item.value.keywords:
                                        if keyword.arg == "primary_key" and isinstance(keyword.value, ast.Constant):
                                            primary_key = keyword.value.value
                                        elif keyword.arg == "nullable" and isinstance(keyword.value, ast.Constant):
                                            nullable = keyword.value.value
                                    
                                    # Check for ForeignKey
                                    if isinstance(item.value.func, ast.Attribute):
                                        # Look for ForeignKey in arguments
                                        for arg in item.value.args:
                                            if isinstance(arg, ast.Call):
                                                if isinstance(arg.func, ast.Name) and arg.func.id == "ForeignKey":
                                                    foreign_key = True
                                                    if arg.args:
                                                        if isinstance(arg.args[0], ast.Constant):
                                                            fk_target = arg.args[0].value
                                                        elif isinstance(arg.args[0], ast.Str):
                                                            fk_target = arg.args[0].s
                                    
                                    column = Column(
                                        name=col_name,
                                        type=col_type,
                                        nullable=nullable,
                                        primary_key=primary_key,
                                        foreign_key=foreign_key,
                                        fk_target_table=fk_target.split('.')[0] if fk_target and '.' in fk_target else None,
                                        fk_target_column=fk_target.split('.')[1] if fk_target and '.' in fk_target and len(fk_target.split('.')) > 1 else None
                                    )
                                    columns.append(column)
            
            if table_name:
                table = Table(
                    name=table_name,
                    columns=columns,
                    props={"source_file": str(file_path), "class": node.name}
                )
                tables.append(table)
    
    return tables


def _extract_models_from_regex(content: str, file_path: Path) -> List[Table]:
    """Fallback regex-based extraction for SQLAlchemy models"""
    tables = []
    
    # Pattern for class definitions with __tablename__
    class_pattern = r'class\s+(\w+).*?:\s*(.*?)(?=class\s+\w+|$)'
    
    for match in re.finditer(class_pattern, content, re.DOTALL):
        class_name = match.group(1)
        class_body = match.group(2)
        
        # Look for __tablename__
        table_match = re.search(r'__tablename__\s*=\s*[\'"](\w+)[\'"]', class_body)
        if table_match:
            table_name = table_match.group(1)
        else:
            table_name = class_name.lower()
        
        # Extract columns (basic pattern)
        columns = []
        column_pattern = r'(\w+)\s*=\s*Column\([^)]*\)'
        
        for col_match in re.finditer(column_pattern, class_body):
            col_name = col_match.group(1)
            col_def = col_match.group(0)
            
            primary_key = 'primary_key=True' in col_def
            nullable = 'nullable=False' not in col_def
            foreign_key = 'ForeignKey' in col_def
            
            column = Column(
                name=col_name,
                type="string",
                nullable=nullable,
                primary_key=primary_key,
                foreign_key=foreign_key
            )
            columns.append(column)
        
        if table_name:
            table = Table(
                name=table_name,
                columns=columns,
                props={"source_file": str(file_path), "class": class_name}
            )
            tables.append(table)
    
    return tables
