"""Code Property Graph extraction using py2cpg"""

import subprocess
from pathlib import Path
from typing import Optional
from rich import print
import json
import shutil


def extract_cpg(repo_path: Path, out_dir: Path) -> Optional[Path]:
    """
    Call py2cpg to generate a CPG for the Python repo.
    Falls back to AST-based extraction if py2cpg is not available.
    """
    cpg_dir = out_dir / "cpg"
    cpg_dir.mkdir(parents=True, exist_ok=True)
    
    cpg_path = cpg_dir / "python.cpg.bin"
    cpg_json_path = cpg_dir / "python.cpg.json"
    
    # Check if py2cpg is available
    py2cpg_available = shutil.which("py2cpg") is not None
    
    if py2cpg_available:
        try:
            print(f"[green]Extracting CPG using py2cpg...[/green]")
            # Run py2cpg
            result = subprocess.run(
                ["py2cpg", str(repo_path), "-o", str(cpg_path)],
                capture_output=True,
                text=True,
                timeout=300
            )
            
            if result.returncode == 0:
                print(f"[green]CPG extracted to {cpg_path}[/green]")
                
                # Try to export to JSON if possible
                try:
                    subprocess.run(
                        ["joern", "--script", "export-cpg.sc", str(cpg_path)],
                        capture_output=True,
                        timeout=60
                    )
                except:
                    # If joern export fails, create a placeholder JSON
                    _create_cpg_metadata(cpg_json_path, repo_path)
                
                return cpg_path
            else:
                print(f"[yellow]py2cpg failed, using AST fallback: {result.stderr}[/yellow]")
                return _extract_cpg_ast_fallback(repo_path, cpg_json_path)
        except subprocess.TimeoutExpired:
            print(f"[yellow]py2cpg timed out, using AST fallback[/yellow]")
            return _extract_cpg_ast_fallback(repo_path, cpg_json_path)
        except Exception as e:
            print(f"[yellow]Error running py2cpg: {e}, using AST fallback[/yellow]")
            return _extract_cpg_ast_fallback(repo_path, cpg_json_path)
    else:
        print(f"[yellow]py2cpg not found, using AST fallback[/yellow]")
        return _extract_cpg_ast_fallback(repo_path, cpg_json_path)


def _extract_cpg_ast_fallback(repo_path: Path, out_path: Path) -> Path:
    """Fallback CPG extraction using Python AST"""
    import ast
    from typing import Dict, List, Any
    
    cpg_data: Dict[str, Any] = {
        "nodes": [],
        "edges": [],
        "metadata": {
            "source": "ast_fallback",
            "repo_path": str(repo_path)
        }
    }
    
    python_files = list(repo_path.rglob("*.py"))
    
    for py_file in python_files:
        # Skip test files
        if "test" in str(py_file) or "__pycache__" in str(py_file):
            continue
        
        try:
            with open(py_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            tree = ast.parse(content, filename=str(py_file))
            
            # Extract functions and classes
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    func_node = {
                        "id": f"func-{py_file.stem}-{node.name}",
                        "type": "function",
                        "name": node.name,
                        "file": str(py_file),
                        "line": node.lineno,
                        "calls": []
                    }
                    
                    # Find function calls
                    for child in ast.walk(node):
                        if isinstance(child, ast.Call):
                            if isinstance(child.func, ast.Name):
                                func_node["calls"].append(child.func.id)
                            elif isinstance(child.func, ast.Attribute):
                                func_node["calls"].append(child.func.attr)
                    
                    cpg_data["nodes"].append(func_node)
                
                elif isinstance(node, ast.ClassDef):
                    class_node = {
                        "id": f"class-{py_file.stem}-{node.name}",
                        "type": "class",
                        "name": node.name,
                        "file": str(py_file),
                        "line": node.lineno,
                        "methods": []
                    }
                    
                    # Extract methods
                    for item in node.body:
                        if isinstance(item, ast.FunctionDef):
                            class_node["methods"].append(item.name)
                    
                    cpg_data["nodes"].append(class_node)
        
        except Exception as e:
            print(f"[yellow]Error processing {py_file}: {e}[/yellow]")
            continue
    
    # Write JSON output
    with open(out_path, 'w') as f:
        json.dump(cpg_data, f, indent=2)
    
    print(f"[green]AST-based CPG extracted to {out_path}[/green]")
    return out_path


def _create_cpg_metadata(json_path: Path, repo_path: Path):
    """Create CPG metadata file"""
    metadata = {
        "metadata": {
            "source": "py2cpg",
            "repo_path": str(repo_path),
            "format": "overflowdb"
        },
        "note": "CPG binary generated by py2cpg. Use Joern to query."
    }
    
    with open(json_path, 'w') as f:
        json.dump(metadata, f, indent=2)
