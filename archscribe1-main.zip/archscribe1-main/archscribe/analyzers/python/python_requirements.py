"""Parse Python requirements.txt and detect dependencies"""

from pathlib import Path
from typing import List
from archscribe.core.metamodel import Node, NodeType, Edge, EdgeKind, Graph


def scan_requirements(repo_path: Path, graph: Graph) -> List[Node]:
    """Parse requirements.txt and create nodes for dependencies"""
    reqs_file = repo_path / "requirements.txt"
    nodes = []
    
    if not reqs_file.exists():
        return nodes
    
    # Create a service node for the Python application
    service_node = Node(
        id="python-service",
        type=NodeType.SERVICE,
        name="Python Service",
        props={"language": "python", "path": str(repo_path)}
    )
    nodes.append(service_node)
    graph.add_node(service_node)
    
    # Parse requirements.txt
    try:
        with open(reqs_file, 'r') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                
                # Parse package name (handle version specifiers)
                package_name = line.split('==')[0].split('>=')[0].split('<=')[0].split('~=')[0].split('!=')[0].strip()
                package_name = package_name.split('[')[0].strip()  # Remove extras
                
                if package_name:
                    dep_node = Node(
                        id=f"dep-{package_name}",
                        type=NodeType.MODULE,
                        name=package_name,
                        labels=["dependency", "python"],
                        props={"source": "requirements.txt", "spec": line}
                    )
                    nodes.append(dep_node)
                    graph.add_node(dep_node)
                    
                    # Add dependency edge
                    dep_edge = Edge(
                        from_node=service_node.id,
                        to_node=dep_node.id,
                        kind=EdgeKind.DEPENDS_ON,
                        props={"source": "requirements.txt"}
                    )
                    graph.add_edge(dep_edge)
    except Exception as e:
        print(f"Error parsing requirements.txt: {e}")
    
    return nodes
