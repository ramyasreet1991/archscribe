"""Extract ERD from Prisma schema"""

from pathlib import Path
from typing import List
import re
from archscribe.core.metamodel import Table, Column, Graph


def scan_prisma_schema(repo_path: Path, graph: Graph) -> List[Table]:
    """Scan for Prisma schema files and extract table definitions"""
    tables = []
    schema_files = list(repo_path.rglob("schema.prisma"))
    
    for schema_file in schema_files:
        try:
            with open(schema_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parse Prisma models
            model_pattern = r'model\s+(\w+)\s*\{([^}]+)\}'
            matches = re.finditer(model_pattern, content, re.DOTALL)
            
            for match in matches:
                model_name = match.group(1)
                model_body = match.group(2)
                
                columns = []
                
                # Parse fields
                field_pattern = r'(\w+)\s+(\w+(\[\])?(\?)?)\s*(@.*?)?(\n|$)'
                field_matches = re.finditer(r'(\w+)\s+(\S+)\s*([^\n]*)', model_body)
                
                for field_match in field_matches:
                    field_name = field_match.group(1)
                    field_type = field_match.group(2)
                    field_attrs = field_match.group(3) if field_match.lastindex >= 3 else ""
                    
                    # Skip relation fields (they don't create columns)
                    if field_type.startswith(('@', 'relation', '[')):
                        continue
                    
                    # Map Prisma types to SQL types
                    type_mapping = {
                        'String': 'text',
                        'Int': 'integer',
                        'Float': 'float',
                        'Boolean': 'boolean',
                        'DateTime': 'timestamp',
                        'Json': 'json',
                        'Bytes': 'bytea',
                        'BigInt': 'bigint',
                        'Decimal': 'numeric'
                    }
                    
                    col_type = type_mapping.get(field_type, 'text')
                    nullable = '?' in field_type or '@optional' in field_attrs
                    primary_key = '@id' in field_attrs or '@@id' in field_attrs
                    unique = '@unique' in field_attrs
                    indexed = '@index' in field_attrs or '@@index' in field_attrs
                    foreign_key = '@relation' in field_attrs or 'relation' in field_attrs.lower()
                    
                    fk_target_table = None
                    fk_target_column = None
                    
                    if foreign_key:
                        # Extract relation target from @relation attribute
                        relation_match = re.search(r'@relation\([^)]*fields:\s*\[(\w+)\][^)]*references:\s*\[(\w+)\][^)]*\)', field_attrs)
                        if relation_match:
                            fk_target_column = relation_match.group(2)
                            # Try to find the target model
                            relation_model_match = re.search(r'@relation\([^)]*name:\s*"(\w+)"', field_attrs)
                            if relation_model_match:
                                fk_target_table = relation_model_match.group(1)
                    
                    column = Column(
                        name=field_name,
                        type=col_type,
                        nullable=nullable,
                        primary_key=primary_key,
                        foreign_key=foreign_key,
                        fk_target_table=fk_target_table,
                        fk_target_column=fk_target_column or "id",
                        indexed=indexed,
                        unique=unique
                    )
                    columns.append(column)
                
                if columns:
                    table = Table(
                        name=model_name,
                        columns=columns,
                        tags=["prisma"],
                        props={
                            "source_file": str(schema_file)
                        }
                    )
                    tables.append(table)
                    graph.add_table(table)
        
        except Exception as e:
            print(f"Error parsing Prisma schema {schema_file}: {e}")
            continue
    
    return tables

