"""Analyze JavaScript/TypeScript projects"""

from pathlib import Path
import json
import re
from typing import List
from archscribe.core.metamodel import Node, NodeType, Graph


def scan_package_json(repo_path: Path, graph: Graph) -> List[Node]:
    """Parse package.json and extract dependencies"""
    nodes = []
    package_json = repo_path / "package.json"
    
    if not package_json.exists():
        return nodes
    
    try:
        with open(package_json, 'r') as f:
            data = json.load(f)
        
        service_node = Node(
            id="js-service",
            type=NodeType.SERVICE,
            name=data.get("name", "JavaScript Service"),
            props={
                "language": "javascript",
                "version": data.get("version", "unknown"),
                "path": str(repo_path)
            }
        )
        
        # Extract dependencies
        deps = []
        if "dependencies" in data:
            deps.extend(list(data["dependencies"].keys()))
        if "devDependencies" in data:
            deps.extend(list(data["devDependencies"].keys()))
        
        if deps:
            service_node.props["dependencies"] = deps
            service_node.props["dependency_count"] = len(deps)
        
        nodes.append(service_node)
        graph.add_node(service_node)
        
    except Exception as e:
        pass
    
    return nodes


def scan_express_routes(repo_path: Path, graph: Graph) -> List[Node]:
    """Scan for Express.js routes and endpoints"""
    nodes = []
    js_files = list(repo_path.rglob("*.js")) + list(repo_path.rglob("*.ts"))
    
    for js_file in js_files:
        if "node_modules" in str(js_file) or "test" in str(js_file):
            continue
        
        try:
            with open(js_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Look for Express patterns
            if 'express' not in content.lower() and 'router' not in content.lower():
                continue
            
            # Extract routes: app.get, app.post, router.get, etc.
            route_pattern = r'(app|router)\.(get|post|put|delete|patch)\s*\([\'"]([^\'"]+)[\'"]'
            routes = re.findall(route_pattern, content)
            
            for method_type, method, path in routes:
                endpoint_node = Node(
                    id=f"endpoint-{js_file.stem}-{path}",
                    type=NodeType.ENDPOINT,
                    name=f"{method.upper()} {path}",
                    props={
                        "method": method.upper(),
                        "path": path,
                        "file": str(js_file.relative_to(repo_path)),
                        "framework": "express"
                    }
                )
                nodes.append(endpoint_node)
                graph.add_node(endpoint_node)
        
        except Exception:
            continue
    
    return nodes

