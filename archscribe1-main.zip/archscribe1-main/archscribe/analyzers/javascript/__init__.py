"""JavaScript/TypeScript analyzers"""
