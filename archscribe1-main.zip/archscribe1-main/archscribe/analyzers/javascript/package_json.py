"""Parse JavaScript/TypeScript package.json and detect dependencies"""

from pathlib import Path
from typing import List
import json
from archscribe.core.metamodel import Node, NodeType, Edge, EdgeKind, Graph


def scan_package_json(repo_path: Path, graph: Graph) -> List[Node]:
    """Parse package.json and create nodes for dependencies"""
    nodes = []
    package_json_path = repo_path / "package.json"
    
    if not package_json_path.exists():
        # Try to find package.json in subdirectories
        package_json_paths = list(repo_path.rglob("package.json"))
        if not package_json_paths:
            return nodes
        package_json_path = package_json_paths[0]
    
    try:
        with open(package_json_path, 'r') as f:
            package_data = json.load(f)
        
        # Create service node
        service_name = package_data.get("name", "js-service")
        service_node = Node(
            id=f"js-service-{service_name}",
            type=NodeType.SERVICE,
            name=service_name,
            props={
                "language": "javascript",
                "path": str(package_json_path.parent),
                "version": package_data.get("version", "unknown")
            }
        )
        nodes.append(service_node)
        graph.add_node(service_node)
        
        # Parse dependencies
        deps = package_data.get("dependencies", {})
        dev_deps = package_data.get("devDependencies", {})
        
        all_deps = {**deps, **dev_deps}
        
        for dep_name, dep_version in all_deps.items():
            dep_node = Node(
                id=f"dep-{dep_name}",
                type=NodeType.MODULE,
                name=dep_name,
                labels=["dependency", "javascript"],
                props={
                    "source": "package.json",
                    "version": dep_version,
                    "dev": dep_name in dev_deps
                }
            )
            nodes.append(dep_node)
            graph.add_node(dep_node)
            
            # Add dependency edge
            dep_edge = Edge(
                from_node=service_node.id,
                to_node=dep_node.id,
                kind=EdgeKind.DEPENDS_ON,
                props={"source": "package.json"}
            )
            graph.add_edge(dep_edge)
    
    except Exception as e:
        print(f"Error parsing package.json: {e}")
    
    return nodes
