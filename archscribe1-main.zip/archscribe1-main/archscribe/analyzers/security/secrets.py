"""Detect hardcoded secrets and credentials"""

import re
from pathlib import Path
from typing import List, Dict
from archscribe.core.metamodel import Node, NodeType, Edge, EdgeKind, Graph


SECRET_PATTERNS = [
    (r'password\s*=\s*["\']([^"\']+)["\']', "password"),
    (r'api_key\s*=\s*["\']([^"\']+)["\']', "api_key"),
    (r'secret\s*=\s*["\']([^"\']+)["\']', "secret"),
    (r'aws_access_key_id\s*=\s*["\']([^"\']+)["\']', "aws_key"),
    (r'aws_secret_access_key\s*=\s*["\']([^"\']+)["\']', "aws_secret"),
    (r'AKIA[0-9A-Z]{16}', "aws_key"),
    (r'sk_live_[0-9a-zA-Z]{24,}', "stripe_key"),
    (r'xoxb-[0-9a-zA-Z-]{10,}', "slack_token"),
    (r'ghp_[0-9a-zA-Z]{36}', "github_token"),
]


def scan_secrets(repo_path: Path, graph: Graph) -> List[Node]:
    """Scan for hardcoded secrets and credentials"""
    nodes = []
    
    # Files to scan
    code_files = list(repo_path.rglob("*.py")) + list(repo_path.rglob("*.js")) + \
                 list(repo_path.rglob("*.ts")) + list(repo_path.rglob("*.yml")) + \
                 list(repo_path.rglob("*.yaml")) + list(repo_path.rglob("*.json"))
    
    # Skip node_modules, venv, etc.
    code_files = [f for f in code_files if not any(
        skip in str(f) for skip in ["node_modules", "__pycache__", ".venv", "venv", ".git"]
    )]
    
    for file_path in code_files:
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                lines = content.split('\n')
            
            for line_num, line in enumerate(lines, 1):
                for pattern, secret_type in SECRET_PATTERNS:
                    matches = re.finditer(pattern, line, re.IGNORECASE)
                    for match in matches:
                        secret_value = match.group(1) if match.groups() else match.group(0)
                        
                        # Redact secret (show only first few chars)
                        redacted = secret_value[:8] + "..." if len(secret_value) > 8 else secret_value
                        
                        secret_node = Node(
                            id=f"secret-{file_path.stem}-{line_num}-{secret_type}",
                            type=NodeType.SECRET,
                            name=f"{secret_type} at {file_path.name}:{line_num}",
                            labels=["secret", "security", secret_type],
                            props={
                                "file": str(file_path),
                                "line": line_num,
                                "type": secret_type,
                                "redacted": redacted,
                                "severity": "high"
                            }
                        )
                        nodes.append(secret_node)
                        graph.add_node(secret_node)
        
        except Exception as e:
            print(f"Error scanning {file_path} for secrets: {e}")
            continue
    
    return nodes
