"""Detect API endpoints from code"""

import re
import ast
from pathlib import Path
from typing import List
from archscribe.core.metamodel import Node, NodeType, Edge, EdgeKind, Graph


def scan_endpoints(repo_path: Path, graph: Graph) -> List[Node]:
    """Scan for API endpoints (Flask, FastAPI, Express, etc.)"""
    nodes = []
    
    # Python files (Flask, FastAPI)
    python_files = list(repo_path.rglob("*.py"))
    for py_file in python_files:
        if "test" in str(py_file) or "__pycache__" in str(py_file):
            continue
        
        try:
            with open(py_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Flask routes
            flask_routes = re.finditer(r'@app\.route\(["\']([^"\']+)["\']', content)
            for match in flask_routes:
                path = match.group(1)
                # Get HTTP method (default GET)
                method = "GET"
                method_match = re.search(r'methods\s*=\s*\[["\'](\w+)["\']', content[match.end():match.end()+200])
                if method_match:
                    method = method_match.group(1)
                
                endpoint_node = Node(
                    id=f"endpoint-{py_file.stem}-{path.replace('/', '-')}",
                    type=NodeType.ENDPOINT,
                    name=f"{method} {path}",
                    labels=["endpoint", "flask", method.lower()],
                    props={
                        "file": str(py_file),
                        "path": path,
                        "method": method,
                        "framework": "flask",
                        "public": True  # Default, can be refined
                    }
                )
                nodes.append(endpoint_node)
                graph.add_node(endpoint_node)
            
            # FastAPI routes
            fastapi_routes = re.finditer(r'@(app|router)\.(get|post|put|delete|patch)\(["\']([^"\']+)["\']', content)
            for match in fastapi_routes:
                method = match.group(2).upper()
                path = match.group(3)
                
                endpoint_node = Node(
                    id=f"endpoint-{py_file.stem}-{path.replace('/', '-')}",
                    type=NodeType.ENDPOINT,
                    name=f"{method} {path}",
                    labels=["endpoint", "fastapi", method.lower()],
                    props={
                        "file": str(py_file),
                        "path": path,
                        "method": method,
                        "framework": "fastapi",
                        "public": True
                    }
                )
                nodes.append(endpoint_node)
                graph.add_node(endpoint_node)
        
        except Exception as e:
            print(f"Error scanning {py_file} for endpoints: {e}")
            continue
    
    # JavaScript/TypeScript files (Express, NestJS)
    js_files = list(repo_path.rglob("*.js")) + list(repo_path.rglob("*.ts"))
    for js_file in js_files:
        if "test" in str(js_file) or "node_modules" in str(js_file):
            continue
        
        try:
            with open(js_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Express routes
            express_routes = re.finditer(r'\.(get|post|put|delete|patch)\(["\']([^"\']+)["\']', content)
            for match in express_routes:
                method = match.group(1).upper()
                path = match.group(2)
                
                endpoint_node = Node(
                    id=f"endpoint-{js_file.stem}-{path.replace('/', '-')}",
                    type=NodeType.ENDPOINT,
                    name=f"{method} {path}",
                    labels=["endpoint", "express", method.lower()],
                    props={
                        "file": str(js_file),
                        "path": path,
                        "method": method,
                        "framework": "express",
                        "public": True
                    }
                )
                nodes.append(endpoint_node)
                graph.add_node(endpoint_node)
        
        except Exception as e:
            print(f"Error scanning {js_file} for endpoints: {e}")
            continue
    
    return nodes
