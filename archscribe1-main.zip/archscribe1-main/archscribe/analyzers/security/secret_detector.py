"""Detect secrets and hardcoded credentials"""

from pathlib import Path
import re
from typing import List
from archscribe.core.metamodel import Node, NodeType, Edge, EdgeKind, Graph


def scan_secrets(repo_path: Path, graph: Graph) -> List[Node]:
    """Scan for hardcoded secrets and credentials"""
    nodes = []
    secret_patterns = [
        (r'["\']?api[_-]?key["\']?\s*[:=]\s*["\']([A-Za-z0-9_\-]{20,})["\']', "API Key"),
        (r'["\']?secret[_-]?key["\']?\s*[:=]\s*["\']([A-Za-z0-9_\-]{20,})["\']', "Secret Key"),
        (r'["\']?password["\']?\s*[:=]\s*["\']([^"\']+)["\']', "Password"),
        (r'["\']?aws[_-]?access[_-]?key["\']?\s*[:=]\s*["\']([A-Z0-9]{20})["\']', "AWS Access Key"),
        (r'["\']?aws[_-]?secret[_-]?key["\']?\s*[:=]\s*["\']([A-Za-z0-9/+=]{40})["\']', "AWS Secret Key"),
        (r'["\']?token["\']?\s*[:=]\s*["\']([A-Za-z0-9_\-]{20,})["\']', "Token"),
    ]
    
    code_files = list(repo_path.rglob("*.py")) + list(repo_path.rglob("*.js")) + list(repo_path.rglob("*.ts")) + list(repo_path.rglob("*.java"))
    
    for code_file in code_files:
        if "node_modules" in str(code_file) or "__pycache__" in str(code_file) or ".git" in str(code_file):
            continue
        
        try:
            with open(code_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            line_num = 0
            for line in content.split('\n'):
                line_num += 1
                for pattern, secret_type in secret_patterns:
                    matches = re.finditer(pattern, line, re.IGNORECASE)
                    for match in matches:
                        secret_value = match.group(1)
                        # Don't store the actual secret, just flag it
                        secret_node = Node(
                            id=f"secret-{code_file.stem}-{line_num}",
                            type=NodeType.SECRET,
                            name=f"{secret_type} in {code_file.name}",
                            props={
                                "type": secret_type,
                                "file": str(code_file.relative_to(repo_path)),
                                "line": line_num,
                                "severity": "high"
                            }
                        )
                        nodes.append(secret_node)
                        graph.add_node(secret_node)
                        
                        # Try to link to nearby functions/endpoints
                        # This is a simplified approach
                        
        except Exception:
            continue
    
    return nodes

