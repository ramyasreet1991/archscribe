"""Security analyzers for vulnerability detection"""
