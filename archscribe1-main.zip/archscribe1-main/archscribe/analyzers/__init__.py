"""Analyzers for different languages and technologies"""
