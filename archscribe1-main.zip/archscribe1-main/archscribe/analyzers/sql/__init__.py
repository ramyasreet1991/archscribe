"""SQL migration and schema analyzers"""
