"""Analyze SQL files and migrations"""

from pathlib import Path
import re
from typing import List
from archscribe.core.metamodel import Table, Column, Graph


def scan_sql_files(repo_path: Path, graph: Graph) -> List[Table]:
    """Scan SQL files for table definitions"""
    tables = []
    sql_files = list(repo_path.rglob("*.sql"))
    
    for sql_file in sql_files:
        try:
            with open(sql_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Extract CREATE TABLE statements
            create_table_pattern = r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:`)?(\w+)(?:`)?\s*\(([^;]+)\)'
            matches = re.finditer(create_table_pattern, content, re.IGNORECASE | re.DOTALL)
            
            for match in matches:
                table_name = match.group(1)
                columns_def = match.group(2)
                
                columns = _parse_columns(columns_def)
                
                table = Table(
                    name=table_name,
                    columns=columns,
                    props={"source_file": str(sql_file.relative_to(repo_path))}
                )
                tables.append(table)
                graph.add_table(table)
        
        except Exception:
            continue
    
    return tables


def _parse_columns(columns_def: str) -> List[Column]:
    """Parse column definitions from SQL"""
    columns = []
    lines = [line.strip() for line in columns_def.split(',')]
    
    for line in lines:
        if not line or line.upper().startswith('PRIMARY KEY') or line.upper().startswith('FOREIGN KEY'):
            continue
        
        # Extract column name and type
        parts = line.split()
        if not parts:
            continue
        
        col_name = parts[0].strip('`"\'')
        col_type = parts[1].upper() if len(parts) > 1 else "TEXT"
        
        nullable = 'NOT NULL' not in line.upper()
        primary_key = 'PRIMARY KEY' in line.upper()
        unique = 'UNIQUE' in line.upper()
        
        # Check for foreign key
        foreign_key = False
        fk_target_table = None
        fk_target_column = None
        
        fk_match = re.search(r'REFERENCES\s+(\w+)\s*\((\w+)\)', line, re.IGNORECASE)
        if fk_match:
            foreign_key = True
            fk_target_table = fk_match.group(1)
            fk_target_column = fk_match.group(2)
        
        column = Column(
            name=col_name,
            type=col_type,
            nullable=nullable,
            primary_key=primary_key,
            foreign_key=foreign_key,
            fk_target_table=fk_target_table,
            fk_target_column=fk_target_column,
            unique=unique
        )
        columns.append(column)
    
    return columns


def scan_django_migrations(repo_path: Path, graph: Graph) -> List[Table]:
    """Scan Django migration files"""
    tables = []
    migration_files = list((repo_path / "migrations").rglob("*.py"))
    
    for mig_file in migration_files:
        if "__init__" in str(mig_file):
            continue
        
        try:
            with open(mig_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Look for CreateModel operations
            create_model_pattern = r'CreateModel\([\'"]([^\'"]+)[\'"]'
            models = re.findall(create_model_pattern, content)
            
            for model_name in models:
                # Try to extract fields (simplified)
                table = Table(
                    name=model_name.lower(),
                    props={"source_file": str(mig_file.relative_to(repo_path)), "framework": "django"}
                )
                tables.append(table)
                graph.add_table(table)
        
        except Exception:
            continue
    
    return tables

