"""Extract ERD from SQL migrations"""

from pathlib import Path
from typing import List
import re
from archscribe.core.metamodel import Table, Column, Graph


def scan_sql_migrations(repo_path: Path, graph: Graph) -> List[Table]:
    """Scan for SQL migration files and extract table definitions"""
    tables = []
    migration_dirs = ['migrations', 'db/migrate', 'db/migrations', 'sql/migrations']
    sql_files = []
    
    # Find migration directories
    for mig_dir in migration_dirs:
        mig_path = repo_path / mig_dir
        if mig_path.exists():
            sql_files.extend(list(mig_path.rglob("*.sql")))
    
    # Also search for any SQL files
    if not sql_files:
        sql_files = list(repo_path.rglob("*.sql"))
    
    for sql_file in sql_files:
        try:
            with open(sql_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parse CREATE TABLE statements
            create_table_pattern = r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:`)?(\w+)(?:`)?\s*\((.*?)\)'
            matches = re.finditer(create_table_pattern, content, re.IGNORECASE | re.DOTALL)
            
            for match in matches:
                table_name = match.group(1)
                table_body = match.group(2)
                
                columns = []
                
                # Parse column definitions
                column_pattern = r'(?:`)?(\w+)(?:`)?\s+(\w+(?:\([^)]+\))?)\s*([^,]*?)(?:,|$)'
                column_matches = re.finditer(r'(?:`)?(\w+)(?:`)?\s+(\w+(?:\([^)]+\))?)\s*([^,]*?)(?:,|$)', table_body)
                
                for col_match in column_matches:
                    col_name = col_match.group(1)
                    col_type = col_match.group(2).lower()
                    col_attrs = col_match.group(3).lower()
                    
                    # Determine column properties
                    nullable = 'NOT NULL' not in col_attrs
                    primary_key = 'PRIMARY KEY' in col_attrs or col_name == 'id'
                    unique = 'UNIQUE' in col_attrs
                    indexed = 'INDEX' in col_attrs or 'KEY' in col_attrs
                    foreign_key = 'REFERENCES' in col_attrs or 'FOREIGN KEY' in col_attrs
                    
                    fk_target_table = None
                    fk_target_column = None
                    
                    if foreign_key:
                        # Extract foreign key reference
                        fk_match = re.search(r'REFERENCES\s+(?:`)?(\w+)(?:`)?\s*\((\w+)\)', col_attrs, re.IGNORECASE)
                        if fk_match:
                            fk_target_table = fk_match.group(1)
                            fk_target_column = fk_match.group(2)
                    
                    column = Column(
                        name=col_name,
                        type=col_type,
                        nullable=nullable,
                        primary_key=primary_key,
                        foreign_key=foreign_key,
                        fk_target_table=fk_target_table,
                        fk_target_column=fk_target_column or "id",
                        indexed=indexed,
                        unique=unique
                    )
                    columns.append(column)
                
                if columns:
                    table = Table(
                        name=table_name,
                        columns=columns,
                        tags=["sql", "migration"],
                        props={
                            "source_file": str(sql_file.relative_to(repo_path))
                        }
                    )
                    tables.append(table)
                    graph.add_table(table)
        
        except Exception as e:
            print(f"Error parsing SQL file {sql_file}: {e}")
            continue
    
    return tables

