"""Analyze infrastructure files (Docker, Kubernetes, Terraform)"""

from pathlib import Path
import yaml
import json
import re
from typing import List
from archscribe.core.metamodel import Node, NodeType, Edge, EdgeKind, Graph


def scan_dockerfiles(repo_path: Path, graph: Graph) -> List[Node]:
    """Scan for Dockerfiles and docker-compose files"""
    nodes = []
    
    # Scan Dockerfile
    dockerfile = repo_path / "Dockerfile"
    if dockerfile.exists():
        container_node = Node(
            id="container-main",
            type=NodeType.CONTAINER,
            name="Main Container",
            props={"type": "docker", "file": "Dockerfile"}
        )
        nodes.append(container_node)
        graph.add_node(container_node)
    
    # Scan docker-compose.yml
    docker_compose_files = list(repo_path.glob("docker-compose*.yml")) + list(repo_path.glob("docker-compose*.yaml"))
    
    for compose_file in docker_compose_files:
        try:
            with open(compose_file, 'r') as f:
                data = yaml.safe_load(f)
            
            if "services" in data:
                for service_name, service_config in data["services"].items():
                    service_node = Node(
                        id=f"service-{service_name}",
                        type=NodeType.SERVICE,
                        name=service_name,
                        props={
                            "type": "docker-compose",
                            "file": str(compose_file.relative_to(repo_path)),
                            "image": service_config.get("image", ""),
                            "ports": service_config.get("ports", [])
                        }
                    )
                    nodes.append(service_node)
                    graph.add_node(service_node)
        
        except Exception:
            continue
    
    return nodes


def scan_kubernetes(repo_path: Path, graph: Graph) -> List[Node]:
    """Scan Kubernetes manifest files"""
    nodes = []
    k8s_files = list(repo_path.rglob("*.yaml")) + list(repo_path.rglob("*.yml"))
    
    for k8s_file in k8s_files:
        if "k8s" not in str(k8s_file) and "kubernetes" not in str(k8s_file) and "helm" not in str(k8s_file):
            continue
        
        try:
            with open(k8s_file, 'r') as f:
                data = yaml.safe_load(f)
            
            if not data:
                continue
            
            kind = data.get("kind", "").lower()
            metadata = data.get("metadata", {})
            name = metadata.get("name", k8s_file.stem)
            
            if kind in ["deployment", "service", "statefulset", "daemonset"]:
                node_type = NodeType.SERVICE if kind == "service" else NodeType.CONTAINER
                
                node = Node(
                    id=f"k8s-{kind}-{name}",
                    type=node_type,
                    name=name,
                    props={
                        "kind": kind,
                        "namespace": metadata.get("namespace", "default"),
                        "file": str(k8s_file.relative_to(repo_path))
                    }
                )
                nodes.append(node)
                graph.add_node(node)
        
        except Exception:
            continue
    
    return nodes


def scan_terraform(repo_path: Path, graph: Graph) -> List[Node]:
    """Scan Terraform files for infrastructure resources"""
    nodes = []
    tf_files = list(repo_path.rglob("*.tf"))
    
    for tf_file in tf_files:
        try:
            with open(tf_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Extract resource definitions
            resource_pattern = r'resource\s+["\']([^"\']+)["\']\s+["\']([^"\']+)["\']'
            resources = re.findall(resource_pattern, content)
            
            for resource_type, resource_name in resources:
                # Map common resource types to node types
                node_type = NodeType.SERVICE
                if "database" in resource_type or "db" in resource_type or "rds" in resource_type:
                    node_type = NodeType.DATABASE
                elif "queue" in resource_type or "sqs" in resource_type:
                    node_type = NodeType.QUEUE
                elif "bucket" in resource_type or "s3" in resource_type:
                    node_type = NodeType.EXTERNAL
                
                node = Node(
                    id=f"tf-{resource_type}-{resource_name}",
                    type=node_type,
                    name=resource_name,
                    props={
                        "resource_type": resource_type,
                        "provider": "terraform",
                        "file": str(tf_file.relative_to(repo_path))
                    }
                )
                nodes.append(node)
                graph.add_node(node)
        
        except Exception:
            continue
    
    return nodes

