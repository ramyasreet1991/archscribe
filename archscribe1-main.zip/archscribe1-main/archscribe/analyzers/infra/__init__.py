"""Infrastructure analyzers (Docker, K8s, Terraform, etc.)"""
