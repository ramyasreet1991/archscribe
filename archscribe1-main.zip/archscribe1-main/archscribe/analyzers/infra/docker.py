"""Analyze Docker and docker-compose files"""

from pathlib import Path
from typing import List
import yaml
from archscribe.core.metamodel import Node, NodeType, Edge, EdgeKind, Graph


def scan_docker(repo_path: Path, graph: Graph) -> List[Node]:
    """Scan for Dockerfile and docker-compose.yml"""
    nodes = []
    
    # Scan for Dockerfiles
    dockerfiles = list(repo_path.rglob("Dockerfile*"))
    for dockerfile in dockerfiles:
        try:
            with open(dockerfile, 'r') as f:
                content = f.read()
            
            # Extract base image
            base_image = None
            for line in content.split('\n'):
                if line.strip().startswith('FROM'):
                    base_image = line.split('FROM')[1].strip().split()[0]
                    break
            
            container_node = Node(
                id=f"container-{dockerfile.stem}",
                type=NodeType.CONTAINER,
                name=dockerfile.stem,
                labels=["docker"],
                props={
                    "file": str(dockerfile),
                    "base_image": base_image,
                    "type": "dockerfile"
                }
            )
            nodes.append(container_node)
            graph.add_node(container_node)
        except Exception as e:
            print(f"Error parsing {dockerfile}: {e}")
    
    # Scan for docker-compose.yml
    compose_files = list(repo_path.rglob("docker-compose*.yml")) + list(repo_path.rglob("docker-compose*.yaml"))
    for compose_file in compose_files:
        try:
            with open(compose_file, 'r') as f:
                compose_data = yaml.safe_load(f)
            
            if not compose_data or 'services' not in compose_data:
                continue
            
            for service_name, service_config in compose_data['services'].items():
                service_node = Node(
                    id=f"service-{service_name}",
                    type=NodeType.SERVICE,
                    name=service_name,
                    labels=["docker-compose"],
                    props={
                        "file": str(compose_file),
                        "image": service_config.get("image"),
                        "ports": service_config.get("ports", []),
                        "environment": list(service_config.get("environment", {}).keys()) if isinstance(service_config.get("environment"), dict) else service_config.get("environment", [])
                    }
                )
                nodes.append(service_node)
                graph.add_node(service_node)
                
                # Check for dependencies
                if "depends_on" in service_config:
                    for dep in service_config["depends_on"]:
                        dep_edge = Edge(
                            from_node=service_node.id,
                            to_node=f"service-{dep}",
                            kind=EdgeKind.DEPENDS_ON,
                            props={"source": "docker-compose"}
                        )
                        graph.add_edge(dep_edge)
        
        except Exception as e:
            print(f"Error parsing {compose_file}: {e}")
    
    return nodes
