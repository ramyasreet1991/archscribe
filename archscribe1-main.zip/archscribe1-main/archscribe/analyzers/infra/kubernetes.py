"""Analyze Kubernetes manifests"""

from pathlib import Path
from typing import List
import yaml
from archscribe.core.metamodel import Node, NodeType, Graph, Edge, EdgeKind


def scan_kubernetes(repo_path: Path, graph: Graph) -> List[Node]:
    """Scan for Kubernetes manifest files"""
    nodes = []
    k8s_files = list(repo_path.rglob("*.yaml")) + list(repo_path.rglob("*.yml"))
    k8s_dirs = ['k8s', 'kubernetes', 'helm', 'charts']
    
    for k8s_file in k8s_files:
        # Check if it's in a k8s directory
        if not any(k8s_dir in str(k8s_file) for k8s_dir in k8s_dirs):
            continue
        
        try:
            with open(k8s_file, 'r') as f:
                # Try to parse as YAML
                try:
                    manifest = yaml.safe_load(f)
                except yaml.YAMLError:
                    continue
                
                if not manifest or 'kind' not in manifest:
                    continue
                
                kind = manifest['kind']
                metadata = manifest.get('metadata', {})
                name = metadata.get('name', 'unknown')
                namespace = metadata.get('namespace', 'default')
                
                if kind == 'Service':
                    service_node = Node(
                        id=f"k8s:service:{namespace}:{name}",
                        type=NodeType.SERVICE,
                        name=name,
                        labels=["kubernetes", "service", namespace],
                        props={
                            "kind": "Service",
                            "namespace": namespace,
                            "source_file": str(k8s_file.relative_to(repo_path)),
                            "ports": manifest.get('spec', {}).get('ports', [])
                        }
                    )
                    nodes.append(service_node)
                    graph.add_node(service_node)
                
                elif kind == 'Deployment':
                    deployment_node = Node(
                        id=f"k8s:deployment:{namespace}:{name}",
                        type=NodeType.CONTAINER,
                        name=name,
                        labels=["kubernetes", "deployment", namespace],
                        props={
                            "kind": "Deployment",
                            "namespace": namespace,
                            "source_file": str(k8s_file.relative_to(repo_path)),
                            "replicas": manifest.get('spec', {}).get('replicas', 1)
                        }
                    )
                    nodes.append(deployment_node)
                    graph.add_node(deployment_node)
        
        except Exception as e:
            print(f"Error processing Kubernetes file {k8s_file}: {e}")
    
    return nodes

