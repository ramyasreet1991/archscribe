"""Entry point for archscribe CLI"""

from archscribe.cli.main import app

def main():
    """Main entry point for CLI"""
    app()

if __name__ == "__main__":
    main()

