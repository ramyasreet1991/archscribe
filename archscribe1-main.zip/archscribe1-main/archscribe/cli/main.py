"""Main CLI entry point"""

import typer
from pathlib import Path
from typing import List, Optional
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

from archscribe.core.metamodel import Graph
from archscribe.core.config import load_config, ArchScribeConfig
from archscribe.core.kg_export import KnowledgeGraphExporter
from archscribe.core.security import SecurityAnalyzer
from archscribe.scanner import Scanner
from archscribe.renderers.mermaid import render_mermaid
from archscribe.renderers.drawio import render_drawio
from archscribe.renderers.plantuml import render_plantuml
from archscribe.renderers.csv import render_erd_csv

app = typer.Typer(help="ArchScribe - Automatic Architecture & ERD Diagrams from Code")
console = Console()


@app.command()
def scan(
    repo: str = typer.Argument(..., help="Repository path or URL"),
    targets: List[str] = typer.Option(["c4-container", "erd"], "--targets", "-t", help="Diagram targets"),
    formats: List[str] = typer.Option(["mermaid", "drawio"], "--formats", "-f", help="Output formats"),
    out: Path = typer.Option(Path("diagrams"), "--out", "-o", help="Output directory"),
    config: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path"),
    cpg: bool = typer.Option(True, "--cpg/--no-cpg", help="Enable CPG extraction"),
    kg: bool = typer.Option(True, "--kg/--no-kg", help="Enable knowledge graph generation"),
    security: bool = typer.Option(True, "--security/--no-security", help="Enable security analysis"),
    neo4j_uri: Optional[str] = typer.Option(None, "--neo4j-uri", help="Neo4j URI"),
    neo4j_user: Optional[str] = typer.Option(None, "--neo4j-user", help="Neo4j username"),
    neo4j_password: Optional[str] = typer.Option(None, "--neo4j-password", help="Neo4j password"),
):
    """Scan repository and generate diagrams"""
    console.print("[bold green]ArchScribe Scanner[/bold green]")
    console.print(f"Repository: {repo}")
    console.print(f"Targets: {', '.join(targets)}")
    console.print(f"Formats: {', '.join(formats)}")
    console.print(f"Output: {out}")
    
    # Load config if provided
    config_obj = None
    if config and config.exists():
        config_obj = load_config(config)
        console.print(f"Loaded config from {config}")
    
    # Initialize scanner
    repo_path = Path(repo)
    if not repo_path.exists():
        console.print(f"[red]Error: Repository path {repo} does not exist[/red]")
        raise typer.Exit(1)
    
    # Create output directories
    out.mkdir(parents=True, exist_ok=True)
    diagrams_dir = out / "diagrams"
    reports_dir = out / "reports"
    diagrams_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)
    
    # Initialize graph
    graph = Graph()
    
    # Scan repository
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Scanning repository...", total=None)
        
        scanner = Scanner(repo_path, graph, config_obj)
        
        # Run analyzers
        progress.update(task, description="Analyzing Python dependencies...")
        scanner.scan_python()
        
        progress.update(task, description="Analyzing JavaScript dependencies...")
        scanner.scan_javascript()
        
        progress.update(task, description="Analyzing infrastructure...")
        scanner.scan_infrastructure()
        
        progress.update(task, description="Extracting ERD...")
        scanner.scan_erd()
        
        if security:
            progress.update(task, description="Scanning for security issues...")
            scanner.scan_security()
        
        if cpg:
            progress.update(task, description="Extracting Code Property Graph...")
            scanner.extract_cpg(reports_dir)
        
        progress.update(task, description="Generating diagrams...")
    
    # Generate diagrams
    console.print("\n[bold]Generating diagrams...[/bold]")
    
    for target in targets:
        target_dir = diagrams_dir / target.replace("c4-", "")
        target_dir.mkdir(parents=True, exist_ok=True)
        
        for fmt in formats:
            try:
                if fmt == "mermaid":
                    content = render_mermaid(target, graph)
                    output_file = target_dir / f"{target}.mmd"
                    output_file.write_text(content)
                    console.print(f"  ✓ Generated {output_file}")
                
                elif fmt == "drawio":
                    content = render_drawio(target, graph)
                    output_file = target_dir / f"{target}.drawio.xml"
                    output_file.write_text(content)
                    console.print(f"  ✓ Generated {output_file}")
                
                elif fmt == "plantuml":
                    content = render_plantuml(target, graph)
                    output_file = target_dir / f"{target}.puml"
                    output_file.write_text(content)
                    console.print(f"  ✓ Generated {output_file}")
                
                elif fmt == "csv" and target == "erd":
                    content = render_erd_csv(graph)
                    output_file = target_dir / "erd.csv"
                    output_file.write_text(content)
                    console.print(f"  ✓ Generated {output_file}")
            
            except Exception as e:
                console.print(f"  ✗ Error generating {target}.{fmt}: {e}")
    
    # Generate knowledge graph
    if kg:
        console.print("\n[bold]Generating knowledge graph...[/bold]")
        kg_exporter = KnowledgeGraphExporter(neo4j_uri, neo4j_user, neo4j_password)
        
        # Export to JSON
        json_file = reports_dir / "graph.json"
        kg_exporter.export_to_json(graph, json_file)
        console.print(f"  ✓ Exported graph to {json_file}")
        
        # Export to Cypher
        cypher_file = reports_dir / "graph.cypher"
        kg_exporter.export_to_cypher(graph, cypher_file)
        console.print(f"  ✓ Exported Cypher script to {cypher_file}")
        
        # Export to Neo4j if configured
        if neo4j_uri:
            console.print(f"  Exporting to Neo4j at {neo4j_uri}...")
            if kg_exporter.export_to_neo4j(graph):
                console.print("  ✓ Exported to Neo4j")
            else:
                console.print("  ✗ Failed to export to Neo4j")
        
        kg_exporter.close()
    
    # Generate security report
    if security:
        console.print("\n[bold]Generating security report...[/bold]")
        security_analyzer = SecurityAnalyzer(graph)
        report = security_analyzer.generate_security_report()
        
        # Save report
        report_file = reports_dir / "security-report.json"
        import json
        report_file.write_text(json.dumps(report, indent=2))
        console.print(f"  ✓ Generated security report: {report_file}")
        
        # Print summary
        console.print("\n[bold]Security Summary:[/bold]")
        summary = report["summary"]
        console.print(f"  Attack Paths: {summary['total_attack_paths']}")
        console.print(f"  Unauthenticated Endpoints: {summary['total_unauthenticated_endpoints']}")
        console.print(f"  Hardcoded Secrets: {summary['total_secrets']}")
        console.print(f"  SQL Injection Risks: {summary['total_sql_risks']}")
        console.print(f"  Privilege Escalation Paths: {summary['total_privilege_escalation']}")
    
    # Generate summary HTML
    console.print("\n[bold]Generating summary...[/bold]")
    summary_file = reports_dir / "summary.html"
    _generate_summary_html(graph, summary_file, out)
    console.print(f"  ✓ Generated summary: {summary_file}")
    
    console.print(f"\n[bold green]✓ Scan complete! Output in {out}[/bold green]")


def _generate_summary_html(graph: Graph, output_file: Path, base_dir: Path):
    """Generate HTML summary"""
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>ArchScribe Summary</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; }}
            h1 {{ color: #333; }}
            .metric {{ display: inline-block; margin: 10px; padding: 10px; background: #f0f0f0; border-radius: 5px; }}
            .metric-value {{ font-size: 24px; font-weight: bold; color: #0066cc; }}
            table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
            th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
            th {{ background-color: #4CAF50; color: white; }}
        </style>
    </head>
    <body>
        <h1>ArchScribe Summary</h1>
        
        <h2>Graph Statistics</h2>
        <div class="metric">
            <div class="metric-value">{len(graph.nodes)}</div>
            <div>Nodes</div>
        </div>
        <div class="metric">
            <div class="metric-value">{len(graph.edges)}</div>
            <div>Edges</div>
        </div>
        <div class="metric">
            <div class="metric-value">{len(graph.tables)}</div>
            <div>Tables</div>
        </div>
        
        <h2>Node Types</h2>
        <table>
            <tr><th>Type</th><th>Count</th></tr>
    """
    
    # Count nodes by type
    node_types = {}
    for node in graph.nodes:
        node_type = node.type.value
        node_types[node_type] = node_types.get(node_type, 0) + 1
    
    for node_type, count in sorted(node_types.items()):
        html += f"<tr><td>{node_type}</td><td>{count}</td></tr>"
    
    html += """
        </table>
        
        <h2>Diagrams</h2>
        <ul>
    """
    
    # List generated diagrams
    diagrams_dir = base_dir / "diagrams"
    if diagrams_dir.exists():
        for diagram_file in diagrams_dir.rglob("*"):
            if diagram_file.is_file():
                rel_path = diagram_file.relative_to(base_dir)
                html += f'<li><a href="{rel_path}">{rel_path}</a></li>'
    
    html += """
        </ul>
        
        <h2>Reports</h2>
        <ul>
    """
    
    # List reports
    reports_dir = base_dir / "reports"
    if reports_dir.exists():
        for report_file in reports_dir.rglob("*"):
            if report_file.is_file():
                rel_path = report_file.relative_to(base_dir)
                html += f'<li><a href="{rel_path}">{rel_path}</a></li>'
    
    html += """
        </ul>
    </body>
    </html>
    """
    
    output_file.write_text(html)


@app.command()
def dashboard(
    graph_json: Path = typer.Argument(..., help="Path to graph.json file"),
    neo4j_uri: Optional[str] = typer.Option(None, "--neo4j-uri", help="Neo4j URI"),
    neo4j_user: Optional[str] = typer.Option("neo4j", "--neo4j-user", help="Neo4j username"),
    neo4j_password: Optional[str] = typer.Option("password", "--neo4j-password", help="Neo4j password"),
    port: int = typer.Option(8501, "--port", "-p", help="Port for Streamlit"),
):
    """Launch Streamlit dashboard"""
    import subprocess
    import os
    
    # Load graph
    if not graph_json.exists():
        console.print(f"[red]Error: Graph file {graph_json} does not exist[/red]")
        raise typer.Exit(1)
    
    console.print("[yellow]Loading graph...[/yellow]")
    console.print("[yellow]Starting Streamlit dashboard...[/yellow]")
    console.print("[yellow]Dashboard will open in your browser[/yellow]")
    
    # Set environment variables for Streamlit
    os.environ["GRAPH_JSON"] = str(graph_json.absolute())
    if neo4j_uri:
        os.environ["NEO4J_URI"] = neo4j_uri
        os.environ["NEO4J_USER"] = neo4j_user or "neo4j"
        os.environ["NEO4J_PASSWORD"] = neo4j_password or "password"
    
    # Launch Streamlit
    dashboard_path = Path(__file__).parent.parent.parent / "archscribe" / "dashboard" / "streamlit_app.py"
    import sys
    import streamlit.web.cli as stcli
    
    # Set up sys.argv for Streamlit
    sys.argv = ["streamlit", "run", str(dashboard_path), "--server.port", str(port)]
    stcli.main()




if __name__ == "__main__":
    app()

