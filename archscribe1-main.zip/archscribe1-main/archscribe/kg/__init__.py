"""Knowledge Graph generation and Neo4j integration"""

