"""Export graph to knowledge graph formats (Cypher, JSON-LD, GraphML)"""

from pathlib import Path
from typing import List, Dict, Any
import json
from archscribe.core.metamodel import Graph, Node, Edge, Table


def export_to_cypher(graph: Graph, out_path: Path) -> str:
    """Export graph to Cypher script for Neo4j"""
    lines = []
    lines.append("// ArchScribe Knowledge Graph Export")
    lines.append("// Generated Cypher script for Neo4j")
    lines.append("")
    
    # Create nodes
    for node in graph.nodes:
        labels = ":".join([node.type.value.capitalize()] + [label.capitalize() for label in node.labels])
        props = {k: v for k, v in node.props.items() if isinstance(v, (str, int, float, bool))}
        props_str = ", ".join([f"{k}: {json.dumps(v)}" for k, v in props.items()])
        
        if props_str:
            lines.append(f"CREATE (n:{labels} {{id: {json.dumps(node.id)}, name: {json.dumps(node.name)}, {props_str}}})")
        else:
            lines.append(f"CREATE (n:{labels} {{id: {json.dumps(node.id)}, name: {json.dumps(node.name)}}})")
    
    lines.append("")
    
    # Create edges
    for edge in graph.edges:
        props = {k: v for k, v in edge.props.items() if isinstance(v, (str, int, float, bool))}
        props_str = ", ".join([f"{k}: {json.dumps(v)}" for k, v in props.items()]) if props else ""
        
        if props_str:
            lines.append(
                f"MATCH (a), (b) "
                f"WHERE a.id = {json.dumps(edge.from_node)} AND b.id = {json.dumps(edge.to_node)} "
                f"CREATE (a)-[r:{edge.kind.value.upper()} {{{props_str}}}]->(b)"
            )
        else:
            lines.append(
                f"MATCH (a), (b) "
                f"WHERE a.id = {json.dumps(edge.from_node)} AND b.id = {json.dumps(edge.to_node)} "
                f"CREATE (a)-[r:{edge.kind.value.upper()}]->(b)"
            )
    
    lines.append("")
    
    # Create table nodes and relationships
    for table in graph.tables:
        table_id = f"table:{table.name}"
        lines.append(f"CREATE (t:Table {{id: {json.dumps(table_id)}, name: {json.dumps(table.name)}, schema: {json.dumps(table.schema or 'default')}}})")
        
        for column in table.columns:
            col_id = f"column:{table.name}:{column.name}"
            lines.append(
                f"CREATE (c:Column {{"
                f"id: {json.dumps(col_id)}, "
                f"name: {json.dumps(column.name)}, "
                f"type: {json.dumps(column.type)}, "
                f"primary_key: {str(column.primary_key).lower()}, "
                f"foreign_key: {str(column.foreign_key).lower()}, "
                f"nullable: {str(column.nullable).lower()}"
                f"}})"
            )
            lines.append(
                f"MATCH (t:Table), (c:Column) "
                f"WHERE t.id = {json.dumps(table_id)} AND c.id = {json.dumps(col_id)} "
                f"CREATE (t)-[:HAS_COLUMN]->(c)"
            )
            
            if column.foreign_key and column.fk_target_table:
                target_table_id = f"table:{column.fk_target_table}"
                lines.append(
                    f"MATCH (c:Column), (target:Table) "
                    f"WHERE c.id = {json.dumps(col_id)} AND target.id = {json.dumps(target_table_id)} "
                    f"CREATE (c)-[:REFERENCES]->(target)"
                )
    
    cypher_script = "\n".join(lines)
    
    # Write to file
    with open(out_path, 'w') as f:
        f.write(cypher_script)
    
    return cypher_script


def export_to_json_ld(graph: Graph, out_path: Path) -> Dict[str, Any]:
    """Export graph to JSON-LD format"""
    json_ld = {
        "@context": {
            "@vocab": "https://archscribe.dev/ontology#",
            "nodes": "@graph"
        },
        "@graph": []
    }
    
    # Export nodes
    for node in graph.nodes:
        node_data = {
            "@id": node.id,
            "@type": node.type.value,
            "name": node.name,
            "labels": node.labels,
            **node.props
        }
        json_ld["@graph"].append(node_data)
    
    # Export edges
    for edge in graph.edges:
        edge_data = {
            "@id": f"edge:{edge.from_node}:{edge.to_node}:{edge.kind.value}",
            "@type": "Relationship",
            "from": edge.from_node,
            "to": edge.to_node,
            "kind": edge.kind.value,
            **edge.props
        }
        json_ld["@graph"].append(edge_data)
    
    # Export tables
    for table in graph.tables:
        table_data = {
            "@id": f"table:{table.name}",
            "@type": "Table",
            "name": table.name,
            "schema": table.schema,
            "columns": [
                {
                    "name": col.name,
                    "type": col.type,
                    "primary_key": col.primary_key,
                    "foreign_key": col.foreign_key,
                    "nullable": col.nullable
                }
                for col in table.columns
            ]
        }
        json_ld["@graph"].append(table_data)
    
    # Write to file
    with open(out_path, 'w') as f:
        json.dump(json_ld, f, indent=2)
    
    return json_ld


def export_to_graphml(graph: Graph, out_path: Path) -> str:
    """Export graph to GraphML format"""
    from xml.etree import ElementTree as ET
    from xml.dom import minidom
    
    root = ET.Element("graphml")
    root.set("xmlns", "http://graphml.graphdrawing.org/xmlns")
    
    # Define attribute keys
    key_id = ET.SubElement(root, "key")
    key_id.set("id", "d0")
    key_id.set("for", "node")
    key_id.set("attr.name", "label")
    key_id.set("attr.type", "string")
    
    key_type = ET.SubElement(root, "key")
    key_type.set("id", "d1")
    key_type.set("for", "node")
    key_type.set("attr.name", "type")
    key_type.set("attr.type", "string")
    
    # Create graph
    graph_elem = ET.SubElement(root, "graph")
    graph_elem.set("id", "G")
    graph_elem.set("edgedefault", "directed")
    
    # Add nodes
    for node in graph.nodes:
        node_elem = ET.SubElement(graph_elem, "node")
        node_elem.set("id", node.id)
        data_label = ET.SubElement(node_elem, "data")
        data_label.set("key", "d0")
        data_label.text = node.name
        data_type = ET.SubElement(node_elem, "data")
        data_type.set("key", "d1")
        data_type.text = node.type.value
    
    # Add edges
    for edge in graph.edges:
        edge_elem = ET.SubElement(graph_elem, "edge")
        edge_elem.set("id", f"e{edge.from_node}{edge.to_node}")
        edge_elem.set("source", edge.from_node)
        edge_elem.set("target", edge.to_node)
        edge_elem.set("label", edge.kind.value)
    
    # Pretty print
    rough_string = ET.tostring(root, encoding='unicode')
    reparsed = minidom.parseString(rough_string)
    graphml = reparsed.toprettyxml(indent="  ")
    
    # Write to file
    with open(out_path, 'w') as f:
        f.write(graphml)
    
    return graphml

