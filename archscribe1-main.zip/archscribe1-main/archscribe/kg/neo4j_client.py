"""Neo4j client for knowledge graph operations"""

from typing import List, Dict, Any, Optional
from neo4j import GraphDatabase
import os
from rich import print as rprint


class Neo4jClient:
    """Client for Neo4j graph database operations"""
    
    def __init__(self, uri: str = None, user: str = None, password: str = None):
        """Initialize Neo4j client"""
        self.uri = uri or os.getenv("NEO4J_URI", "bolt://localhost:7687")
        self.user = user or os.getenv("NEO4J_USER", "neo4j")
        self.password = password or os.getenv("NEO4J_PASSWORD", "password")
        self.driver = None
    
    def connect(self):
        """Connect to Neo4j"""
        try:
            self.driver = GraphDatabase.driver(self.uri, auth=(self.user, self.password))
            self.driver.verify_connectivity()
            rprint(f"[green]✓[/green] Connected to Neo4j at {self.uri}")
            return True
        except Exception as e:
            rprint(f"[red]✗[/red] Failed to connect to Neo4j: {e}")
            return False
    
    def close(self):
        """Close Neo4j connection"""
        if self.driver:
            self.driver.close()
    
    def execute_cypher(self, cypher: str, parameters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Execute Cypher query"""
        if not self.driver:
            raise Exception("Not connected to Neo4j")
        
        with self.driver.session() as session:
            result = session.run(cypher, parameters or {})
            return [record.data() for record in result]
    
    def import_graph(self, graph_data: Dict[str, Any]):
        """Import graph data into Neo4j"""
        # This would import the graph using the Cypher export
        # For now, we'll use the execute_cypher method
        pass
    
    def find_attack_paths(self, source_labels: List[str], target_labels: List[str], max_depth: int = 5) -> List[Dict[str, Any]]:
        """Find attack paths from source to target nodes"""
        source_label_str = ":".join(source_labels)
        target_label_str = ":".join(target_labels)
        
        cypher = f"""
        MATCH path = (source:{source_label_str})-[*1..{max_depth}]->(target:{target_label_str})
        WHERE NOT (source)-[:REQUIRES_AUTH]->()
        RETURN path, length(path) as depth
        ORDER BY depth
        LIMIT 100
        """
        
        return self.execute_cypher(cypher)
    
    def find_secrets_in_code(self) -> List[Dict[str, Any]]:
        """Find all secrets in the codebase"""
        cypher = """
        MATCH (s:Secret)
        OPTIONAL MATCH (s)<-[:USES_SECRET]-(f:Function)
        RETURN s, collect(f) as functions
        """
        return self.execute_cypher(cypher)
    
    def find_unauthenticated_endpoints(self) -> List[Dict[str, Any]]:
        """Find endpoints without authentication"""
        cypher = """
        MATCH (e:Endpoint)
        WHERE NOT (e)-[:REQUIRES_AUTH]->()
        OPTIONAL MATCH path = (e)-[*1..3]->(db:Database)
        RETURN e, collect(path) as paths
        """
        return self.execute_cypher(cypher)
    
    def find_data_flow_paths(self, source: str, target: str, max_depth: int = 5) -> List[Dict[str, Any]]:
        """Find data flow paths from source to target"""
        cypher = f"""
        MATCH path = (source {{id: $source}})-[*1..{max_depth}]->(target {{id: $target}})
        WHERE ANY(rel in relationships(path) WHERE rel.kind IN ['calls', 'reads', 'writes'])
        RETURN path, length(path) as depth
        ORDER BY depth
        LIMIT 50
        """
        return self.execute_cypher(cypher, {"source": source, "target": target})
    
    def clear_database(self):
        """Clear all data from the database (use with caution!)"""
        cypher = "MATCH (n) DETACH DELETE n"
        self.execute_cypher(cypher)
        rprint("[yellow]⚠[/yellow] Database cleared")

