"""Streamlit app entry point"""

import streamlit as st
import json
import os
from pathlib import Path
from archscribe.core.metamodel import Graph
from archscribe.dashboard.dashboard import SecurityDashboard

# Load graph from environment variable
graph_json_path = os.getenv("GRAPH_JSON")
neo4j_uri = os.getenv("NEO4J_URI")
neo4j_user = os.getenv("NEO4J_USER", "neo4j")
neo4j_password = os.getenv("NEO4J_PASSWORD", "password")

if graph_json_path and Path(graph_json_path).exists():
    # Load graph
    with open(graph_json_path, 'r') as f:
        graph_data = json.load(f)
    
    # Reconstruct graph from JSON
    graph = Graph.from_dict(graph_data)
    
    # Create dashboard
    dashboard = SecurityDashboard(graph, neo4j_uri, neo4j_user, neo4j_password)
    dashboard.render()
elif graph_json_path:
    st.error(f"Graph JSON file not found: {graph_json_path}")
    st.info("Please run: archscribe scan ... to generate the graph.json file")
else:
    st.error("GRAPH_JSON environment variable not set. Please run: archscribe scan ...")
    st.info("Or set GRAPH_JSON environment variable to point to graph.json file")

