"""Streamlit dashboard for security visualization"""

import streamlit as st
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from typing import Dict, Any, List
from pathlib import Path
import json
from neo4j import GraphDatabase
from archscribe.core.metamodel import Graph
from archscribe.core.security import SecurityAnalyzer
from archscribe.core.kg_export import KnowledgeGraphExporter


class SecurityDashboard:
    """Streamlit dashboard for security analysis"""
    
    def __init__(self, graph: Graph, neo4j_uri: str = None, neo4j_user: str = None, 
                 neo4j_password: str = None):
        self.graph = graph
        self.security_analyzer = SecurityAnalyzer(graph)
        self.neo4j_uri = neo4j_uri
        self.neo4j_user = neo4j_user
        self.neo4j_password = neo4j_password
        
        # Initialize Neo4j connection if available
        self.neo4j_driver = None
        if neo4j_uri:
            try:
                self.neo4j_driver = GraphDatabase.driver(
                    neo4j_uri, auth=(neo4j_user, neo4j_password)
                )
            except Exception as e:
                st.warning(f"Could not connect to Neo4j: {e}")
    
    def render(self):
        """Render the dashboard"""
        st.set_page_config(page_title="ArchScribe Security Dashboard", layout="wide")
        
        st.title("🛡️ ArchScribe Security Dashboard")
        st.markdown("### Knowledge Graph-Powered Security Analysis")
        
        # Sidebar
        with st.sidebar:
            st.header("Configuration")
            view_mode = st.selectbox(
                "View Mode",
                ["Security Analysis", "Graph Explorer", "Attack Paths", "SAST Comparison"]
            )
            
            if self.neo4j_driver:
                st.success("✅ Neo4j Connected")
            else:
                st.warning("⚠️ Neo4j Not Connected")
        
        # Main content
        if view_mode == "Security Analysis":
            self._render_security_analysis()
        elif view_mode == "Graph Explorer":
            self._render_graph_explorer()
        elif view_mode == "Attack Paths":
            self._render_attack_paths()
        elif view_mode == "SAST Comparison":
            self._render_sast_comparison()
    
    def _render_security_analysis(self):
        """Render security analysis view"""
        st.header("Security Analysis Summary")
        
        # Generate security report
        report = self.security_analyzer.generate_security_report()
        summary = report["summary"]
        
        # Metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Attack Paths", summary["total_attack_paths"], delta=None)
        with col2:
            st.metric("Unauthenticated Endpoints", summary["total_unauthenticated_endpoints"], 
                     delta=None, delta_color="inverse")
        with col3:
            st.metric("Hardcoded Secrets", summary["total_secrets"], 
                     delta=None, delta_color="inverse")
        with col4:
            st.metric("SQL Injection Risks", summary["total_sql_risks"], 
                     delta=None, delta_color="inverse")
        
        # Attack paths
        st.subheader("🚨 Exploitable Attack Paths")
        if report["attack_paths"]:
            attack_paths_df = pd.DataFrame([
                {
                    "Endpoint": ap["endpoint"],
                    "Resource": ap["resource"],
                    "Severity": ap["severity"],
                    "Path Length": len(ap["path"])
                }
                for ap in report["attack_paths"]
            ])
            st.dataframe(attack_paths_df, use_container_width=True)
        else:
            st.info("No exploitable attack paths found")
        
        # Unauthenticated endpoints
        st.subheader("🔓 Unauthenticated Endpoints")
        if report["unauthenticated_endpoints"]:
            unauth_df = pd.DataFrame(report["unauthenticated_endpoints"])
            st.dataframe(unauth_df, use_container_width=True)
        else:
            st.info("All endpoints require authentication")
        
        # Hardcoded secrets
        st.subheader("🔑 Hardcoded Secrets")
        if report["hardcoded_secrets"]:
            secrets_df = pd.DataFrame(report["hardcoded_secrets"])
            st.dataframe(secrets_df, use_container_width=True)
        else:
            st.info("No hardcoded secrets found")
        
        # SQL injection risks
        st.subheader("💉 SQL Injection Risks")
        if report["sql_injection_risks"]:
            sql_risks_df = pd.DataFrame(report["sql_injection_risks"])
            st.dataframe(sql_risks_df, use_container_width=True)
        else:
            st.info("No SQL injection risks found")
    
    def _render_graph_explorer(self):
        """Render graph explorer view"""
        st.header("Graph Explorer")
        
        # Cypher query input
        if self.neo4j_driver:
            st.subheader("Cypher Query")
            query = st.text_area(
                "Enter Cypher query:",
                value="MATCH (n) RETURN n LIMIT 25",
                height=100
            )
            
            if st.button("Execute Query"):
                try:
                    with self.neo4j_driver.session() as session:
                        result = session.run(query)
                        records = [dict(record) for record in result]
                        
                        if records:
                            st.dataframe(pd.DataFrame(records), use_container_width=True)
                        else:
                            st.info("No results found")
                except Exception as e:
                    st.error(f"Query error: {e}")
            
            # Predefined queries
            st.subheader("Predefined Queries")
            query_options = {
                "All Nodes": "MATCH (n) RETURN n LIMIT 50",
                "All Edges": "MATCH (a)-[r]->(b) RETURN a, r, b LIMIT 50",
                "Public Endpoints": "MATCH (e:Endpoint {public: true}) RETURN e",
                "Secrets": "MATCH (s:Secret) RETURN s",
                "Attack Paths": """
                    MATCH (e:Endpoint {public: true})-[*1..5]->(r)
                    WHERE r:Database OR r:Secret
                    RETURN e, r
                """,
            }
            
            selected_query = st.selectbox("Select a query:", list(query_options.keys()))
            if st.button("Run Selected Query"):
                query = query_options[selected_query]
                try:
                    with self.neo4j_driver.session() as session:
                        result = session.run(query)
                        records = [dict(record) for record in result]
                        if records:
                            st.dataframe(pd.DataFrame(records), use_container_width=True)
                except Exception as e:
                    st.error(f"Query error: {e}")
        else:
            st.warning("Neo4j not connected. Please configure Neo4j connection.")
            
            # Fallback: show graph statistics
            st.subheader("Graph Statistics")
            stats = {
                "Total Nodes": len(self.graph.nodes),
                "Total Edges": len(self.graph.edges),
                "Total Tables": len(self.graph.tables),
                "Services": len([n for n in self.graph.nodes if n.type.value == "service"]),
                "Endpoints": len([n for n in self.graph.nodes if n.type.value == "endpoint"]),
                "Databases": len([n for n in self.graph.nodes if n.type.value == "db"]),
            }
            st.json(stats)
    
    def _render_attack_paths(self):
        """Render attack paths visualization"""
        st.header("Attack Path Visualization")
        
        attack_paths = self.security_analyzer.find_attack_paths()
        
        if attack_paths:
            # Select attack path to visualize
            path_options = {
                f"{ap['endpoint']} → {ap['resource']} ({ap['severity']})": ap
                for ap in attack_paths
            }
            selected = st.selectbox("Select attack path:", list(path_options.keys()))
            selected_path = path_options[selected]
            
            # Visualize path
            st.subheader(f"Path: {selected_path['endpoint']} → {selected_path['resource']}")
            st.write(f"**Severity:** {selected_path['severity']}")
            st.write(f"**Path:** {' → '.join(selected_path['path'])}")
            
            # Create network graph
            G = nx.DiGraph()
            path_nodes = selected_path['path']
            
            for i, node_id in enumerate(path_nodes):
                node = self.graph.get_node(node_id)
                if node:
                    G.add_node(node_id, label=node.name, type=node.type.value)
                    if i < len(path_nodes) - 1:
                        G.add_edge(node_id, path_nodes[i + 1])
            
            # Draw graph
            fig, ax = plt.subplots(figsize=(12, 8))
            pos = nx.spring_layout(G)
            nx.draw(G, pos, ax=ax, with_labels=True, node_color='lightblue', 
                   node_size=2000, font_size=10, arrows=True)
            st.pyplot(fig)
        else:
            st.info("No attack paths found")
    
    def _render_sast_comparison(self):
        """Render SAST vs Graph-based analysis comparison"""
        st.header("SAST vs Knowledge Graph Analysis")
        
        st.markdown("""
        ### Why Knowledge Graph Analysis Adds Value
        
        **SAST Alone:**
        - Finds potential vulnerabilities in isolation
        - High false positive rate
        - No attack path context
        - No prioritization based on exploitability
        
        **Knowledge Graph Analysis:**
        - Models full system architecture
        - Identifies real attack paths
        - Prioritizes based on exploitability
        - Context-aware risk assessment
        """)
        
        # Comparison metrics
        st.subheader("Comparison Metrics")
        
        # Generate mock SAST data for comparison
        sast_findings = {
            "total": 50,
            "high": 10,
            "medium": 25,
            "low": 15,
            "false_positives_estimated": 30
        }
        
        kg_findings = self.security_analyzer.generate_security_report()
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### SAST Findings")
            st.metric("Total Findings", sast_findings["total"])
            st.metric("High Severity", sast_findings["high"])
            st.metric("Estimated False Positives", sast_findings["false_positives_estimated"])
        
        with col2:
            st.markdown("#### Knowledge Graph Findings")
            st.metric("Exploitable Attack Paths", kg_findings["summary"]["total_attack_paths"])
            st.metric("Unauthenticated Endpoints", kg_findings["summary"]["total_unauthenticated_endpoints"])
            st.metric("Hardcoded Secrets", kg_findings["summary"]["total_secrets"])
        
        # Value proposition
        st.subheader("Business Value")
        value_points = [
            "🎯 **Focus on Real Risks**: Knowledge graph identifies actual exploitable paths",
            "⏱️ **Save Time**: Reduced false positives means less time on non-issues",
            "🔒 **Better Security**: Context-aware analysis catches architectural flaws",
            "📊 **Actionable Insights**: Prioritized findings with business impact",
        ]
        
        for point in value_points:
            st.markdown(point)
    
    def close(self):
        """Close Neo4j connection"""
        if self.neo4j_driver:
            self.neo4j_driver.close()

