"""Main scanner orchestrator"""

from pathlib import Path
from typing import Optional
from archscribe.core.metamodel import Graph
from archscribe.core.config import ArchScribeConfig
from archscribe.analyzers.python.python_requirements import scan_requirements
from archscribe.analyzers.python.sqlalchemy_erd import scan_sqlalchemy_models
from archscribe.analyzers.python.cpg import extract_cpg
from archscribe.analyzers.javascript.package_json import scan_package_json
from archscribe.analyzers.infra.docker import scan_docker
from archscribe.analyzers.security.secrets import scan_secrets
from archscribe.analyzers.security.endpoints import scan_endpoints


class Scanner:
    """Main scanner that orchestrates all analyzers"""
    
    def __init__(self, repo_path: Path, graph: Graph, config: Optional[ArchScribeConfig] = None):
        self.repo_path = repo_path
        self.graph = graph
        self.config = config
    
    def scan_python(self):
        """Scan Python code"""
        scan_requirements(self.repo_path, self.graph)
        # Additional Python analyzers can be added here
    
    def scan_javascript(self):
        """Scan JavaScript/TypeScript code"""
        scan_package_json(self.repo_path, self.graph)
        # Additional JavaScript analyzers can be added here
    
    def scan_infrastructure(self):
        """Scan infrastructure files"""
        scan_docker(self.repo_path, self.graph)
        # Additional infrastructure analyzers can be added here
    
    def scan_erd(self):
        """Scan for ERD extraction"""
        scan_sqlalchemy_models(self.repo_path, self.graph)
        # Additional ERD analyzers can be added here
    
    def scan_security(self):
        """Scan for security issues"""
        scan_secrets(self.repo_path, self.graph)
        scan_endpoints(self.repo_path, self.graph)
        # Additional security analyzers can be added here
    
    def extract_cpg(self, out_dir: Path):
        """Extract Code Property Graph"""
        extract_cpg(self.repo_path, out_dir)

