"""ArchScribe - Automatic Architecture & ERD Diagrams from Code"""

__version__ = "0.1.0"

