"""Visio VDX renderer (simplified)"""

from xml.etree import ElementTree as ET
from xml.dom import minidom
from archscribe.core.metamodel import Graph, Node, NodeType


def render_visio_vdx(profile: str, graph: Graph, title: str = "Architecture Diagram") -> str:
    """Render graph as Visio VDX XML (simplified version)"""
    # Create VDX structure
    vdx = ET.Element("VisioDocument")
    vdx.set("xmlns", "http://schemas.microsoft.com/visio/2003/core")
    vdx.set("xmlns:vx", "http://schemas.microsoft.com/visio/2006/extension")
    
    # Document properties
    doc_props = ET.SubElement(vdx, "DocumentProperties")
    ET.SubElement(doc_props, "Title").text = title
    
    # Pages
    pages = ET.SubElement(vdx, "Pages")
    page = ET.SubElement(pages, "Page")
    page.set("ID", "0")
    page.set("NameU", "Page-1")
    
    # Shapes (simplified - would need full VDX spec for complete implementation)
    shapes = ET.SubElement(page, "Shapes")
    
    x_pos = 1.0
    y_pos = 1.0
    
    for idx, node in enumerate(graph.nodes[:20]):  # Limit for simplicity
        shape = ET.SubElement(shapes, "Shape")
        shape.set("ID", str(idx + 1))
        shape.set("Type", "Shape")
        shape.set("Master", "1")
        
        # Shape text
        text = ET.SubElement(shape, "Text")
        text.text = node.name
        
        # Position
        xform = ET.SubElement(shape, "XForm")
        ET.SubElement(xform, "PinX").text = str(x_pos)
        ET.SubElement(xform, "PinY").text = str(y_pos)
        ET.SubElement(xform, "Width").text = "2.0"
        ET.SubElement(xform, "Height").text = "0.75"
        
        x_pos += 2.5
        if x_pos > 10:
            x_pos = 1.0
            y_pos += 1.5
    
    # Pretty print
    rough_string = ET.tostring(vdx, encoding='unicode')
    reparsed = minidom.parseString(rough_string)
    return reparsed.toprettyxml(indent="  ")

