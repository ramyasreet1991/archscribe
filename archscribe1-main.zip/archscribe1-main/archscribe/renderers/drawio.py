"""Draw.io (mxGraph) XML renderer"""

from typing import List
from archscribe.core.metamodel import Graph, Node, Edge, Table, NodeType, EdgeKind


def render_drawio(profile: str, graph: Graph) -> str:
    """Render graph in Draw.io XML format"""
    if profile == "erd":
        return render_erd_drawio(graph)
    else:
        return render_system_drawio(graph)


def render_erd_drawio(graph: Graph) -> str:
    """Render ERD in Draw.io format"""
    xml_lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<mxfile host="app.diagrams.net">',
        '  <diagram id="erd" name="ERD">',
        '    <mxGraphModel dx="1422" dy="794" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1169" pageHeight="827" math="0" shadow="0">',
        '      <root>',
        '        <mxCell id="0" />',
        '        <mxCell id="1" parent="0" />',
    ]
    
    # Calculate positions
    x_start = 100
    y_start = 100
    table_width = 200
    table_height = 50
    spacing = 300
    
    y_pos = y_start
    for idx, table in enumerate(graph.tables):
        x_pos = x_start + (idx % 3) * spacing
        if idx > 0 and idx % 3 == 0:
            y_pos += table_height * (len(table.columns) + 2) + 50
        
        # Table rectangle
        table_id = f"table-{table.name}"
        xml_lines.append(f'        <mxCell id="{table_id}" value="{table.name}" style="swimlane;fontStyle=1;childLayout=stackLayout;horizontal=1;startSize=30;horizontalStack=0;resizeParent=1;resizeParentMax=0;resizeLast=0;collapsible=1;marginBottom=0;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">')
        xml_lines.append(f'          <mxGeometry x="{x_pos}" y="{y_pos}" width="{table_width}" height="{30 + len(table.columns) * 25}" as="geometry" />')
        xml_lines.append('        </mxCell>')
        
        # Columns
        for col_idx, col in enumerate(table.columns):
            col_label = col.name
            if col.primary_key:
                col_label = f"🔑 {col_label}"
            if col.foreign_key:
                col_label = f"🔗 {col_label}"
            
            col_id = f"{table_id}-col-{col_idx}"
            xml_lines.append(f'        <mxCell id="{col_id}" value="{col_label}: {col.type}" style="text;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;spacingLeft=4;spacingRight=4;overflow=hidden;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;rotatable=0;whiteSpace=wrap;html=1;" vertex="1" parent="{table_id}">')
            xml_lines.append(f'          <mxGeometry y="{30 + col_idx * 25}" width="{table_width}" height="25" as="geometry" />')
            xml_lines.append('        </mxCell>')
        
        # Relationships
        for col in table.columns:
            if col.foreign_key and col.fk_target_table:
                target_table_id = f"table-{col.fk_target_table}"
                # Add edge (simplified)
                edge_id = f"edge-{table_id}-{target_table_id}"
                xml_lines.append(f'        <mxCell id="{edge_id}" value="" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;" edge="1" parent="1" source="{table_id}" target="{target_table_id}">')
                xml_lines.append('          <mxGeometry relative="1" as="geometry" />')
                xml_lines.append('        </mxCell>')
    
    xml_lines.extend([
        '      </root>',
        '    </mxGraphModel>',
        '  </diagram>',
        '</mxfile>',
    ])
    
    return "\n".join(xml_lines)


def render_system_drawio(graph: Graph) -> str:
    """Render system architecture in Draw.io format"""
    xml_lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<mxfile host="app.diagrams.net">',
        '  <diagram id="system" name="System Architecture">',
        '    <mxGraphModel dx="1422" dy="794" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1169" pageHeight="827" math="0" shadow="0">',
        '      <root>',
        '        <mxCell id="0" />',
        '        <mxCell id="1" parent="0" />',
    ]
    
    # Calculate positions (simple grid layout)
    x_start = 100
    y_start = 100
    node_width = 150
    node_height = 80
    spacing = 200
    
    # Position nodes
    node_positions = {}
    for idx, node in enumerate(graph.nodes):
        row = idx // 4
        col = idx % 4
        x_pos = x_start + col * spacing
        y_pos = y_start + row * spacing
        node_positions[node.id] = (x_pos, y_pos)
        
        # Node style based on type
        if node.type == NodeType.DATABASE:
            style = "shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=15;fillColor=#d5e8d4;strokeColor=#82b366;"
        elif node.type == NodeType.QUEUE:
            style = "shape=queue;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;"
        else:
            style = "rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;"
        
        xml_lines.append(f'        <mxCell id="{node.id}" value="{node.name}" style="{style}" vertex="1" parent="1">')
        xml_lines.append(f'          <mxGeometry x="{x_pos}" y="{y_pos}" width="{node_width}" height="{node_height}" as="geometry" />')
        xml_lines.append('        </mxCell>')
    
    # Add edges
    for edge in graph.edges:
        if edge.from_node in node_positions and edge.to_node in node_positions:
            xml_lines.append(f'        <mxCell id="edge-{edge.from_node}-{edge.to_node}" value="{edge.kind.value}" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;" edge="1" parent="1" source="{edge.from_node}" target="{edge.to_node}">')
            xml_lines.append('          <mxGeometry relative="1" as="geometry" />')
            xml_lines.append('        </mxCell>')
    
    xml_lines.extend([
        '      </root>',
        '    </mxGraphModel>',
        '  </diagram>',
        '</mxfile>',
    ])
    
    return "\n".join(xml_lines)
