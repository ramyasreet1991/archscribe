"""PlantUML diagram renderer"""

from archscribe.core.metamodel import Graph, Node, Edge, Table, NodeType, EdgeKind


def render_plantuml(profile: str, graph: Graph) -> str:
    """Render graph in PlantUML format"""
    if profile == "erd":
        return render_erd_plantuml(graph)
    elif profile == "c4-container":
        return render_c4_container_plantuml(graph)
    else:
        return render_system_plantuml(graph)


def render_erd_plantuml(graph: Graph) -> str:
    """Render ERD in PlantUML"""
    lines = ["@startuml", "!define TABLE(name,desc) class name as \"desc\" << (T,#FFAAAA) >>"]
    
    for table in graph.tables:
        lines.append(f"entity {table.name} {{")
        for col in table.columns:
            pk_marker = "**" if col.primary_key else ""
            fk_marker = "<" if col.foreign_key else ""
            nullable_marker = "" if col.nullable else " NOT NULL"
            lines.append(f"  {pk_marker}{fk_marker}{col.name}: {col.type}{nullable_marker}")
        lines.append("}")
    
    # Relationships
    for table in graph.tables:
        for col in table.columns:
            if col.foreign_key and col.fk_target_table:
                lines.append(f"{table.name} ||--o{{ {col.fk_target_table}")
    
    lines.append("@enduml")
    return "\n".join(lines)


def render_c4_container_plantuml(graph: Graph) -> str:
    """Render C4 Container diagram in PlantUML"""
    lines = [
        "@startuml",
        "!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Container.puml",
        "",
    ]
    
    # Services
    containers = [n for n in graph.nodes if n.type == NodeType.SERVICE]
    for node in containers:
        lines.append(f'Container(service, "{node.name}", "Service", "Provides API")')
    
    # Databases
    databases = [n for n in graph.nodes if n.type == NodeType.DATABASE]
    for node in databases:
        lines.append(f'ContainerDb(db, "{node.name}", "Database", "Stores data")')
    
    # Relationships
    for edge in graph.edges:
        if edge.kind in [EdgeKind.CALLS, EdgeKind.READS, EdgeKind.WRITES]:
            lines.append(f'Rel(service, db, "{edge.kind.value}")')
    
    lines.append("@enduml")
    return "\n".join(lines)


def render_system_plantuml(graph: Graph) -> str:
    """Render general system diagram in PlantUML"""
    lines = ["@startuml"]
    
    for node in graph.nodes:
        node_type = "component" if node.type == NodeType.SERVICE else "database" if node.type == NodeType.DATABASE else "rectangle"
        lines.append(f'{node_type} "{node.name}" as {node.id}')
    
    for edge in graph.edges:
        lines.append(f'{edge.from_node} --> {edge.to_node} : {edge.kind.value}')
    
    lines.append("@enduml")
    return "\n".join(lines)
