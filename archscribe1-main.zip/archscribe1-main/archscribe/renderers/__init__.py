"""Renderers for different diagram formats"""
