"""Mermaid diagram renderer"""

from typing import List, Optional
from archscribe.core.metamodel import Graph, Node, Edge, Table, NodeType, EdgeKind


def render_mermaid(profile: str, graph: Graph) -> str:
    """Render graph in Mermaid format"""
    if profile == "erd":
        return render_erd_mermaid(graph)
    elif profile == "c4-context":
        return render_c4_context_mermaid(graph)
    elif profile == "c4-container":
        return render_c4_container_mermaid(graph)
    elif profile == "c4-component":
        return render_c4_component_mermaid(graph)
    else:
        return render_system_mermaid(graph)


def render_erd_mermaid(graph: Graph) -> str:
    """Render ERD in Mermaid"""
    lines = ["erDiagram"]
    
    for table in graph.tables:
        table_name = table.name
        lines.append(f"    {table_name} {{")
        
        for col in table.columns:
            col_type = col.type
            pk_marker = "PK" if col.primary_key else ""
            fk_marker = f"FK" if col.foreign_key else ""
            nullable_marker = "" if col.nullable else " NOT NULL"
            
            markers = " ".join(filter(None, [pk_marker, fk_marker]))
            markers = f" {markers}" if markers else ""
            
            lines.append(f"        {col.type} {col.name}{markers}{nullable_marker}")
        
        lines.append("    }")
    
    # Add relationships
    for table in graph.tables:
        for col in table.columns:
            if col.foreign_key and col.fk_target_table:
                lines.append(f"    {table.name} ||--o{{ {col.fk_target_table} : \"{col.name}\"")
    
    return "\n".join(lines)


def render_c4_context_mermaid(graph: Graph) -> str:
    """Render C4 Context diagram in Mermaid"""
    lines = ["graph TB"]
    
    # External systems
    external_nodes = [n for n in graph.nodes if n.type == NodeType.EXTERNAL]
    for node in external_nodes:
        lines.append(f"    {node.id}[\"{node.name}\"]")
    
    # Main system
    main_systems = [n for n in graph.nodes if n.type == NodeType.SERVICE]
    for node in main_systems:
        lines.append(f"    {node.id}[\"{node.name}\"]")
    
    # Users
    user_nodes = [n for n in graph.nodes if "user" in n.labels]
    for node in user_nodes:
        lines.append(f"    {node.id}[\"{node.name}\"]")
    
    # Add edges
    for edge in graph.edges:
        if edge.kind in [EdgeKind.CALLS, EdgeKind.DEPENDS_ON]:
            lines.append(f"    {edge.from_node} --> {edge.to_node}")
    
    return "\n".join(lines)


def render_c4_container_mermaid(graph: Graph) -> str:
    """Render C4 Container diagram in Mermaid"""
    lines = ["graph TB"]
    
    # Services/Containers
    containers = [n for n in graph.nodes if n.type in [NodeType.SERVICE, NodeType.CONTAINER]]
    for node in containers:
        node_type_label = "Service" if node.type == NodeType.SERVICE else "Container"
        lines.append(f"    {node.id}[\"{node.name}<br/>{node_type_label}\"]")
    
    # Databases
    databases = [n for n in graph.nodes if n.type == NodeType.DATABASE]
    for node in databases:
        lines.append(f"    {node.id}((\"{node.name}<br/>Database\"))")
    
    # Queues
    queues = [n for n in graph.nodes if n.type in [NodeType.QUEUE, NodeType.TOPIC]]
    for node in queues:
        lines.append(f"    {node.id}[\"{node.name}<br/>Queue\"]")
    
    # Add edges
    for edge in graph.edges:
        if edge.kind in [EdgeKind.CALLS, EdgeKind.READS, EdgeKind.WRITES, EdgeKind.PUBLISHES, EdgeKind.SUBSCRIBES]:
            edge_label = edge.kind.value
            lines.append(f"    {edge.from_node} -->|{edge_label}| {edge.to_node}")
    
    return "\n".join(lines)


def render_c4_component_mermaid(graph: Graph) -> str:
    """Render C4 Component diagram in Mermaid"""
    lines = ["graph TB"]
    
    # Components (modules, classes, functions)
    components = [n for n in graph.nodes if n.type in [NodeType.MODULE, NodeType.CLASS, NodeType.FUNCTION]]
    for node in components:
        lines.append(f"    {node.id}[\"{node.name}\"]")
    
    # Add edges
    for edge in graph.edges:
        if edge.kind in [EdgeKind.CALLS, EdgeKind.IMPORTS, EdgeKind.REFERENCES]:
            lines.append(f"    {edge.from_node} --> {edge.to_node}")
    
    return "\n".join(lines)


def render_system_mermaid(graph: Graph) -> str:
    """Render general system diagram in Mermaid"""
    lines = ["graph TB"]
    
    # All nodes
    for node in graph.nodes:
        shape = "[]" if node.type in [NodeType.SERVICE, NodeType.MODULE] else "()" if node.type == NodeType.DATABASE else "{}"
        lines.append(f"    {node.id}{shape}\"{node.name}\"")
    
    # All edges
    for edge in graph.edges:
        lines.append(f"    {edge.from_node} -->|{edge.kind.value}| {edge.to_node}")
    
    return "\n".join(lines)
