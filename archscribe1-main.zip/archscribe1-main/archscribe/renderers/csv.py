"""CSV renderer for ERD data"""

import csv
from io import StringIO
from typing import List
from archscribe.core.metamodel import Graph, Table


def render_erd_csv(graph: Graph) -> str:
    """Render ERD as CSV for Lucid import"""
    output = StringIO()
    writer = csv.writer(output)
    
    # Header
    writer.writerow(["Table", "Column", "Type", "PK", "FK", "FK_Target", "Nullable"])
    
    # Rows
    for table in graph.tables:
        for col in table.columns:
            pk = "TRUE" if col.primary_key else "FALSE"
            fk = "TRUE" if col.foreign_key else "FALSE"
            fk_target = f"{col.fk_target_table}.{col.fk_target_column}" if col.foreign_key and col.fk_target_table else ""
            nullable = "FALSE" if not col.nullable else "TRUE"
            
            writer.writerow([
                table.name,
                col.name,
                col.type,
                pk,
                fk,
                fk_target,
                nullable
            ])
    
    return output.getvalue()
