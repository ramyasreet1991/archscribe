"""Attack path analysis and simulation"""

from typing import List, Dict, Any, Optional
from archscribe.core.metamodel import Graph, Node, NodeType, Edge, EdgeKind
from archscribe.kg.neo4j_client import Neo4jClient
import networkx as nx


class AttackPathAnalyzer:
    """Analyze attack paths in the codebase"""
    
    def __init__(self, graph: Graph, neo4j_client: Optional[Neo4jClient] = None):
        """Initialize attack path analyzer"""
        self.graph = graph
        self.neo4j_client = neo4j_client
        self.networkx_graph = self._build_networkx_graph()
    
    def _build_networkx_graph(self) -> nx.DiGraph:
        """Build NetworkX graph from ArchScribe graph"""
        G = nx.DiGraph()
        
        # Add nodes
        for node in self.graph.nodes:
            G.add_node(node.id, **node.props, type=node.type.value, labels=node.labels)
        
        # Add edges
        for edge in self.graph.edges:
            G.add_edge(edge.from_node, edge.to_node, kind=edge.kind.value, **edge.props)
        
        return G
    
    def find_attack_paths(
        self,
        source_types: List[NodeType] = None,
        target_types: List[NodeType] = None,
        max_depth: int = 5,
        require_auth: bool = False
    ) -> List[Dict[str, Any]]:
        """Find attack paths from source to target nodes"""
        if source_types is None:
            source_types = [NodeType.ENDPOINT]
        if target_types is None:
            target_types = [NodeType.DATABASE, NodeType.TABLE, NodeType.SECRET]
        
        attack_paths = []
        
        # Get source nodes (e.g., public endpoints)
        source_nodes = [
            n for n in self.graph.nodes
            if n.type in source_types and (not require_auth or not n.props.get('requires_auth', False))
        ]
        
        # Get target nodes (e.g., databases, secrets)
        target_nodes = [
            n for n in self.graph.nodes
            if n.type in target_types
        ]
        
        # Find paths using NetworkX
        for source in source_nodes:
            for target in target_nodes:
                try:
                    paths = list(nx.all_simple_paths(
                        self.networkx_graph,
                        source.id,
                        target.id,
                        cutoff=max_depth
                    ))
                    
                    for path in paths:
                        attack_paths.append({
                            "source": source.id,
                            "target": target.id,
                            "path": path,
                            "depth": len(path) - 1,
                            "source_name": source.name,
                            "target_name": target.name,
                            "exploitability": self._calculate_exploitability(path),
                            "business_impact": self._estimate_business_impact(target)
                        })
                except (nx.NetworkXNoPath, nx.NodeNotFound):
                    continue
        
        # Sort by exploitability and depth
        attack_paths.sort(key=lambda x: (x['exploitability'], x['depth']), reverse=True)
        
        return attack_paths
    
    def _calculate_exploitability(self, path: List[str]) -> float:
        """Calculate exploitability score for an attack path"""
        score = 1.0
        
        # Reduce score for each hop (longer paths are harder to exploit)
        score *= (1.0 - (len(path) - 1) * 0.1)
        
        # Check for authentication requirements
        for node_id in path:
            node = self.graph.get_node(node_id)
            if node and node.props.get('requires_auth', False):
                score *= 0.5  # Reduce score if auth is required
        
        return max(0.0, min(1.0, score))
    
    def _estimate_business_impact(self, target: Node) -> str:
        """Estimate business impact of compromising a target"""
        if target.type == NodeType.SECRET:
            return "High - Secret exposure"
        elif target.type == NodeType.DATABASE:
            return "High - Data breach"
        elif target.type == NodeType.TABLE:
            if any(tag in target.labels for tag in ['user', 'payment', 'order']):
                return "High - Sensitive data access"
            return "Medium - Data access"
        else:
            return "Low - System access"
    
    def find_sql_injection_paths(self) -> List[Dict[str, Any]]:
        """Find potential SQL injection attack paths"""
        attack_paths = []
        
        # Find endpoints that accept user input and call database
        endpoints = [n for n in self.graph.nodes if n.type == NodeType.ENDPOINT]
        databases = [n for n in self.graph.nodes if n.type == NodeType.DATABASE]
        
        for endpoint in endpoints:
            # Check if endpoint has paths to database
            paths = self._find_paths_to_type(endpoint.id, NodeType.DATABASE)
            
            for path in paths:
                # Check if path involves user input
                if self._path_involves_user_input(path):
                    attack_paths.append({
                        "type": "sql_injection",
                        "endpoint": endpoint.id,
                        "endpoint_name": endpoint.name,
                        "path": path,
                        "severity": "High",
                        "description": f"Potential SQL injection via {endpoint.name}"
                    })
        
        return attack_paths
    
    def find_secret_exposure_paths(self) -> List[Dict[str, Any]]:
        """Find paths where secrets might be exposed"""
        exposure_paths = []
        
        secrets = [n for n in self.graph.nodes if n.type == NodeType.SECRET]
        endpoints = [n for n in self.graph.nodes if n.type == NodeType.ENDPOINT]
        
        for secret in secrets:
            for endpoint in endpoints:
                try:
                    paths = list(nx.all_simple_paths(
                        self.networkx_graph,
                        endpoint.id,
                        secret.id,
                        cutoff=5
                    ))
                    
                    for path in paths:
                        exposure_paths.append({
                            "type": "secret_exposure",
                            "secret": secret.id,
                            "secret_name": secret.name,
                            "endpoint": endpoint.id,
                            "endpoint_name": endpoint.name,
                            "path": path,
                            "severity": "Critical",
                            "description": f"Secret {secret.name} accessible via {endpoint.name}"
                        })
                except (nx.NetworkXNoPath, nx.NodeNotFound):
                    continue
        
        return exposure_paths
    
    def _find_paths_to_type(self, source_id: str, target_type: NodeType, max_depth: int = 5) -> List[List[str]]:
        """Find paths from source to nodes of target type"""
        paths = []
        target_nodes = [n.id for n in self.graph.nodes if n.type == target_type]
        
        for target_id in target_nodes:
            try:
                found_paths = list(nx.all_simple_paths(
                    self.networkx_graph,
                    source_id,
                    target_id,
                    cutoff=max_depth
                ))
                paths.extend(found_paths)
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                continue
        
        return paths
    
    def _path_involves_user_input(self, path: List[str]) -> bool:
        """Check if a path involves user input"""
        for node_id in path:
            node = self.graph.get_node(node_id)
            if node and node.type == NodeType.ENDPOINT:
                return True
        return False
    
    def generate_attack_report(self) -> Dict[str, Any]:
        """Generate comprehensive attack report"""
        report = {
            "summary": {
                "total_attack_paths": 0,
                "high_risk_paths": 0,
                "medium_risk_paths": 0,
                "low_risk_paths": 0
            },
            "attack_paths": [],
            "sql_injection_paths": [],
            "secret_exposure_paths": [],
            "unauthenticated_endpoints": []
        }
        
        # Find attack paths
        attack_paths = self.find_attack_paths()
        report["attack_paths"] = attack_paths
        report["summary"]["total_attack_paths"] = len(attack_paths)
        
        # Categorize by risk
        for path in attack_paths:
            if path['exploitability'] > 0.7:
                report["summary"]["high_risk_paths"] += 1
            elif path['exploitability'] > 0.4:
                report["summary"]["medium_risk_paths"] += 1
            else:
                report["summary"]["low_risk_paths"] += 1
        
        # Find SQL injection paths
        report["sql_injection_paths"] = self.find_sql_injection_paths()
        
        # Find secret exposure paths
        report["secret_exposure_paths"] = self.find_secret_exposure_paths()
        
        # Find unauthenticated endpoints
        endpoints = [n for n in self.graph.nodes if n.type == NodeType.ENDPOINT]
        report["unauthenticated_endpoints"] = [
            {
                "id": e.id,
                "name": e.name,
                "path": e.props.get('path', ''),
                "method": e.props.get('method', ''),
                "file": e.props.get('file', '')
            }
            for e in endpoints
            if not e.props.get('requires_auth', False)
        ]
        
        return report

