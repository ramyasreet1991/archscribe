"""Core metamodel for architecture and ERD representation"""

from typing import Any, Dict, List, Optional, Set
from dataclasses import dataclass, field
from enum import Enum


class NodeType(str, Enum):
    """Types of nodes in the architecture graph"""
    SERVICE = "service"
    MODULE = "module"
    DATABASE = "db"
    TABLE = "table"
    QUEUE = "queue"
    TOPIC = "topic"
    GATEWAY = "gateway"
    FUNCTION = "function"
    JOB = "job"
    ENDPOINT = "endpoint"
    CLASS = "class"
    METHOD = "method"
    SECRET = "secret"
    CONFIG = "config"
    CONTAINER = "container"
    EXTERNAL = "external"


class EdgeKind(str, Enum):
    """Types of edges/relationships"""
    CALLS = "calls"
    READS = "reads"
    WRITES = "writes"
    PUBLISHES = "pub"
    SUBSCRIBES = "sub"
    DEPENDS_ON = "depends_on"
    DEPLOYS_TO = "deploys_to"
    AUTHENTICATES = "authenticates"
    REQUIRES_AUTH = "requires_auth"
    USES_SECRET = "uses_secret"
    IMPORTS = "imports"
    INHERITS = "inherits"
    IMPLEMENTS = "implements"
    REFERENCES = "references"


@dataclass
class Node:
    """Represents a node in the architecture graph"""
    id: str
    type: NodeType
    name: str
    labels: List[str] = field(default_factory=list)
    props: Dict[str, Any] = field(default_factory=dict)
    
    def __hash__(self):
        return hash(self.id)
    
    def __eq__(self, other):
        return isinstance(other, Node) and self.id == other.id


@dataclass
class Edge:
    """Represents an edge/relationship in the architecture graph"""
    from_node: str
    to_node: str
    kind: EdgeKind
    props: Dict[str, Any] = field(default_factory=dict)
    
    def __hash__(self):
        return hash((self.from_node, self.to_node, self.kind))
    
    def __eq__(self, other):
        return (
            isinstance(other, Edge) and
            self.from_node == other.from_node and
            self.to_node == other.to_node and
            self.kind == other.kind
        )


@dataclass
class Column:
    """Represents a database column"""
    name: str
    type: str
    nullable: bool = False
    primary_key: bool = False
    foreign_key: bool = False
    fk_target_table: Optional[str] = None
    fk_target_column: Optional[str] = None
    indexed: bool = False
    unique: bool = False


@dataclass
class Table:
    """Represents a database table"""
    name: str
    schema: Optional[str] = None
    columns: List[Column] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    props: Dict[str, Any] = field(default_factory=dict)
    
    def __hash__(self):
        return hash((self.schema, self.name))
    
    def __eq__(self, other):
        return (
            isinstance(other, Table) and
            self.schema == other.schema and
            self.name == other.name
        )


@dataclass
class Graph:
    """Main graph container for nodes, edges, and tables"""
    nodes: List[Node] = field(default_factory=list)
    edges: List[Edge] = field(default_factory=list)
    tables: List[Table] = field(default_factory=list)
    
    def add_node(self, node: Node):
        """Add a node if it doesn't exist"""
        if node not in self.nodes:
            self.nodes.append(node)
        else:
            # Update existing node
            idx = self.nodes.index(node)
            existing = self.nodes[idx]
            existing.labels.extend([l for l in node.labels if l not in existing.labels])
            existing.props.update(node.props)
    
    def add_edge(self, edge: Edge):
        """Add an edge if it doesn't exist"""
        if edge not in self.edges:
            self.edges.append(edge)
        else:
            # Update existing edge
            idx = self.edges.index(edge)
            existing = self.edges[idx]
            existing.props.update(edge.props)
    
    def add_table(self, table: Table):
        """Add a table if it doesn't exist"""
        if table not in self.tables:
            self.tables.append(table)
        else:
            # Update existing table
            idx = self.tables.index(table)
            existing = self.tables[idx]
            existing.columns.extend([c for c in table.columns if c not in existing.columns])
            existing.tags.extend([t for t in table.tags if t not in existing.tags])
            existing.props.update(table.props)
    
    def get_node(self, node_id: str) -> Optional[Node]:
        """Get a node by ID"""
        for node in self.nodes:
            if node.id == node_id:
                return node
        return None
    
    def get_nodes_by_type(self, node_type: NodeType) -> List[Node]:
        """Get all nodes of a specific type"""
        return [n for n in self.nodes if n.type == node_type]
    
    def get_edges_from(self, node_id: str) -> List[Edge]:
        """Get all edges from a node"""
        return [e for e in self.edges if e.from_node == node_id]
    
    def get_edges_to(self, node_id: str) -> List[Edge]:
        """Get all edges to a node"""
        return [e for e in self.edges if e.to_node == node_id]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert graph to dictionary for serialization"""
        return {
            "nodes": [
                {
                    "id": n.id,
                    "type": n.type.value,
                    "name": n.name,
                    "labels": n.labels,
                    "props": n.props
                }
                for n in self.nodes
            ],
            "edges": [
                {
                    "from": e.from_node,
                    "to": e.to_node,
                    "kind": e.kind.value,
                    "props": e.props
                }
                for e in self.edges
            ],
            "tables": [
                {
                    "name": t.name,
                    "schema": t.schema,
                    "columns": [
                        {
                            "name": c.name,
                            "type": c.type,
                            "nullable": c.nullable,
                            "primary_key": c.primary_key,
                            "foreign_key": c.foreign_key,
                            "fk_target_table": c.fk_target_table,
                            "fk_target_column": c.fk_target_column,
                            "indexed": c.indexed,
                            "unique": c.unique
                        }
                        for c in t.columns
                    ],
                    "tags": t.tags,
                    "props": t.props
                }
                for t in self.tables
            ]
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Graph":
        """Create graph from dictionary"""
        graph = cls()
        
        # Load nodes
        for node_data in data.get("nodes", []):
            node = Node(
                id=node_data["id"],
                type=NodeType(node_data["type"]),
                name=node_data["name"],
                labels=node_data.get("labels", []),
                props=node_data.get("props", {})
            )
            graph.add_node(node)
        
        # Load edges
        for edge_data in data.get("edges", []):
            edge = Edge(
                from_node=edge_data["from"],
                to_node=edge_data["to"],
                kind=EdgeKind(edge_data["kind"]),
                props=edge_data.get("props", {})
            )
            graph.add_edge(edge)
        
        # Load tables
        for table_data in data.get("tables", []):
            columns = []
            for col_data in table_data.get("columns", []):
                column = Column(
                    name=col_data["name"],
                    type=col_data["type"],
                    nullable=col_data.get("nullable", False),
                    primary_key=col_data.get("primary_key", False),
                    foreign_key=col_data.get("foreign_key", False),
                    fk_target_table=col_data.get("fk_target_table"),
                    fk_target_column=col_data.get("fk_target_column"),
                    indexed=col_data.get("indexed", False),
                    unique=col_data.get("unique", False)
                )
                columns.append(column)
            
            table = Table(
                name=table_data["name"],
                schema=table_data.get("schema"),
                columns=columns,
                tags=table_data.get("tags", []),
                props=table_data.get("props", {})
            )
            graph.add_table(table)
        
        return graph

