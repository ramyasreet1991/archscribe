"""Configuration management"""

from pathlib import Path
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
import yaml


class DiagramTarget(BaseModel):
    """Target diagram type"""
    type: str = Field(..., description="Diagram type: c4-context, c4-container, c4-component, erd, system")


class InputConfig(BaseModel):
    """Input configuration"""
    repo: str = Field(..., description="Repository URL or path")
    paths: Optional[Dict[str, List[str]]] = Field(default=None, description="Include/exclude paths")
    languages: Optional[List[str]] = Field(default=None, description="Language hints")
    frameworks: Optional[List[str]] = Field(default=None, description="Framework hints")
    cloud: Optional[str] = Field(default=None, description="Cloud provider: aws, gcp, azure")


class ERDConfig(BaseModel):
    """ERD extraction configuration"""
    sources: List[str] = Field(default=["orm", "migrations", "sql"], description="ERD sources")
    infer_nullability: bool = Field(default=True, description="Infer nullability")


class RenderConfig(BaseModel):
    """Rendering configuration"""
    formats: List[str] = Field(default=["mermaid", "drawio"], description="Output formats")
    layout: str = Field(default="elk", description="Layout engine: elk, graphviz, manual")
    theme: str = Field(default="neutral", description="Theme")


class PublishConfig(BaseModel):
    """Publishing configuration"""
    github_pr_comment: bool = Field(default=False, description="Comment on GitHub PRs")
    artifact_dir: str = Field(default="diagrams/", description="Artifact directory")
    upload_to_cloud: bool = Field(default=False, description="Upload to cloud storage")


class ArchScribeConfig(BaseModel):
    """Main configuration model"""
    project: str = Field(..., description="Project name")
    targets: List[DiagramTarget] = Field(default_factory=list, description="Diagram targets")
    inputs: InputConfig = Field(..., description="Input configuration")
    erd: ERDConfig = Field(default_factory=ERDConfig, description="ERD configuration")
    render: RenderConfig = Field(default_factory=RenderConfig, description="Render configuration")
    publish: PublishConfig = Field(default_factory=PublishConfig, description="Publish configuration")
    cpg: bool = Field(default=True, description="Enable CPG extraction")
    kg: bool = Field(default=True, description="Enable knowledge graph generation")
    security: bool = Field(default=True, description="Enable security analysis")


def load_config(config_path: Path) -> ArchScribeConfig:
    """Load configuration from YAML file"""
    with open(config_path, 'r') as f:
        data = yaml.safe_load(f)
    return ArchScribeConfig(**data)


def save_config(config: ArchScribeConfig, config_path: Path):
    """Save configuration to YAML file"""
    with open(config_path, 'w') as f:
        yaml.dump(config.dict(), f, default_flow_style=False, sort_keys=False)

