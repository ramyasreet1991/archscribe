"""Core metamodel and graph abstractions"""

