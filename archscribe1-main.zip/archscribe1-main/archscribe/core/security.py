"""Security analysis and attack path simulation"""

from typing import List, Dict, Any, Tuple
from archscribe.core.metamodel import Graph, Node, Edge, NodeType, EdgeKind
from neo4j import GraphDatabase


class SecurityAnalyzer:
    """Analyze security vulnerabilities and attack paths"""
    
    def __init__(self, graph: Graph, neo4j_driver=None):
        self.graph = graph
        self.neo4j_driver = neo4j_driver
    
    def find_attack_paths(self) -> List[Dict[str, Any]]:
        """Find attack paths from public endpoints to sensitive resources"""
        attack_paths = []
        
        # Find public endpoints
        public_endpoints = [
            n for n in self.graph.nodes 
            if n.type == NodeType.ENDPOINT and n.props.get("public", False)
        ]
        
        # Find sensitive resources (databases, secrets, admin functions)
        sensitive_resources = [
            n for n in self.graph.nodes
            if n.type in [NodeType.DATABASE, NodeType.SECRET] or "admin" in n.labels
        ]
        
        # For each public endpoint, find paths to sensitive resources
        for endpoint in public_endpoints:
            for resource in sensitive_resources:
                paths = self._find_paths(endpoint.id, resource.id)
                for path in paths:
                    # Check if path bypasses authentication
                    if not self._requires_auth(path):
                        attack_paths.append({
                            "endpoint": endpoint.name,
                            "resource": resource.name,
                            "path": path,
                            "severity": self._calculate_severity(path, resource),
                            "exploitable": True
                        })
        
        return attack_paths
    
    def find_unauthenticated_endpoints(self) -> List[Node]:
        """Find endpoints without authentication"""
        endpoints = [n for n in self.graph.nodes if n.type == NodeType.ENDPOINT]
        unauthenticated = []
        
        for endpoint in endpoints:
            # Check if endpoint has authentication requirement
            auth_edges = [
                e for e in self.graph.edges
                if e.from_node == endpoint.id and e.kind == EdgeKind.REQUIRES_AUTH
            ]
            
            if not auth_edges:
                unauthenticated.append(endpoint)
        
        return unauthenticated
    
    def find_hardcoded_secrets(self) -> List[Node]:
        """Find hardcoded secrets"""
        return [n for n in self.graph.nodes if n.type == NodeType.SECRET]
    
    def find_sql_injection_risks(self) -> List[Dict[str, Any]]:
        """Find potential SQL injection risks"""
        risks = []
        
        # Find endpoints that write to database
        endpoints = [n for n in self.graph.nodes if n.type == NodeType.ENDPOINT]
        databases = [n for n in self.graph.nodes if n.type == NodeType.DATABASE]
        
        for endpoint in endpoints:
            # Check if endpoint calls database
            db_edges = [
                e for e in self.graph.edges
                if e.from_node == endpoint.id and e.to_node in [db.id for db in databases]
                and e.kind in [EdgeKind.WRITES, EdgeKind.READS]
            ]
            
            if db_edges:
                # Check if endpoint accepts user input (simplified)
                if endpoint.props.get("method") in ["POST", "PUT", "PATCH"]:
                    risks.append({
                        "endpoint": endpoint.name,
                        "file": endpoint.props.get("file"),
                        "severity": "high",
                        "type": "sql_injection",
                        "description": f"Endpoint {endpoint.name} writes to database without apparent input validation"
                    })
        
        return risks
    
    def find_privilege_escalation_paths(self) -> List[Dict[str, Any]]:
        """Find potential privilege escalation paths"""
        paths = []
        
        # Find user-facing endpoints
        user_endpoints = [
            n for n in self.graph.nodes
            if n.type == NodeType.ENDPOINT and n.props.get("public", False)
        ]
        
        # Find admin functions
        admin_functions = [
            n for n in self.graph.nodes
            if "admin" in n.labels or "privileged" in n.labels
        ]
        
        # Find paths from user endpoints to admin functions
        for endpoint in user_endpoints:
            for admin_func in admin_functions:
                path = self._find_path(endpoint.id, admin_func.id)
                if path and not self._requires_auth(path):
                    paths.append({
                        "endpoint": endpoint.name,
                        "admin_function": admin_func.name,
                        "path": path,
                        "severity": "critical",
                        "type": "privilege_escalation"
                    })
        
        return paths
    
    def generate_security_report(self) -> Dict[str, Any]:
        """Generate comprehensive security report"""
        report = {
            "attack_paths": self.find_attack_paths(),
            "unauthenticated_endpoints": [
                {
                    "name": n.name,
                    "file": n.props.get("file"),
                    "method": n.props.get("method"),
                    "path": n.props.get("path")
                }
                for n in self.find_unauthenticated_endpoints()
            ],
            "hardcoded_secrets": [
                {
                    "name": n.name,
                    "file": n.props.get("file"),
                    "line": n.props.get("line"),
                    "type": n.props.get("type"),
                    "severity": n.props.get("severity", "high")
                }
                for n in self.find_hardcoded_secrets()
            ],
            "sql_injection_risks": self.find_sql_injection_risks(),
            "privilege_escalation_paths": self.find_privilege_escalation_paths(),
            "summary": {
                "total_attack_paths": len(self.find_attack_paths()),
                "total_unauthenticated_endpoints": len(self.find_unauthenticated_endpoints()),
                "total_secrets": len(self.find_hardcoded_secrets()),
                "total_sql_risks": len(self.find_sql_injection_risks()),
                "total_privilege_escalation": len(self.find_privilege_escalation_paths())
            }
        }
        
        return report
    
    def _find_paths(self, start_id: str, end_id: str, max_depth: int = 5) -> List[List[str]]:
        """Find all paths from start to end node"""
        paths = []
        visited = set()
        
        def dfs(current: str, target: str, path: List[str], depth: int):
            if depth > max_depth:
                return
            
            if current == target:
                paths.append(path.copy())
                return
            
            visited.add(current)
            
            # Find neighbors
            neighbors = [
                e.to_node for e in self.graph.edges
                if e.from_node == current and e.to_node not in visited
            ]
            
            for neighbor in neighbors:
                path.append(neighbor)
                dfs(neighbor, target, path, depth + 1)
                path.pop()
            
            visited.remove(current)
        
        dfs(start_id, end_id, [start_id], 0)
        return paths
    
    def _find_path(self, start_id: str, end_id: str) -> List[str]:
        """Find a single path from start to end node (BFS)"""
        from collections import deque
        
        queue = deque([(start_id, [start_id])])
        visited = {start_id}
        
        while queue:
            current, path = queue.popleft()
            
            if current == end_id:
                return path
            
            # Find neighbors
            neighbors = [
                e.to_node for e in self.graph.edges
                if e.from_node == current and e.to_node not in visited
            ]
            
            for neighbor in neighbors:
                visited.add(neighbor)
                queue.append((neighbor, path + [neighbor]))
        
        return []
    
    def _requires_auth(self, path: List[str]) -> bool:
        """Check if path requires authentication"""
        for i in range(len(path) - 1):
            from_node = path[i]
            to_node = path[i + 1]
            
            # Check for auth requirement edge
            auth_edges = [
                e for e in self.graph.edges
                if e.from_node == from_node and e.to_node == to_node
                and e.kind == EdgeKind.REQUIRES_AUTH
            ]
            
            if auth_edges:
                return True
        
        return False
    
    def _calculate_severity(self, path: List[str], resource: Node) -> str:
        """Calculate severity of attack path"""
        if resource.type == NodeType.SECRET:
            return "critical"
        elif resource.type == NodeType.DATABASE:
            return "high"
        elif "admin" in resource.labels:
            return "high"
        else:
            return "medium"

