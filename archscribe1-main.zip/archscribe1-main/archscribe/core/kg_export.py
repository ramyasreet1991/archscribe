"""Knowledge Graph export to Neo4j and other formats"""

from pathlib import Path
from typing import List, Optional, Dict, Any
import json
from archscribe.core.metamodel import Graph, Node, Edge, Table
from neo4j import GraphDatabase
import networkx as nx


class KnowledgeGraphExporter:
    """Export graph to Neo4j and other formats"""
    
    def __init__(self, neo4j_uri: Optional[str] = None, neo4j_user: Optional[str] = None, 
                 neo4j_password: Optional[str] = None):
        self.neo4j_uri = neo4j_uri or "bolt://localhost:7687"
        self.neo4j_user = neo4j_user or "neo4j"
        self.neo4j_password = neo4j_password or "password"
        self.driver = None
        
        if neo4j_uri:
            try:
                self.driver = GraphDatabase.driver(neo4j_uri, auth=(neo4j_user, neo4j_password))
            except Exception as e:
                print(f"Warning: Could not connect to Neo4j: {e}")
    
    def export_to_cypher(self, graph: Graph, out_path: Path) -> Path:
        """Export graph as Cypher script"""
        cypher_lines = []
        
        # Clear existing data (optional)
        cypher_lines.append("// Clear existing data")
        cypher_lines.append("MATCH (n) DETACH DELETE n;")
        cypher_lines.append("")
        
        # Create nodes
        cypher_lines.append("// Create nodes")
        for node in graph.nodes:
            labels = ":".join([node.type.value.title()] + [l.title() for l in node.labels])
            props = self._format_props(node.props)
            cypher_lines.append(
                f"CREATE (n:{labels} {{id: '{node.id}', name: '{node.name}', {props}}});"
            )
        
        cypher_lines.append("")
        
        # Create edges
        cypher_lines.append("// Create edges")
        for edge in graph.edges:
            edge_type = edge.kind.value.upper().replace("_", "")
            props = self._format_props(edge.props)
            cypher_lines.append(
                f"MATCH (a {{id: '{edge.from_node}'}}), (b {{id: '{edge.to_node}'}})"
            )
            if props:
                cypher_lines.append(
                    f"CREATE (a)-[r:{edge_type} {{ {props} }}]->(b);"
                )
            else:
                cypher_lines.append(f"CREATE (a)-[r:{edge_type}]->(b);")
        
        cypher_lines.append("")
        
        # Create table nodes
        cypher_lines.append("// Create table nodes")
        for table in graph.tables:
            table_id = f"table-{table.name}"
            props = self._format_props(table.props)
            cypher_lines.append(
                f"CREATE (n:Table {{id: '{table_id}', name: '{table.name}', schema: '{table.schema or ''}', {props}}});"
            )
            
            # Create column nodes
            for col in table.columns:
                col_id = f"{table_id}-col-{col.name}"
                cypher_lines.append(
                    f"CREATE (c:Column {{id: '{col_id}', name: '{col.name}', type: '{col.type}', "
                    f"primary_key: {str(col.primary_key).lower()}, foreign_key: {str(col.foreign_key).lower()}}});"
                )
                cypher_lines.append(
                    f"MATCH (t:Table {{id: '{table_id}'}}), (c:Column {{id: '{col_id}'}}) "
                    f"CREATE (t)-[:HAS_COLUMN]->(c);"
                )
                
                # Foreign key relationships
                if col.foreign_key and col.fk_target_table:
                    target_table_id = f"table-{col.fk_target_table}"
                    cypher_lines.append(
                        f"MATCH (c:Column {{id: '{col_id}'}}), (t:Table {{id: '{target_table_id}'}}) "
                        f"CREATE (c)-[:REFERENCES]->(t);"
                    )
        
        cypher_script = "\n".join(cypher_lines)
        
        with open(out_path, 'w') as f:
            f.write(cypher_script)
        
        return out_path
    
    def export_to_neo4j(self, graph: Graph) -> bool:
        """Export graph directly to Neo4j"""
        if not self.driver:
            print("Neo4j driver not available")
            return False
        
        try:
            with self.driver.session() as session:
                # Clear existing data
                session.run("MATCH (n) DETACH DELETE n")
                
                # Create nodes
                for node in graph.nodes:
                    labels = ":".join([node.type.value.title()] + [l.title() for l in node.labels])
                    props = {"id": node.id, "name": node.name, **node.props}
                    query = f"CREATE (n:{labels} $props)"
                    session.run(query, props=props)
                
                # Create edges
                for edge in graph.edges:
                    edge_type = edge.kind.value.upper().replace("_", "")
                    query = f"""
                        MATCH (a {{id: $from_id}}), (b {{id: $to_id}})
                        CREATE (a)-[r:{edge_type} $props]->(b)
                    """
                    session.run(query, from_id=edge.from_node, to_id=edge.to_node, props=edge.props)
                
                # Create tables
                for table in graph.tables:
                    table_id = f"table-{table.name}"
                    props = {"id": table_id, "name": table.name, "schema": table.schema or "", **table.props}
                    session.run("CREATE (n:Table $props)", props=props)
                    
                    # Create columns
                    for col in table.columns:
                        col_id = f"{table_id}-col-{col.name}"
                        col_props = {
                            "id": col_id,
                            "name": col.name,
                            "type": col.type,
                            "primary_key": col.primary_key,
                            "foreign_key": col.foreign_key
                        }
                        session.run("CREATE (c:Column $props)", props=col_props)
                        session.run(
                            "MATCH (t:Table {id: $table_id}), (c:Column {id: $col_id}) "
                            "CREATE (t)-[:HAS_COLUMN]->(c)",
                            table_id=table_id, col_id=col_id
                        )
                        
                        # Foreign key relationships
                        if col.foreign_key and col.fk_target_table:
                            target_table_id = f"table-{col.fk_target_table}"
                            session.run(
                                "MATCH (c:Column {id: $col_id}), (t:Table {id: $target_id}) "
                                "CREATE (c)-[:REFERENCES]->(t)",
                                col_id=col_id, target_id=target_table_id
                            )
                
                print("Graph exported to Neo4j successfully")
                return True
        
        except Exception as e:
            print(f"Error exporting to Neo4j: {e}")
            return False
    
    def export_to_networkx(self, graph: Graph) -> nx.DiGraph:
        """Export graph to NetworkX format"""
        G = nx.DiGraph()
        
        # Add nodes
        for node in graph.nodes:
            G.add_node(node.id, type=node.type.value, name=node.name, **node.props)
        
        # Add edges
        for edge in graph.edges:
            G.add_edge(edge.from_node, edge.to_node, kind=edge.kind.value, **edge.props)
        
        return G
    
    def export_to_json(self, graph: Graph, out_path: Path) -> Path:
        """Export graph as JSON"""
        graph_dict = graph.to_dict()
        
        with open(out_path, 'w') as f:
            json.dump(graph_dict, f, indent=2)
        
        return out_path
    
    def _format_props(self, props: Dict[str, Any]) -> str:
        """Format properties for Cypher"""
        if not props:
            return ""
        
        formatted = []
        for key, value in props.items():
            if isinstance(value, str):
                formatted.append(f"{key}: '{value}'")
            elif isinstance(value, bool):
                formatted.append(f"{key}: {str(value).lower()}")
            elif isinstance(value, (int, float)):
                formatted.append(f"{key}: {value}")
            elif isinstance(value, list):
                formatted.append(f"{key}: {value}")
            else:
                formatted.append(f"{key}: '{str(value)}'")
        
        return ", ".join(formatted)
    
    def close(self):
        """Close Neo4j driver"""
        if self.driver:
            self.driver.close()

