# ⚡ DevAccelerator

**LLM-powered developer productivity CLI — a curated prompt library that integrates with LLM Suite & GitHub Copilot.**

> Hackathon Entry: Turn hours of repetitive dev work into seconds with context-aware prompt templates.

---

## Quick Start

```bash
# Install dependencies
npm install

# Initialize configuration
node src/cli.js init

# Edit .env with your LLM Suite API credentials
# (supports any OpenAI-compatible API)

# Verify setup
node src/cli.js status

# List all prompts
node src/cli.js list

# Run a prompt interactively
node src/cli.js interactive

# Run a specific prompt
node src/cli.js run poc_kickstart

# Dry run — see the compiled prompt without calling LLM
node src/cli.js run pr_review --dry-run

# Save output to file
node src/cli.js run test_generator -o tests.md
```

## Global Install (optional)

```bash
npm link
# Now use `devaccel` from anywhere:
devaccel list
devaccel run standup_summary
```

---

## Prompt Library

| Category | Prompts | Description |
|----------|---------|-------------|
| 🏗️ Scaffold | `poc_kickstart` | Generate full POC project structure |
| ⚡ Code | `test_generator` | Generate unit/integration/edge-case tests |
| 🔍 Review | `pr_review` | AI-powered PR code review with severity ranking |
| 📋 Daily | `standup_summary`, `eod_report` | Auto-generate standups and EOD reports from git |
| 📖 Docs | `api_doc_generator` | Generate OpenAPI specs from code |
| 🚀 DevOps | `k8s_manifest_gen`, `dockerfile_optimizer` | K8s manifests, Docker optimization |

---

## How It Works

```
┌─────────────────────────────────────────────────┐
│  Developer runs: devaccel run pr_review          │
├─────────────────────────────────────────────────┤
│  1. Load prompt template (YAML + Handlebars)     │
│  2. Auto-collect context (git diff, branch, log) │
│  3. Prompt for missing required inputs           │
│  4. Compile template with all variables          │
│  5. Send to LLM Suite API                        │
│  6. Display formatted output / save to file      │
└─────────────────────────────────────────────────┘
```

## Adding New Prompts

Create a YAML file in `prompts/<category>/`:

```yaml
id: my_custom_prompt
category: code
title: "My Custom Prompt"
description: "What this prompt does"
tags: [custom, example]
est_time_saved: "15 min"
llm_target: llm_suite

variables:
  - name: code
    description: "Source code to analyze"
    required: true
  - name: language
    description: "Programming language"
    required: false
    default: "auto-detect"
    source: auto_detect

template: |
  Analyze this {{language}} code:
  ```
  {{code}}
  ```
  Provide suggestions for improvement.
```

### Variable Sources

| Source | Description |
|--------|-------------|
| `auto_git` | Auto-fill from git (repo_name, branch, changed_files) |
| `auto_git_diff` | Auto-fill with `git diff` output |
| `auto_git_log` | Auto-fill with recent commit log |
| `auto_detect` | Auto-detect from workspace context |
| `auto_clipboard` | Read from clipboard |
| `auto_file` | Read from specified file |

---

## Architecture

```
dev-accelerator/
├── src/
│   ├── cli.js              # Main CLI entry (Commander.js)
│   └── lib/
│       ├── prompt-loader.js # YAML loader + Handlebars compiler
│       ├── git-context.js   # Git context auto-collector
│       └── llm-client.js    # LLM Suite API client
├── prompts/                 # Prompt library (YAML templates)
│   ├── scaffold/
│   ├── code/
│   ├── review/
│   ├── daily/
│   ├── docs/
│   └── devops/
├── .env.example
├── package.json
└── README.md
```

---

## Tech Stack

- **Runtime**: Node.js 18+
- **CLI Framework**: Commander.js + Inquirer.js
- **Template Engine**: Handlebars (Mustache-compatible)
- **Prompt Format**: YAML with metadata
- **Git Integration**: simple-git
- **LLM Backend**: Any OpenAI-compatible API (LLM Suite, Azure OpenAI, etc.)

---

## Hackathon Demo Flow

1. `devaccel run poc_kickstart` → scaffold a full project in 30s
2. Write code → `devaccel run test_generator` → tests in 15s
3. Before PR → `devaccel run pr_review --dry-run` → review in 20s
4. End of day → `devaccel run eod_report` → formatted report in 10s

**Total time saved in demo: ~3 hours of manual work → under 2 minutes**
