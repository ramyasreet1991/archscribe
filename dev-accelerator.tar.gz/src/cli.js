#!/usr/bin/env node

import { Command } from 'commander';
import chalk from 'chalk';
import inquirer from 'inquirer';
import ora from 'ora';
import { loadAllPrompts, getPromptsByCategory, findPrompt, searchPrompts, compilePrompt, getRequiredInputs } from './lib/prompt-loader.js';
import { autoFillGitVariables } from './lib/git-context.js';
import { callLLM, checkConnection } from './lib/llm-client.js';
import fs from 'fs';

const program = new Command();

// ─── Branding ───────────────────────────────────────────
const BANNER = `
${chalk.cyan('╔══════════════════════════════════════════╗')}
${chalk.cyan('║')}  ${chalk.bold.white('⚡ DevAccelerator')}  ${chalk.dim('v1.0.0')}                ${chalk.cyan('║')}
${chalk.cyan('║')}  ${chalk.dim('LLM-powered developer productivity')}      ${chalk.cyan('║')}
${chalk.cyan('╚══════════════════════════════════════════╝')}
`;

// ─── List Command ───────────────────────────────────────
program
  .command('list')
  .description('List all available prompts')
  .option('-c, --category <category>', 'Filter by category')
  .action((opts) => {
    console.log(BANNER);
    const grouped = getPromptsByCategory();

    const categoryIcons = {
      scaffold: '🏗️ ',
      code: '⚡',
      review: '🔍',
      daily: '📋',
      docs: '📖',
      devops: '🚀',
    };

    const categories = opts.category ? { [opts.category]: grouped[opts.category] } : grouped;

    for (const [cat, prompts] of Object.entries(categories)) {
      if (!prompts) continue;
      console.log(`\n${categoryIcons[cat] || '📂'} ${chalk.bold.cyan(cat.toUpperCase())} ${chalk.dim(`(${prompts.length} prompts)`)}`);
      console.log(chalk.dim('─'.repeat(45)));

      for (const p of prompts) {
        console.log(
          `  ${chalk.green(p.id.padEnd(24))} ${chalk.white(p.title)}`
        );
        console.log(
          `  ${' '.repeat(24)} ${chalk.dim(p.description)}`
        );
        console.log(
          `  ${' '.repeat(24)} ${chalk.yellow('⏱ ' + (p.est_time_saved || 'N/A'))} ${chalk.dim('│')} ${chalk.blue(p.tags?.join(', ') || '')}`
        );
        console.log();
      }
    }

    const total = Object.values(grouped).reduce((s, p) => s + (p?.length || 0), 0);
    console.log(chalk.dim(`\nTotal: ${total} prompts across ${Object.keys(grouped).length} categories`));
  });

// ─── Search Command ─────────────────────────────────────
program
  .command('search <query>')
  .description('Search prompts by keyword')
  .action((query) => {
    const results = searchPrompts(query);
    if (results.length === 0) {
      console.log(chalk.yellow(`No prompts found for "${query}"`));
      return;
    }

    console.log(chalk.bold(`\n🔍 Found ${results.length} prompt(s) for "${query}":\n`));
    for (const p of results) {
      console.log(`  ${chalk.green(p.id)} — ${chalk.white(p.title)} ${chalk.dim(`[${p.category}]`)}`);
      console.log(`  ${chalk.dim(p.description)}\n`);
    }
  });

// ─── Run Command ────────────────────────────────────────
program
  .command('run <prompt-id>')
  .description('Execute a prompt with context')
  .option('-o, --output <file>', 'Save output to file')
  .option('--dry-run', 'Show compiled prompt without calling LLM')
  .option('--repo <path>', 'Path to git repository', process.cwd())
  .action(async (promptId, opts) => {
    console.log(BANNER);

    // 1. Find the prompt
    const promptDef = findPrompt(promptId);
    if (!promptDef) {
      console.log(chalk.red(`❌ Prompt "${promptId}" not found.`));
      console.log(chalk.dim('Run `devaccel list` to see available prompts.'));
      return;
    }

    console.log(chalk.bold(`📝 ${promptDef.title}`) + chalk.dim(` — ${promptDef.description}`));
    console.log();

    // 2. Auto-fill git variables
    const spinner = ora('Collecting workspace context...').start();
    let autoVars = {};
    try {
      autoVars = await autoFillGitVariables(promptDef, opts.repo);
      const autoCount = Object.keys(autoVars).length;
      spinner.succeed(`Collected ${autoCount} context variable(s) from workspace`);
    } catch (err) {
      spinner.warn(`Git context: ${err.message}`);
    }

    // 3. Prompt user for required inputs
    const requiredInputs = getRequiredInputs(promptDef);
    const userVars = {};

    if (requiredInputs.length > 0) {
      console.log(chalk.dim('\nPlease provide the following inputs:\n'));

      const questions = requiredInputs.map((v) => ({
        type: v.name === 'code' || v.name === 'dockerfile' ? 'editor' : 'input',
        name: v.name,
        message: `${v.description}${v.example ? chalk.dim(` (e.g., ${v.example})`) : ''}:`,
        default: v.default,
        validate: (input) => (v.required && !input ? `${v.name} is required` : true),
      }));

      const answers = await inquirer.prompt(questions);
      Object.assign(userVars, answers);
    }

    // 4. Merge variables and compile
    const allVars = { ...autoVars, ...userVars };
    const compiledPrompt = compilePrompt(promptDef, allVars);

    if (opts.dryRun) {
      console.log(chalk.bold('\n── Compiled Prompt ──────────────────────────'));
      console.log(compiledPrompt);
      console.log(chalk.bold('─────────────────────────────────────────────\n'));
      return;
    }

    // 5. Call LLM
    const llmSpinner = ora(`Sending to ${promptDef.llm_target || 'LLM Suite'}...`).start();
    try {
      const result = await callLLM(compiledPrompt);
      llmSpinner.succeed('Response received');

      console.log(chalk.bold('\n── Output ──────────────────────────────────'));
      console.log(result.content);
      console.log(chalk.bold('─────────────────────────────────────────────'));

      if (result.usage) {
        console.log(chalk.dim(`\nTokens: ${result.usage.prompt_tokens} in → ${result.usage.completion_tokens} out | Model: ${result.model}`));
      }

      // 6. Save output if requested
      if (opts.output) {
        fs.writeFileSync(opts.output, result.content, 'utf8');
        console.log(chalk.green(`\n✅ Output saved to ${opts.output}`));
      }
    } catch (err) {
      llmSpinner.fail('LLM call failed');
      console.log(chalk.red(`Error: ${err.message}`));
      console.log(chalk.dim('Check your .env configuration and API key.'));
    }
  });

// ─── Interactive Mode ───────────────────────────────────
program
  .command('interactive')
  .alias('i')
  .description('Interactive prompt selector')
  .action(async () => {
    console.log(BANNER);

    const grouped = getPromptsByCategory();
    const categoryNames = Object.keys(grouped);

    const { category } = await inquirer.prompt([
      {
        type: 'list',
        name: 'category',
        message: 'Select a category:',
        choices: categoryNames.map((c) => ({
          name: `${c.toUpperCase()} (${grouped[c].length} prompts)`,
          value: c,
        })),
      },
    ]);

    const prompts = grouped[category];
    const { promptId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'promptId',
        message: 'Select a prompt:',
        choices: prompts.map((p) => ({
          name: `${p.title} — ${chalk.dim(p.description)} ${chalk.yellow('⏱ ' + (p.est_time_saved || ''))}`,
          value: p.id,
        })),
      },
    ]);

    // Delegate to run command logic
    program.parse(['node', 'devaccel', 'run', promptId]);
  });

// ─── Status Command ─────────────────────────────────────
program
  .command('status')
  .description('Check configuration and LLM connectivity')
  .action(async () => {
    console.log(BANNER);
    console.log(chalk.bold('Configuration Status:\n'));

    // Prompts
    const prompts = loadAllPrompts();
    console.log(`  ${chalk.green('✓')} Prompt library: ${chalk.bold(prompts.length)} prompts loaded`);

    // API config
    const hasKey = !!process.env.LLM_SUITE_API_KEY;
    const baseUrl = process.env.LLM_SUITE_BASE_URL || 'not set';
    console.log(`  ${hasKey ? chalk.green('✓') : chalk.red('✗')} API Key: ${hasKey ? 'configured' : chalk.red('missing')}`);
    console.log(`  ${chalk.dim('  Base URL:')} ${baseUrl}`);
    console.log(`  ${chalk.dim('  Model:')} ${process.env.LLM_SUITE_MODEL || 'gpt-4 (default)'}`);

    // Connectivity test
    if (hasKey) {
      const spinner = ora('Testing LLM connection...').start();
      const conn = await checkConnection();
      if (conn.ok) {
        spinner.succeed(`Connected to ${conn.model}`);
      } else {
        spinner.fail(`Connection failed: ${conn.error}`);
      }
    }

    // Git context test
    try {
      const { collectGitContext } = await import('./lib/git-context.js');
      const ctx = await collectGitContext();
      console.log(`  ${ctx.isRepo ? chalk.green('✓') : chalk.yellow('○')} Git repo: ${ctx.isRepo ? ctx.repo_name : 'not in a git repo'}`);
    } catch {
      console.log(`  ${chalk.yellow('○')} Git: not available`);
    }
  });

// ─── Init Command ───────────────────────────────────────
program
  .command('init')
  .description('Initialize DevAccelerator in current project')
  .action(() => {
    console.log(BANNER);

    if (!fs.existsSync('.env') && fs.existsSync(new URL('../.env.example', import.meta.url).pathname)) {
      fs.copyFileSync(new URL('../.env.example', import.meta.url).pathname, '.env');
      console.log(chalk.green('✅ Created .env from template'));
    } else if (fs.existsSync('.env')) {
      console.log(chalk.yellow('⚠️  .env already exists'));
    }

    console.log(`
${chalk.bold('Quick Start:')}
  1. Edit ${chalk.cyan('.env')} with your LLM Suite API credentials
  2. Run ${chalk.cyan('devaccel status')} to verify connection
  3. Run ${chalk.cyan('devaccel list')} to see available prompts
  4. Run ${chalk.cyan('devaccel run <prompt-id>')} to execute a prompt
  5. Run ${chalk.cyan('devaccel interactive')} for guided mode
    `);
  });

program
  .name('devaccel')
  .version('1.0.0')
  .description('LLM-powered developer productivity prompt library')
  .parse(process.argv);

// Show help if no command
if (!process.argv.slice(2).length) {
  console.log(BANNER);
  program.outputHelp();
}
